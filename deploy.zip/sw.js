const prefix = 'mjc-os-static-';
const cacheName = prefix + 'd344fa3324c005e5';
const files = ["/404.html", "/assets/apps.18f1999be153.css", "/assets/avatar.807e8ad213fe.webp", "/assets/capture.52c22ce24f0b.css", "/assets/case-preview.23f3c678c340.js", "/assets/contact-reveal.6723528699c5.js", "/assets/control-input.9618447454bb.js", "/assets/gallery.3bca3d966eee.js", "/assets/home-media.8867ab546fe6.js", "/assets/identity.88e5d880e761.svg", "/assets/image-viewer.000df8eee326.js", "/assets/portfolio.649e9b489589.js", "/assets/portfolio.82b220fdd192.css", "/assets/ribbon-480.42807164342e.webp", "/assets/ribbon-800.be2ea2e1bd9d.webp", "/assets/story.775a18f54ea5.js", "/contact/index.html", "/en/index.html", "/experience/index.html", "/honor/index.html", "/ice/index.html", "/index.html", "/manifest.webmanifest", "/offline.html", "/plain/index.html", "/poster/index.html", "/projects/index.html", "/projects/sprout-patrol/index.html", "/standby/index.html", "/story/index.html", "/updates/index.html"];
const controlUrl = new URL('/sw-state.json', self.location.origin).href;
let statusCheck;
let retirement;

function releaseIsRetired() {
  if (!statusCheck) {
    statusCheck = (async () => {
      try {
        const response = await fetch(controlUrl, { cache: 'no-store' });
        if (response.status === 404 || response.status === 410) return true;
        if (!response.ok) return false;
        return (await response.json()).enabled === false;
      } catch {
        return false;
      }
    })().finally(() => { statusCheck = undefined; });
  }
  return statusCheck;
}

function retire() {
  if (!retirement) retirement = (async () => {
    await self.registration.unregister();
    for (const key of await caches.keys()) {
      if (key.startsWith(prefix)) await caches.delete(key);
    }
  })();
  return retirement;
}

self.addEventListener('install', event => {
  event.waitUntil(caches.open(cacheName).then(cache => cache.addAll(files)));
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key.startsWith(prefix) && key !== cacheName) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('message', event => {
  if (event.data?.type === 'ACTIVATE_UPDATE') event.waitUntil(self.skipWaiting());
  if (event.data?.type === 'CHECK_RELEASE') {
    event.waitUntil((async () => {
      if (!await releaseIsRetired()) return;
      await retire();
      const clients = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
      for (const client of clients) {
        const path = new URL(client.url).pathname;
        if (path !== '/game' && !path.startsWith('/game/')) client.postMessage({ type: 'OS_ROLLBACK' });
      }
    })());
  }
});

function documentKey(path) {
  if (path.endsWith('/')) return path + 'index.html';
  return path.endsWith('.html') ? path : path + '/index.html';
}

self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);
  if (retirement || request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/game/') ||
      url.pathname === '/game' || request.headers.has('Range') || /\.(?:mp4|aac|pdf|vcf)$/.test(url.pathname) ||
      url.pathname.startsWith('/assets/ice.')) return;
  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(cacheName);
      const key = documentKey(url.pathname);
      try {
        // Request fresh HTML even when a prior navigation filled the offline cache.
        const response = await fetch(request, { cache: 'no-cache' });
        if (retirement || await releaseIsRetired()) {
          await retire();
          return response.ok ? response : Response.redirect(new URL('/', self.location.origin), 302);
        }
        if (response.ok && files.includes(key)) await cache.put(key, response.clone());
        return response;
      } catch {
        return await cache.match(key) || await cache.match('/offline.html');
      }
    })());
    return;
  }
  if (files.includes(url.pathname)) {
    event.respondWith(caches.open(cacheName).then(async cache => {
      if (retirement) return fetch(request);
      const saved = await cache.match(url.pathname);
      if (saved) return saved;
      return fetch(request);
    }));
  }
});
