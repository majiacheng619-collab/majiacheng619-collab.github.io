/* Progressive portfolio interactions. Include once with defer; no dependencies. */
(() => {
  'use strict';
  const all = (selector, root = document) => [...root.querySelectorAll(selector)];
  const byId = id => id ? document.getElementById(id.replace(/^#/, '')) : null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const focusable = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const isOpen = dialog => Boolean(dialog?.hasAttribute('open'));
  const canFocus = node => node && !node.hidden && node.getClientRects().length > 0;
  const fallbackStates = new WeakMap();
  const modalSupported = typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const openers = new WeakMap();
  const triggers = new WeakMap();
  let activeDialog = null;
  let priorOverflow = '';
  let priorGutter = '';
  const outsideStarts = new WeakMap();

  function finishClose(dialog, restoreFocus = true) {
    if (isOpen(dialog) || activeDialog !== dialog) return;
    all('video, audio', dialog).forEach(media => media.pause());
    const opener = openers.get(dialog);
    triggers.get(dialog)?.setAttribute('aria-expanded', 'false');
    const fallback = fallbackStates.get(dialog);
    if (fallback) {
      fallback.backdrop.remove();
      fallback.background.forEach(({ node, inert, hidden }) => {
        if ('inert' in node) node.inert = inert;
        if (hidden === null) node.removeAttribute('aria-hidden'); else node.setAttribute('aria-hidden', hidden);
      });
      if (fallback.style === null) dialog.removeAttribute('style'); else dialog.setAttribute('style', fallback.style);
      if (fallback.role === null) dialog.removeAttribute('role'); else dialog.setAttribute('role', fallback.role);
      dialog.removeAttribute('aria-modal');
      fallbackStates.delete(dialog);
    }
    document.documentElement.style.overflow = priorOverflow;
    document.documentElement.style.scrollbarGutter = priorGutter;
    activeDialog = null;
    if (restoreFocus && opener?.isConnected && canFocus(opener) && !opener.closest('dialog:not([open])')) opener.focus({ preventScroll: true });
  }
  function close(dialog, restoreFocus = true) {
    if (!isOpen(dialog)) return;
    if (fallbackStates.has(dialog)) dialog.removeAttribute('open');
    else dialog.close();
    // Native close events are queued: settle this session before opening another.
    finishClose(dialog, restoreFocus);
  }
  function open(dialog, opener) {
    if (!dialog || dialog.tagName !== 'DIALOG') return false;
    if (isOpen(dialog)) return true;
    const returnOpener = activeDialog && opener?.closest('dialog') === activeDialog ? openers.get(activeDialog) : opener;
    if (activeDialog && activeDialog !== dialog) close(activeDialog, false);
    openers.set(dialog, returnOpener);
    triggers.set(dialog, opener);
    priorOverflow = document.documentElement.style.overflow;
    priorGutter = document.documentElement.style.scrollbarGutter;
    // Reserve the scrollbar lane so opening a dialog does not shift the page.
    document.documentElement.style.scrollbarGutter = 'stable';
    document.documentElement.style.overflow = 'hidden';
    // Older WebViews still receive a usable, focus-contained dialog.
    let nativeOpened = false;
    if (modalSupported) {
      try { dialog.showModal(); nativeOpened = true; } catch (_) { /* Use the local fallback. */ }
    }
    if (!nativeOpened) {
      const backdrop = document.createElement('div');
      backdrop.setAttribute('aria-hidden', 'true');
      backdrop.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(12,20,32,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)';
      const background = all('body > *').filter(node => node !== dialog && !['SCRIPT', 'STYLE'].includes(node.tagName))
        .map(node => ({ node, inert: node.inert, hidden: node.getAttribute('aria-hidden') }));
      fallbackStates.set(dialog, { backdrop, background, style: dialog.getAttribute('style'), role: dialog.getAttribute('role') });
      background.forEach(({ node }) => { if ('inert' in node) node.inert = true; else node.setAttribute('aria-hidden', 'true'); });
      document.body.append(backdrop);
      backdrop.addEventListener('click', () => close(dialog));
      dialog.setAttribute('open', '');
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      Object.assign(dialog.style, { display: 'block', position: 'fixed', zIndex: '9999', inset: '0', margin: 'auto', overflow: 'auto', maxHeight: 'calc(100% - 24px)' });
    }
    activeDialog = dialog;
    opener?.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => {
      if (activeDialog !== dialog || !isOpen(dialog)) return;
      const target = dialog.querySelector('[autofocus]') ||
        dialog.querySelector('[data-dialog-close], button, a[href], input');
      if (target) target.focus({ preventScroll: true });
      else { dialog.tabIndex = -1; dialog.focus({ preventScroll: true }); }
    });
    return true;
  }

  all('dialog').forEach(dialog => {
    if (!modalSupported) dialog.style.display = 'none';
    dialog.addEventListener('close', () => {
      // Ignore an older queued close if this dialog has already reopened.
      finishClose(dialog);
    });
    const outside = event => {
      const box = dialog.getBoundingClientRect();
      return event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom);
    };
    dialog.addEventListener('pointerdown', event => { outsideStarts.set(dialog, outside(event)); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(dialog); });
    dialog.addEventListener('click', event => {
      // A drag starting inside the dialog must never dismiss it on release.
      const startedOutside = outsideStarts.get(dialog);
      outsideStarts.delete(dialog);
      if (!startedOutside || event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close(dialog);
    });
    all('[data-dialog-close], [data-portrait-close]', dialog).forEach(button => button.addEventListener('click', () => close(dialog)));
  });

  window.PortfolioDialogs = { open, close };

  all('[data-dialog-open], [data-portrait-open], [data-image-open]').forEach(opener => {
    const id = opener.dataset.dialogOpen || opener.dataset.imageTarget || 'portrait-dialog';
    const dialog = byId(id);
    if (!dialog) {
      // Keep real hrefs operational; dead buttons should not appear interactive.
      if (opener.tagName === 'BUTTON') opener.hidden = true;
      return;
    }
    opener.setAttribute('aria-controls', dialog.id);
    opener.setAttribute('aria-haspopup', 'dialog');
    opener.setAttribute('aria-expanded', 'false');
    opener.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (opener.hasAttribute('data-image-open')) {
        const image = dialog.querySelector('[data-dialog-image]');
        const source = opener.dataset.imageSrc || opener.getAttribute('href');
        if (image && source) {
          let url;
          try { url = new URL(source, location.href); } catch (_) { return; }
          if (!['https:', 'http:'].includes(url.protocol)) return;
          image.src = url.href;
          image.alt = opener.dataset.imageAlt || opener.querySelector('img')?.alt || '作品图片';
        }
      }
      if (open(dialog, opener)) event.preventDefault();
    });
  });

  document.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.defaultPrevented) return;
    if (activeDialog && event.key === 'Escape') { event.preventDefault(); close(activeDialog); return; }
    if (!activeDialog || !fallbackStates.has(activeDialog)) return;
    if (event.key === 'Tab') {
      const targets = all(focusable, activeDialog).filter(canFocus);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) { event.preventDefault(); activeDialog.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    }
  });

  // No autoplay, scroll hijacking, or automatic audio resumption.
  // Native video controls remain the single playback surface.
  const pauseMedia = () => all('video').forEach(media => media.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMedia(); });
  window.addEventListener('pagehide', pauseMedia);

  // A small, explicit choice illustrates the mechanism; no timed advancement.
  all('.growth-demo').forEach(demo => {
    const buttons = all('button[data-growth-step]', demo);
    const panels = all('[data-growth-panel]', demo);
    if (!buttons.length || !panels.length) return;
    let growthMotion=null;
    const select = (step,animate=true) => {
      growthMotion?.cancel();
      const chosen = panels.find(panel => panel.dataset.growthPanel === step);
      if (!chosen) return;
      buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.growthStep === step)));
      panels.forEach(panel => { panel.hidden = panel !== chosen; });
      if(animate&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
        const plant=chosen.querySelector('img');
        if(plant){growthMotion=plant.animate([{opacity:.45,transform:'translateY(10px) scale(.86)'},{opacity:1,transform:'none'}],{duration:300,easing:'cubic-bezier(.2,.8,.2,1)'});growthMotion.finished.catch(()=>{});}
      }
    };
    buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.growthStep)));
    const initial = buttons.find(button => button.getAttribute('aria-pressed') === 'true') || buttons[0];
    select(initial.dataset.growthStep,false);
    demo.classList.add('is-enhanced');
  });

  document.documentElement.classList.add('js-ready');

  // Content remains visible if JS fails or IntersectionObserver is unsupported.
  const reveal = all('[data-reveal]');
  let observer;
  const settleReveal = () => {
    observer?.disconnect();
    reveal.forEach(node => { node.classList.remove('reveal-pending'); node.classList.add('is-visible'); });
  };
  if (!reduce.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    reveal.forEach(node => {
      // Above-the-fold content is immediately readable, even on a slow device.
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight && box.bottom > 0) node.classList.add('is-visible');
      else { observer.observe(node); node.classList.add('reveal-pending'); }
    });
    document.addEventListener('focusin', event => {
      const section = event.target.closest?.('[data-reveal]');
      if (section) { section.classList.remove('reveal-pending'); section.classList.add('is-visible'); observer.unobserve(section); }
    });
    window.addEventListener('beforeprint', settleReveal);
    window.addEventListener('pageshow', event => { if (event.persisted) settleReveal(); });
  } else settleReveal();
  // Only active reveal effects respond to the motion preference.
  const motionChanged = () => { if (reduce.matches) settleReveal(); };
  if (reduce.addEventListener) reduce.addEventListener('change', motionChanged);
  else reduce.addListener(motionChanged);
})();

/* The dock keeps real links and native vertical scrolling. Only a deliberate
   horizontal drag becomes a liquid selection gesture. No page-wide effects. */
(() => {
  'use strict';
  const dock = document.querySelector('[data-glass-dock]');
  if (!dock || dock.dataset.glassReady) return;
  const lens = dock.querySelector('[data-dock-lens]');
  const links = [...dock.querySelectorAll('[data-dock-item]')];
  const isLink = item => item.hasAttribute('data-dock-link');
  if (!lens || !links.length) return;
  dock.dataset.glassReady = 'true';
  // Anchors remain ordinary links, but their browser drag ghost would cancel
  // the pointer stream before our horizontal liquid gesture can take ownership.
  links.forEach(link => {
    link.setAttribute('draggable', 'false');
    link.querySelectorAll('svg,img').forEach(node => node.setAttribute('draggable', 'false'));
  });
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const aborter = new AbortController();
  const signal = aborter.signal;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  let selected = Math.max(0, links.findIndex(link => link.hasAttribute('aria-current')));
  let dockLeft = 0, measuredRect = null;
  let boxes = [], current = 0, target = 0, width = 0, targetWidth = 0;
  let velocity = 0, frame = 0, lastTime = 0, gesture = null;
  let suppressClickUntil = 0, navigationTimer = 0, dragActivation = false;
  let heldScale = 0, heldVelocity = 0;
  let resizeObserver = null, contrastObserver = null, pendingHref = '';
  const contrastSources = [...document.querySelectorAll('video, .dark, [data-dock-tone=dark]')];
  function observeContrast() {
    contrastObserver?.disconnect();
    if (!contrastSources.length || !('IntersectionObserver' in window)) return;
    const box = dock.getBoundingClientRect();
    const viewportHeight = window.innerHeight, viewportWidth = window.innerWidth;
    const center = box.top + box.height / 2;
    const active = new Set();
    contrastObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) active.add(entry.target); else active.delete(entry.target); });
      dock.toggleAttribute('data-over-media', active.size > 0);
    }, {rootMargin:`${-center}px ${-(viewportWidth - box.right)}px ${-(viewportHeight - center - 1)}px ${-box.left}px`, threshold:0});
    contrastSources.forEach(node => contrastObserver.observe(node));
  }
  const handoffKey = 'portfolio-dock-handoff-v2';
  const normalizedPath = pathname => pathname.replace(/\/index\.html$/, '/');
  function samePage(a, b) {
    return a.origin === b.origin && normalizedPath(a.pathname) === normalizedPath(b.pathname) && a.search === b.search;
  }
  function clearHandoff() {
    pendingHref = '';
    try { sessionStorage.removeItem(handoffKey); } catch (_) { /* Storage may be disabled. */ }
  }
  function saveHandoff() {
    if (!pendingHref || reduce.matches || boxes.length < 2) return;
    const span = boxes.at(-1).x - boxes[0].x;
    if (span <= 0) return;
    try {
      sessionStorage.setItem(handoffKey, JSON.stringify({
        href: pendingHref, at: Date.now(), fraction: (current - boxes[0].x) / span,
        speed: clamp(velocity / span, -3, 3), lift: heldScale
      }));
    } catch (_) { /* Ordinary anchor navigation remains available without storage. */ }
  }
  function restoreHandoff() {
    let state;
    try {
      state = JSON.parse(sessionStorage.getItem(handoffKey));
      sessionStorage.removeItem(handoffKey);
    } catch (_) { return; }
    if (reduce.matches || !state || typeof state.href !== 'string' ||
        !Number.isFinite(state.at) || Date.now() - state.at < 0 || Date.now() - state.at > 10000 ||
        !Number.isFinite(state.fraction) || state.fraction < -.1 || state.fraction > 1.1 ||
        !Number.isFinite(state.speed) || !Number.isFinite(state.lift)) return;
    try { if (!samePage(new URL(state.href, location.href), new URL(location.href))) return; } catch (_) { return; }
    const span = boxes.at(-1).x - boxes[0].x;
    current = boxes[0].x + state.fraction * span;
    velocity = clamp(state.speed, -3, 3) * span;
    heldScale = clamp(state.lift, 0, 1);
    paint(1 + heldScale * .09, 1 + heldScale * .16);
    animate();
  }

  // The shell alone samples the backdrop. The empty lens is one composited
  // surface: no filters, cloned labels, width animation or per-item frame writes.
  function paint(stretch = 1, squash = 1) {
    lens.style.setProperty('--lens-x', `${current.toFixed(3)}px`);
    lens.style.setProperty('--lens-stretch', stretch.toFixed(4));
    lens.style.setProperty('--lens-squash', squash.toFixed(4));
    lens.style.setProperty('--lens-glint-shift', `${clamp(velocity * .008, -10, 10).toFixed(3)}px`);
    lens.style.setProperty('--lens-glint-alpha', (.2 + Math.min(.45, Math.abs(velocity) * .0003 + Math.abs(heldScale) * .24)).toFixed(3));
  }
  function tick(time) {
    frame = 0;
    if (document.hidden) return;
    const dt = clamp((time - (lastTime || time - 16.667)) / 1000, .001, 1);
    lastTime = time;
    // Closed-form springs are stable across long frames: use real elapsed time
    // so rendering pressure cannot stretch a short release into idle animation.
    if (gesture?.dragging) {
      // Coalesce input into one paint per display frame; do not make the finger
      // chase a spring. Only the released lens settles with inertia.
      velocity = (target - current) / dt;
      current = target;
    } else {
      const omega = 24;
      const offset = current - target, c = velocity + omega * offset;
      const decay = Math.exp(-omega * dt);
      current = target + (offset + c * dt) * decay;
      velocity = (velocity - omega * c * dt) * decay;
    }
    const heldTarget = gesture ? 1 : 0;
    // Closed-form damped droplet response: one restrained release ripple,
    // independent of display refresh rate and with no geometry/filter animation.
    const frequency = 30, damping = .72, decayLift = Math.exp(-damping * frequency * dt);
    const damped = frequency * Math.sqrt(1 - damping * damping);
    const liftOffset = heldScale - heldTarget;
    const liftB = (heldVelocity + damping * frequency * liftOffset) / damped;
    const liftCos = Math.cos(damped * dt), liftSin = Math.sin(damped * dt);
    heldScale = heldTarget + decayLift * (liftOffset * liftCos + liftB * liftSin);
    heldVelocity = decayLift * ((-damping * frequency * liftOffset + damped * liftB) * liftCos
      + (-damping * frequency * liftB - damped * liftOffset) * liftSin);
    const strain = Math.min(.15, Math.abs(velocity) * .00013);
    paint(1 + strain + heldScale * .09, 1 - strain * .32 + heldScale * .16);
    if (Math.abs(current - target) > .03 || Math.abs(velocity) > .15 || Math.abs(heldTarget - heldScale) > .002 || Math.abs(heldVelocity) > .04) {
      frame = requestAnimationFrame(tick);
    } else {
      current = target; velocity = 0; lastTime = 0; heldScale = heldTarget; heldVelocity = 0;
      dock.removeAttribute('data-settling');
      paint(1 + heldScale * .09, 1 + heldScale * .16);
    }
  }
  function animate() {
    if (reduce.matches) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; velocity = 0; lastTime = 0; current = target; width = targetWidth; heldScale = 0; heldVelocity = 0;
      paint(); return;
    }
    if (!frame && !document.hidden) {
      if (!lastTime) lastTime = performance.now();
      frame = requestAnimationFrame(tick);
    }
  }
  function measure(snap = false) {
    const rect = dock.getBoundingClientRect();
    measuredRect = {left:rect.left, width:rect.width, height:rect.height};
    dockLeft = rect.left + dock.clientLeft;
    boxes = links.map(link => {
      const box = link.getBoundingClientRect();
      return {x: box.left - rect.left - dock.clientLeft, width: box.width, center: box.left + box.width / 2};
    });
    const geometryIndex = selected;
    target = boxes[geometryIndex].x; targetWidth = boxes[geometryIndex].width;
    width = targetWidth;
    lens.style.setProperty('--lens-width', `${width.toFixed(3)}px`);
    if (snap || !width) { current = target; width = targetWidth; velocity = 0; paint(); }
    else animate();
  }
  function select(index, snap = false) {
    selected = clamp(index, 0, links.length - 1);
    links.forEach((link, i) => {
      if (i === selected && isLink(link)) link.setAttribute('data-active', 'true');
      else link.removeAttribute('data-active');
      if (i === selected && isLink(link)) link.setAttribute('aria-current', new URL(link.href, location.href).hash ? 'location' : 'page');
      else link.removeAttribute('aria-current');
    });
    if (!boxes.length) return;
    target = boxes[selected].x; targetWidth = boxes[selected].width;
    if (snap) { current = target; width = targetWidth; velocity = 0; paint(); }
    else { dock.setAttribute('data-settling', ''); animate(); }
  }
  function nearest(clientX) {
    return boxes.reduce((best, box, index) => Math.abs(clientX - box.center) < Math.abs(clientX - boxes[best].center) ? index : best, 0);
  }
  function releaseCapture(pointerId) {
    if (dock.hasPointerCapture?.(pointerId)) dock.releasePointerCapture(pointerId);
  }
  function cancelGesture() {
    const old = gesture; gesture = null;
    velocity = 0;
    dock.removeAttribute('data-dragging');
    if (old) releaseCapture(old.id);
    select(selected, reduce.matches);
  }
  dock.addEventListener('contextmenu', event => {
    // Keep desktop link menus (including Ctrl-click on macOS) available. Only
    // the touch hold needs suppression to avoid callouts and selected labels.
    if (event.button === 2 || event.ctrlKey || event.pointerType === 'mouse') return;
    event.preventDefault();
    if (gesture && !gesture.dragging) { suppressClickUntil = performance.now() + 900; cancelGesture(); }
  }, {signal});
  dock.addEventListener('selectstart', event => event.preventDefault(), {signal});
  dock.addEventListener('dragstart', event => event.preventDefault(), {signal});
  dock.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || event.target.closest('a')?.hasAttribute('download')) return;
    if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = 0; clearHandoff(); }
    measure();
    gesture = {id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), dragging: false};
    animate();
  }, {signal, passive: true});
  dock.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
    if (!gesture.dragging) {
      if (Math.abs(dy) > 9 && Math.abs(dy) > Math.abs(dx)) { cancelGesture(); return; }
      if (Math.abs(dx) < 7 || Math.abs(dx) < Math.abs(dy) * 1.15) return;
      gesture.dragging = true;
      dock.setPointerCapture?.(event.pointerId);
      dock.setAttribute('data-dragging', 'true');
    }
    if (event.cancelable) event.preventDefault();
    const first = boxes[0].x, last = boxes.at(-1).x;
    // Once horizontal intent is established, the lens belongs underneath the
    // finger even if the gesture began over an unselected destination.
    const raw = event.clientX - dockLeft - width / 2;
    target = raw < first ? first + (raw - first) * .16 : raw > last ? last + (raw - last) * .16 : raw;
    animate();
  }, {signal, passive: false});
  dock.addEventListener('pointerup', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const wasDragging = gesture.dragging;
    const held = performance.now() - gesture.started;
    gesture = null;
    dock.removeAttribute('data-dragging');
    releaseCapture(event.pointerId);
    if (!wasDragging) {
      // A held press can already have settled and stopped its frame loop.
      // Always restart on release, even when no click follows the long hold.
      animate();
      if (held > 550) suppressClickUntil = performance.now() + 450;
      return;
    }
    velocity = clamp(velocity, -750, 750);
    const next = nearest(event.clientX);
    if (isLink(links[next])) select(next);
    else select(selected);
    // Consume only the compatibility click generated by this drag. Dispatch a
    // real anchor click first so existing navigation handlers remain in charge.
    dragActivation = event.isTrusted;
    links[next].click();
    dragActivation = false;
    suppressClickUntil = performance.now() + 450;
  }, {signal});
  dock.addEventListener('click', event => {
    if (performance.now() < suppressClickUntil && event.isTrusted && event.detail > 0) {
      suppressClickUntil = 0;
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const link = event.target.closest('[data-dock-item]');
    if (!link || !isLink(link) || link.hasAttribute('download') || link.getAttribute('target') === '_blank' || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
    select(links.indexOf(link));
    const url = new URL(link.href, location.href);
    const currentURL = new URL(location.href);
    // Native cross-document navigation otherwise destroys the selection animation
    // before its first frame. A short, cancellable handoff makes it visible.
    if ((event.isTrusted || dragActivation) && url.origin === location.origin &&
        !samePage(url, currentURL)) {
      event.preventDefault();
      if (navigationTimer) clearTimeout(navigationTimer);
      pendingHref = url.href;
      if (reduce.matches) { clearHandoff(); location.assign(url.href); }
      else navigationTimer = setTimeout(() => {
        navigationTimer = 0;
        saveHandoff();
        location.assign(url.href);
      }, 110);
    }
  }, {signal, capture: true});
  dock.addEventListener('pointercancel', cancelGesture, {signal});
  // A mouse press has no implicit capture. If it leaves the dock before a
  // horizontal drag begins, its release never reaches the dock listener.
  // Clear that held state without activating an unrelated destination.
  addEventListener('pointerup', event => {
    if (gesture && event.pointerId === gesture.id && !dock.contains(event.target)) cancelGesture();
  }, {signal});
  addEventListener('blur', () => { if (gesture) cancelGesture(); }, {signal});
  dock.addEventListener('lostpointercapture', event => {
    // Touch starts with implicit capture on the anchor. Moving capture to the
    // dock emits a bubbling lostpointercapture for that anchor; it is not loss
    // of the dock's newly acquired pointer and must not cancel the drag.
    if (gesture && event.pointerId === gesture.id && !dock.hasPointerCapture?.(gesture.id)) cancelGesture();
  }, {signal});
  // Native Tab/Enter activation and the focus-visible ring provide keyboard
  // navigation. Focus alone never moves the page-selection lens to a different
  // destination, so a focused control cannot look like a second current page.
  const onResize = event => {
    // ResizeObserver delivers an initial notification even without a resize.
    // Snapping that notification would erase a just-restored cross-page spring.
    const rect = dock.getBoundingClientRect();
    const changed = !measuredRect || rect.left !== measuredRect.left || rect.width !== measuredRect.width || rect.height !== measuredRect.height;
    if (!changed && !event?.type) return;
    if (gesture) cancelGesture();
    measure(true);
    observeContrast();
  };
  addEventListener('resize', onResize, {signal, passive: true});
  if ('ResizeObserver' in window) {
    resizeObserver = new ResizeObserver(onResize); resizeObserver.observe(dock);
  }
  const onMotion = () => { cancelGesture(); measure(true); animate(); };
  reduce.addEventListener('change', onMotion, {signal});
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0; cancelGesture();
    } else { measure(true); }
  }, {signal});
  // Each tab now names a separate page, including contact. Scrolling inside a
  // document never changes its current-page semantics or runs a section observer.
  measure(true); select(selected, true); restoreHandoff(); observeContrast();
  addEventListener('pagehide', event => {
    // Capture the actual departure position after loading time, rather than the
    // earlier click position, so the next document continues the same movement.
    saveHandoff();
    cancelGesture();
    if (frame) cancelAnimationFrame(frame);
    frame = 0; velocity = 0; lastTime = 0;
    if (navigationTimer) clearTimeout(navigationTimer);
    navigationTimer = 0;
    if (event.persisted) return;
    aborter.abort(); resizeObserver?.disconnect(); contrastObserver?.disconnect();
    if (frame) cancelAnimationFrame(frame);
  }, {signal});
  addEventListener('pageshow', event => {
    if (!event.persisted) return;
    suppressClickUntil = 0;
    heldScale = 0; heldVelocity = 0; velocity = 0;
    measure(true); select(selected, true);
  }, {signal});
})();

/* Small portfolio-only keyboard improvements. Existing springs, pointer input,
 * native scrolling, dialogs and click activation each keep their single owner. */
(() => {
  'use strict';
  if (!document.body.matches('.home-page,.inner-page')) return;

  // Preserve saved links to business cards whose full cases now live in Experience.
  if (/\/projects\/(?:index\.html)?$/.test(location.pathname)) {
    const destination = {'#service-work':'ecommerce','#campus-work':'printing'}[location.hash];
    if (destination) { location.replace(new URL('../experience/index.html#'+destination,location.href)); return; }
  }

  const dock = document.querySelector('[data-glass-dock]');
  if (dock && !dock.dataset.keyboardNavigation) {
    dock.dataset.keyboardNavigation = 'ready';
    dock.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.isComposing) return;
      const links = [...dock.querySelectorAll('a[data-dock-link][href]')];
      const current = links.indexOf(event.target);
      if (current < 0) return;
      const reverse = getComputedStyle(dock).direction === 'rtl' ? -1 : 1;
      let next;
      if (event.key === 'ArrowRight') next = (current + reverse + links.length) % links.length;
      else if (event.key === 'ArrowLeft') next = (current - reverse + links.length) % links.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = links.length - 1;
      else return;
      // Arrow keys only move focus. Current-page semantics and the material
      // selection remain truthful until the user activates a real destination.
      event.preventDefault();
      links[next].focus({preventScroll:true});
    });
  }

  const focusDeepLink = () => {
    if (!location.hash || document.querySelector('dialog[open]')) return;
    let id;
    try { id = decodeURIComponent(location.hash.slice(1)); } catch { return; }
    const target = document.getElementById(id);
    if (!target || !target.closest('main') || !target.getClientRects().length) return;
    const active = document.activeElement;
    if (active && active !== document.body && active !== document.documentElement && active.tagName !== 'A') return;
    if (active?.tagName === 'A') {
      let destination;
      try { destination = new URL(active.href,location.href); } catch { return; }
      if (destination.pathname !== location.pathname || destination.hash !== location.hash) return;
    }
    const heading = target.matches('h1,h2,h3') ? target : target.querySelector('h1,h2,h3');
    const destination = heading || target;
    const previous = destination.getAttribute('tabindex');
    destination.setAttribute('tabindex','-1');
    destination.dataset.anchorFocus = '';
    // The browser owns the anchor scroll. This moves only the reading/focus
    // position, so keyboard and screen-reader users arrive at the same section.
    destination.focus({preventScroll:true});
    destination.addEventListener('blur', () => {
      if (previous === null) destination.removeAttribute('tabindex');
      else destination.setAttribute('tabindex',previous);
      delete destination.dataset.anchorFocus;
    }, {once:true});
  };
  addEventListener('hashchange',focusDeepLink);
  addEventListener('pageshow',event => { if (!event.persisted) focusDeepLink(); });
  // Once-only reading transitions: content is visible before JavaScript and
  // pressure/focus always wins over an entrance that is still in progress.
  const motionPreference=matchMedia('(prefers-reduced-motion: reduce)');
  const entranceAnimations=new Map();
  let entranceObserver;
  function clearEntrances(){
    entranceObserver?.disconnect();
    for(const animation of entranceAnimations.values())animation.cancel();
    entranceAnimations.clear();
  }
  function observeEntrances(){
    if (motionPreference.matches || document.documentElement.dataset.polish !== 'ready' ||
        !('IntersectionObserver' in window)) return;
    entranceObserver?.disconnect();
    const nodes=[...document.querySelectorAll('.practice-glass,.work-card,.detail-row-list,.case-study,.detail-split,.contact-identity')];
    entranceObserver=new IntersectionObserver(entries=>{
      if (motionPreference.matches || document.documentElement.dataset.polish !== 'ready') return;
      for(const entry of entries){
        if(!entry.isIntersecting)continue;
        const node=entry.target;entranceObserver.unobserve(node);
        if(node.dataset.motionEntered)continue;
        node.dataset.motionEntered='true';
        if(node.matches(':focus-within,[data-glass-pressed="true"]'))continue;
        const animation=node.animate([{opacity:.65,translate:'0 20px'},{opacity:1,translate:'0 0'}],{duration:650,easing:'cubic-bezier(.22,1,.36,1)'});
        entranceAnimations.set(node,animation);
        animation.finished.catch(()=>{}).finally(()=>{if(entranceAnimations.get(node)===animation)entranceAnimations.delete(node);});
      }
    },{threshold:.12});
    nodes.filter(node=>!node.dataset.motionEntered&&!node.closest('[data-reveal]')).forEach(node=>entranceObserver.observe(node));
  }
  function yieldToInput(event){
    for(const [node,animation] of entranceAnimations)if(node.contains(event.target)){animation.cancel();entranceAnimations.delete(node);}
  }
  document.addEventListener('pointerdown',yieldToInput,{passive:true,capture:true});
  document.addEventListener('focusin',yieldToInput,{passive:true});
  motionPreference.addEventListener('change',()=>{clearEntrances();observeEntrances();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clearEntrances();else observeEntrances();});
  addEventListener('pagehide',clearEntrances);
  addEventListener('pageshow',event=>{if(event.persisted)observeEntrances();});
  addEventListener('portfolio:polish',observeEntrances);
})();

/* Actual previews and direct contact utilities, progressively enhanced. */
(() => {
  'use strict';
  if (!document.body.matches('.home-page,.inner-page')) return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  for(const workbench of document.querySelectorAll('[data-studio-preview]')) {
    const tabs=[...workbench.querySelectorAll('[data-studio-tab]')];
    const panels=[...workbench.querySelectorAll('[data-studio-panel]')];
    if(!tabs.length||tabs.length!==panels.length)continue;
    let active=0,transition=null,heightTransition=null;
    const tablist=workbench.querySelector('[role="tablist"]');
    function measureSelection(){
      const selected=tabs[active];
      tablist.style.setProperty('--studio-tab-x',selected.offsetLeft+'px');
      tablist.style.setProperty('--studio-tab-width',selected.offsetWidth+'px');
    }
    function select(index,focus=false,animate=true){
      if(index<0||index>=tabs.length)return;
      const before=workbench.getBoundingClientRect().height;
      transition?.cancel();heightTransition?.cancel();
      active=index;
      tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});
      panels.forEach((panel,i)=>{panel.hidden=i!==index;panel.tabIndex=i===index?0:-1;});
      measureSelection();
      if(focus)tabs[index].focus({preventScroll:true});
      if(animate&&!reduced.matches&&panels[index].animate){
        const after=workbench.getBoundingClientRect().height;
        heightTransition=workbench.animate([{height:before+'px'},{height:after+'px'}],{duration:460,easing:'cubic-bezier(.22,1,.36,1)'});
        heightTransition.finished.catch(()=>{});
        transition=panels[index].animate([{opacity:.45,transform:'perspective(1000px) translate3d(0,16px,-18px) scale(.985)'},{opacity:1,transform:'none'}],{duration:460,easing:'cubic-bezier(.22,1,.36,1)'});
        transition.finished.catch(()=>{});
      }
    }
    tabs.forEach((tab,index)=>{
      tab.addEventListener('click',()=>select(index));
      tab.addEventListener('keydown',event=>{
        if(event.altKey||event.ctrlKey||event.metaKey||event.shiftKey)return;
        const focused=tabs.indexOf(event.currentTarget);
        const current=focused<0?active:focused;
        let index;
        if(event.key==='ArrowRight')index=(current+1)%tabs.length;
        else if(event.key==='ArrowLeft')index=(current-1+tabs.length)%tabs.length;
        else if(event.key==='Home')index=0;
        else if(event.key==='End')index=tabs.length-1;
        else return;
        event.preventDefault();select(index,true);
      });
    });
    workbench.querySelector('[role="tablist"]').hidden=false;
    workbench.classList.add('is-interactive');
    select(0,false,false);
    workbench.dataset.studioReady='true';
    if('ResizeObserver' in window)new ResizeObserver(measureSelection).observe(tablist);
    document.fonts?.ready.then(measureSelection);
    // A horizontal gesture changes the actual work preview; vertical scrolling stays native.
    let gesture=null,suppressClick=false,clickTimer;
    const clearGesture=()=>{
      if(gesture){gesture.panel.style.removeProperty('translate');gesture.panel.removeAttribute('data-studio-dragging');}
      gesture=null;
    };
    workbench.addEventListener('pointerdown',event=>{
      if(gesture||!event.isPrimary||event.button!==0||!['touch','pen'].includes(event.pointerType))return;
      const panel=event.target.closest('[data-studio-panel]');
      if(!panel||panel.hidden||event.target.closest('button,input,video,summary'))return;
      transition?.cancel();gesture={id:event.pointerId,x:event.clientX,y:event.clientY,panel,dx:0,locked:false};
    },{passive:true});
    workbench.addEventListener('pointermove',event=>{
      if(!gesture||event.pointerId!==gesture.id)return;
      const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y;
      if(!gesture.locked){
        if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){clearGesture();return;}
        if(Math.abs(dx)<12||Math.abs(dx)<Math.abs(dy)*1.25)return;
        gesture.locked=true;
        try{gesture.panel.setPointerCapture(event.pointerId);}catch{/* Synthetic inputs do not own native capture. */}
        gesture.panel.setAttribute('data-studio-dragging','');
      }
      gesture.dx=dx;
      if(!reduced.matches)gesture.panel.style.translate=Math.max(-55,Math.min(55,dx*.25))+'px 0';
    },{passive:true});
    const finishGesture=event=>{
      if(!gesture||event.pointerId!==gesture.id)return;
      const ended=gesture,commit=event.type==='pointerup'&&ended.locked&&Math.abs(ended.dx)>55;
      if(ended.locked){
        suppressClick=true;clearTimeout(clickTimer);clickTimer=setTimeout(()=>{suppressClick=false;},400);
      }
      clearGesture();
      if(commit){
        const direction=getComputedStyle(workbench).direction==='rtl'?-1:1;
        const next=Math.max(0,Math.min(tabs.length-1,active+(ended.dx<0?1:-1)*direction));
        if(next!==active)select(next);
      }
    };
    workbench.addEventListener('pointerup',finishGesture);
    workbench.addEventListener('pointercancel',finishGesture);
    workbench.addEventListener('lostpointercapture',event=>{if(gesture?.id===event.pointerId&&event.target===gesture.panel)clearGesture();});
    workbench.addEventListener('click',event=>{if(suppressClick){event.preventDefault();event.stopPropagation();suppressClick=false;}},true);
    reduced.addEventListener('change',()=>{transition?.cancel();heightTransition?.cancel();clearGesture();measureSelection();});
    addEventListener('pagehide',()=>{heightTransition?.cancel();transition?.cancel();clearGesture();clearTimeout(clickTimer);suppressClick=false;});
  }
  // Offscreen geometry pauses instead of running unseen for the full page.
  if('IntersectionObserver' in window){
    const scenes=new IntersectionObserver(entries=>{
      for(const entry of entries)entry.target.toggleAttribute('data-paused',!entry.isIntersecting);
    },{rootMargin:'80px'});
    document.querySelectorAll('.era-silk').forEach(scene=>scenes.observe(scene));
  }
  // Native anchor links keep their URL and keyboard behavior; the index follows reading.
  const caseIndex=document.querySelector('.case-index');
  if(caseIndex){
    const links=[...caseIndex.querySelectorAll('a[href^="#"]')];
    const entries=links.map(link=>({link,section:document.querySelector(link.getAttribute('href'))})).filter(item=>item.section);
    let scheduled=false,intent=null;
    const update=()=>{
      scheduled=false;const edge=Math.max(160,innerHeight*.25);
      const atEdge=entries.filter(item=>item.section.getBoundingClientRect().top<=edge).at(-1);
      if(intent&&(performance.now()>intent.until||atEdge===intent.item))intent=null;
      const current=intent?.item||atEdge;
      for(const item of entries){if(item===current)item.link.setAttribute('aria-current','location');else item.link.removeAttribute('aria-current');}
    };
    const schedule=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update);}};
    caseIndex.addEventListener('click',event=>{
      if(event.defaultPrevented||event.button>0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey)return;
      const link=event.target.closest('a[href]'),item=entries.find(item=>item.link===link);
      if(item){intent={item,until:performance.now()+2000};update();}
    });
    const clearIntent=()=>{if(intent){intent=null;schedule();}};
    addEventListener('scrollend',clearIntent,{passive:true});
    addEventListener('wheel',clearIntent,{passive:true});
    addEventListener('pointerdown',clearIntent,{passive:true});
    addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});update();
  }
})();

/* One local search surface. No model, account or download is required. */
(() => {
  'use strict';
  const root = document.querySelector('[data-sprite]');
  if (!root) return;
  let records, loading;
  const siteURL = new URL('../', document.currentScript.src);
  function loadIndex() {
    if (records) return Promise.resolve();
    if (!loading) {
      loading = Promise.all([
        import(new URL('assets/spotlight-engine.cc3e2aa8cdb3.mjs', siteURL)),
        fetch(new URL('assets/spotlight.11b4f57aeeb3.json', siteURL)).then(response => {
          if (!response.ok) throw new Error('Index unavailable');
          return response.json();
        }),
      ]).then(([, data]) => { records = data; }).catch(error => { loading = undefined; throw error; });
    }
    return loading;
  }
  const launcher=root.querySelector('.sprite-launcher'), panel=root.querySelector('.sprite-panel');
  const input=root.querySelector('input'), results=root.querySelector('.sprite-results');
  const scroller=root.querySelector('.sprite-scroll'), status=root.querySelector('[data-sprite-status]');
  const clear=root.querySelector('[data-sprite-clear-input]'), submit=root.querySelector('button[type="submit"]');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let opened=false,timer,closing,previousFocus,composing=false,committedContext=null;
  const normalize=value=>String(value || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
  function markText(element, text, query) {
    const terms = [...new Set(query.trim().split(/\s+/).filter(Boolean))].sort((a,b)=>b.length-a.length);
    if (!terms.length) { element.textContent = text; return; }
    const escaped = terms.map(term => term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const expression = new RegExp('(' + escaped.join('|') + ')', 'gi');
    for (const part of text.split(expression)) {
      const match = terms.some(term => part.toLocaleLowerCase() === term.toLocaleLowerCase());
      const node = match ? document.createElement('mark') : document.createTextNode(part);
      if (match) node.textContent = part;
      element.append(node);
    }
  }
  function snippet(text, query) {
    const key = query.trim().split(/\s+/).find(term => text.toLowerCase().includes(term.toLowerCase()));
    const match = key ? text.toLowerCase().indexOf(key.toLowerCase()) : 0;
    const start = Math.max(0, match - 32);
    const end = Math.min(text.length, start + 180);
    return (start ? '…' : '') + text.slice(start, end) + (end < text.length ? '…' : '');
  }

  function safeSourceURL(value) {
    try {const url=new URL(value,siteURL);return url.origin===siteURL.origin && ['http:','https:'].includes(url.protocol) ? url.href : null;}
    catch {return null;}
  }
  function focusContent() {
    const target=results.querySelector('h3,h4,.sprite-empty strong');
    if(target){target.tabIndex=-1;target.focus({preventScroll:true});}
  }
  function appendSources(card,sources) {
    const destinations=new Set([...card.querySelectorAll('a[href]')].map(link=>link.href));
    const evidence=sources.filter(record=>{
      const destination=safeSourceURL(record.url);
      if(!destination || destinations.has(destination))return false;
      destinations.add(destination);return true;
    }).slice(0,3);
    if(!evidence.length)return;
    const box=document.createElement('nav');box.className='sprite-sources';box.setAttribute('aria-label','相关内容');
    for(const record of evidence){
      const link=document.createElement('a');link.className='sprite-answer-source';
      link.href=safeSourceURL(record.url);link.textContent=record.title || '查看相关经历';box.append(link);
    }
    card.append(box);
  }
  function drawAnswer(answer,query) {
    const card=document.createElement('article');card.className='sprite-answer';card.dataset.spriteTopic=answer.topic || '';
    const title=document.createElement('h3');title.className='sprite-answer-title';title.textContent=answer.title || '搜索结果';card.append(title);
    const facts=(answer.facts || []).slice(0,4);
    const paragraphs=(answer.paragraphs || []).filter(text=>!facts.some(fact=>normalize(text).includes(normalize(fact.value)))).slice(0,Math.min(4,(answer.title || '').split(' · ').length));
    for(const paragraph of paragraphs){
      const p=document.createElement('p');p.className='sprite-answer-paragraph';
      const clean=paragraph.trim();
      const boundary=Math.max(clean.slice(0,180).lastIndexOf('。'),clean.slice(0,180).lastIndexOf('；'));
      p.textContent=clean.length<=180?clean:clean.slice(0,boundary>50?boundary+1:180).trim()+'…';card.append(p);
    }
    if(facts.length){
      const list=document.createElement('dl');list.className='sprite-facts';
      for(const fact of facts){const row=document.createElement('div'),label=document.createElement('dt'),value=document.createElement('dd');label.textContent=fact.label;value.textContent=fact.value;row.append(label,value);list.append(row);}
      card.append(list);
    }
    if(/简历|履历|resume|\bcv\b/i.test(query)){
      const link=document.createElement('a');link.className='sprite-resume';link.dataset.spriteAction='resume';link.textContent='下载简历';
      const existing=[...document.querySelectorAll('a[href]')].map(a=>safeSourceURL(a.href)).find(url=>url && /\/resume(?:-[a-f0-9]{12})?\.pdf$/.test(new URL(url).pathname));
      link.href=existing || new URL('resume-beb4a3432690.pdf',siteURL).href;link.download='马嘉程_个人简历.pdf';card.append(link);
    }
    appendSources(card,answer.sources || []);return card;
  }
  function render(query,{commit=false}={}) {
    clearTimeout(timer);
    const value=query.trim().slice(0,140);
    clear.hidden=!input.value;submit.disabled=!value;
    results.replaceChildren();results.setAttribute('aria-busy','false');
    root.dataset.spriteState=value?'results':'welcome';
    if(!value){status.textContent='';committedContext=null;return;}
    if (!records) {
      status.textContent = '正在载入搜索';
      results.setAttribute('aria-busy', 'true');
      loadIndex().then(() => {
        if (!opened || input.value.trim().slice(0, 140) !== value) return;
        render(input.value, { commit });
        if (commit) focusContent();
      }).catch(() => {
        status.textContent = '搜索暂不可用';
        results.setAttribute('aria-busy', 'false');
      });
      return;
    }
    if(!window.XiaoChengBrain?.search){
      root.dataset.spriteState='empty';status.textContent='搜索暂不可用';
      const message=document.createElement('p');message.className='sprite-unavailable';message.textContent='搜索暂不可用，请刷新后重试。';results.append(message);return;
    }
    let answer=null;
    try{answer=window.XiaoChengBrain?.answer(value,records,committedContext || {}) || null;}catch{}
    const found=window.XiaoChengBrain?.search?.(answer?.resolvedQuery || value,records,{limit:4}) || [];
    if(answer){
      results.append(drawAnswer(answer,value));
      status.textContent='已找到'+answer.title;
      if(commit)committedContext={topic:answer.topic,query:answer.resolvedQuery || value};
    }else if(found.length){
      status.textContent='找到'+found.length+'条相关内容';
      for(const [i,record] of found.entries()){
        const card=document.createElement('article'),title=document.createElement('h4'),link=document.createElement('a'),text=document.createElement('p');
        card.className='sprite-result';card.style.animationDelay=`${i*25}ms`;
        link.href=safeSourceURL(record.url);markText(link,record.title,value);title.append(link);
        markText(text,snippet(record.text,value),value);card.append(title,text);results.append(card);
      }
    }else{
      root.dataset.spriteState='empty';status.textContent='暂无结果';
      const card=document.createElement('div'),title=document.createElement('strong'),text=document.createElement('p');
      card.className='sprite-empty';title.textContent='暂无结果';text.textContent='换个关键词，或描述想找的内容。';card.append(title,text);results.append(card);
    }
    scroller.scrollTop=0;
  }
  function syncTone(){
    if(!opened)return;
    const hero=document.querySelector('.home-page .era-hero'),box=panel.getBoundingClientRect();
    const scene=hero?.getBoundingClientRect(),center=box.top+Math.min(box.height/2,180);
    root.dataset.spriteTone=scene&&scene.top<=center&&scene.bottom>=center?'dark':'light';
  }
  function open() {
    if(document.querySelector('dialog[open]'))return;
    if (opened) { input.focus({preventScroll:true}); return; }
    loadIndex().catch(() => {});
    opened = true; clearTimeout(closing); previousFocus = document.activeElement;
    panel.hidden = false; panel.inert = false;
    launcher.setAttribute('aria-expanded','true');
    requestAnimationFrame(() => {if (opened) root.setAttribute('data-open','');});
    // Focus in the original gesture so the iOS keyboard can open naturally.
    input.focus({preventScroll:true}); fitKeyboard();syncTone();
  }
  function close(restoreFocus=true) {
    if (!opened) return;
    opened = false; root.removeAttribute('data-open'); panel.inert = true;
    launcher.setAttribute('aria-expanded','false'); input.blur();
    if(restoreFocus)(previousFocus && previousFocus.isConnected && previousFocus!==document.body && previousFocus!==document.documentElement ? previousFocus : launcher).focus({preventScroll:true});
    closing = setTimeout(() => { if (!opened) panel.hidden = true; }, reduced.matches ? 0 : 240);
    ['max-height','height','bottom','top','min-height'].forEach(property=>panel.style.removeProperty(property));root.removeAttribute('data-keyboard');
  }

  for(const trigger of document.querySelectorAll('[data-open-companion]')){
    trigger.hidden=false;trigger.setAttribute('aria-controls',panel.id);trigger.setAttribute('aria-haspopup','dialog');
    trigger.addEventListener('click',()=>{open();const query=trigger.dataset.openCompanion?.trim();if(query){input.value=query;render(query,{commit:true});input.blur();focusContent();}});
  }
  root.querySelector('.sprite-close').addEventListener('click',close);
  document.addEventListener('pointerdown',event=>{if(opened && !panel.contains(event.target) && !launcher.contains(event.target))close();});
  // This is a nonmodal search: Tab can return to the page, and the surface
  // dismisses without pulling focus away from the visitor's next control.
  document.addEventListener('focusin',event=>{if(opened && !panel.contains(event.target))close(false);});
  results.addEventListener('click',event=>{
    const link=event.target.closest('a[href]');
    if(!link || event.defaultPrevented || event.button!==0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)return;
    const destination=new URL(link.href);
    if(destination.origin!==siteURL.origin || link.hasAttribute('download'))return;
    close(false);
    // Native anchors own scrolling and history. Also focus a repeated same-page
    // destination, where hashchange may not fire a second time.
    if(destination.pathname===location.pathname && destination.hash){
      requestAnimationFrame(()=>{
        let section;try{section=document.getElementById(decodeURIComponent(destination.hash.slice(1)));}catch{return;}
        const target=section?.querySelector('h1,h2,h3') || section;
        if(!target)return;
        const old=target.getAttribute('tabindex');target.tabIndex=-1;target.focus({preventScroll:true});
        target.addEventListener('blur',()=>{if(old===null)target.removeAttribute('tabindex');else target.setAttribute('tabindex',old);},{once:true});
      });
    }
  });
  launcher.addEventListener('click',event=>{if(suppressClick){event.preventDefault();return;}opened?close():open();});
  root.querySelector('form').addEventListener('submit',event=>{
    event.preventDefault();clearTimeout(timer);if(composing || event.isComposing || !input.value.trim())return;
    render(input.value,{commit:true});input.blur();focusContent();
  });
  input.addEventListener('input',()=>{
    clear.hidden=!input.value;submit.disabled=!input.value.trim();
    if(composing)return;clearTimeout(timer);results.setAttribute('aria-busy','true');timer=setTimeout(()=>render(input.value),120);
  });
  input.addEventListener('compositionstart',()=>{composing=true;clearTimeout(timer);});
  input.addEventListener('compositionend',()=>{composing=false;render(input.value);});
  clear.addEventListener('click',()=>{clearTimeout(timer);input.value='';committedContext=null;render('');input.focus({preventScroll:true});});
  panel.addEventListener('keydown',event=>{
    if(event.altKey || event.metaKey || event.ctrlKey || event.isComposing || composing || !['ArrowDown','ArrowUp'].includes(event.key))return;
    const targets=[...results.querySelectorAll('summary,a')].filter(element=>{
      if(!element.getClientRects().length)return false;
      for(let owner=element.parentElement;owner && owner!==results;owner=owner.parentElement)if(owner.tagName==='DETAILS' && !owner.open && owner.querySelector('summary')!==element)return false;
      return true;
    });
    if(!targets.length)return;
    const index=targets.indexOf(document.activeElement),headingFocused=document.activeElement?.matches('h3,h4,.sprite-empty strong');
    if(document.activeElement!==input && index<0 && !headingFocused)return;
    if(document.activeElement===input && event.key==='ArrowUp')return;
    event.preventDefault();const next=index+(event.key==='ArrowDown'?1:-1);
    if(next<0)input.focus({preventScroll:true});else{const target=targets[Math.min(next,targets.length-1)];target.focus({preventScroll:true});target.scrollIntoView({block:'nearest'});}
  });
  document.addEventListener('keydown',event=>{
    if(event.isComposing || composing || event.defaultPrevented)return;
    if(event.key==='Escape' && opened){event.preventDefault();close();}

  });
  render('');
  launcher.hidden=false;
  const pauseCharacter=()=>root.toggleAttribute('data-sprite-paused',document.hidden);
  document.addEventListener('visibilitychange',pauseCharacter);pauseCharacter();
  // Keep the search field above the software keyboard without scrolling the page.
  function fitKeyboard() {
    if (!opened || !window.visualViewport) return;
    const viewport=window.visualViewport;
    const overlap=Math.max(0,window.innerHeight-viewport.height-viewport.offsetTop);
    const keyboard=overlap>100;
    root.toggleAttribute('data-keyboard',keyboard);
    if (keyboard || window.innerWidth<800) {
      const gutter=viewport.height<280?8:12;
      panel.style.top=`${Math.max(0,viewport.offsetTop)+gutter}px`;
      panel.style.bottom='auto';
      panel.style.maxHeight=`${Math.max(0,viewport.height-2*gutter)}px`;
    } else {['top','bottom','max-height'].forEach(property=>panel.style.removeProperty(property));}
  }
  window.visualViewport?.addEventListener('resize',fitKeyboard);
  window.visualViewport?.addEventListener('scroll',fitKeyboard);
  window.visualViewport?.addEventListener('resize',syncTone);
  addEventListener('scroll',syncTone,{passive:true});addEventListener('resize',syncTone,{passive:true});
  // The outer anchor stays still for tapping; only the inner pearl floats.
  let drag, suppressClick = false, draggedPosition = false;
  function boundaries() {
    const dock = document.querySelector('[data-glass-dock]')?.getBoundingClientRect();
    const floor = dock && dock.top > innerHeight / 2 ? dock.top - 12 : innerHeight - 12;
    return {minX:8,maxX:Math.max(8,innerWidth-launcher.offsetWidth-8),minY:8,maxY:Math.max(8,floor-launcher.offsetHeight)};
  }
  function position(x,y) {
    const b = boundaries();
    root.style.left = `${Math.min(b.maxX,Math.max(b.minX,x))}px`;
    root.style.top = `${Math.min(b.maxY,Math.max(b.minY,y))}px`;
    root.style.right = 'auto';root.style.bottom = 'auto';draggedPosition = true;
  }
  launcher.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    const box = launcher.getBoundingClientRect();
    drag = {id:event.pointerId,x:event.clientX,y:event.clientY,left:box.left,top:box.top,moved:false};
    suppressClick = false; launcher.setPointerCapture(event.pointerId);
  });
  launcher.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.id) return;
    const dx = event.clientX-drag.x,dy = event.clientY-drag.y;
    if (!drag.moved && Math.hypot(dx,dy) < 7) return;
    drag.moved = true;suppressClick = true;root.setAttribute('data-dragging','');
    position(drag.left+dx,drag.top+dy);
  });
  function finishDrag(event) {
    if (!drag || event.pointerId !== drag.id) return;
    const moved = drag.moved;drag = null;root.removeAttribute('data-dragging');
    if (moved) {
      const box = launcher.getBoundingClientRect();
      position(box.left+box.width/2 < innerWidth/2 ? 10 : innerWidth-box.width-10,box.top);
      try {sessionStorage.setItem('mjc-sprite-position',JSON.stringify({side:box.left+box.width/2<innerWidth/2?'left':'right',ratio:box.top/Math.max(1,innerHeight)}));} catch {}
      setTimeout(()=>{suppressClick=false;},100);
    }
  }
  launcher.addEventListener('pointerup', finishDrag);
  launcher.addEventListener('pointercancel', finishDrag);
  launcher.addEventListener('lostpointercapture', event => {if(drag)finishDrag(event);});
  try {
    const saved = JSON.parse(sessionStorage.getItem('mjc-sprite-position'));
    if (saved && ['left','right'].includes(saved.side) && Number.isFinite(saved.ratio)) position(saved.side==='left'?10:innerWidth-launcher.offsetWidth-10,saved.ratio*innerHeight);
  } catch {}
  window.addEventListener('resize', () => {
    if(draggedPosition){const box=launcher.getBoundingClientRect();position(box.left,box.top);} fitKeyboard();
  });
  launcher.addEventListener('pointermove', event => {
    if (drag || reduced.matches) return;
    const box = launcher.getBoundingClientRect();
    launcher.style.setProperty('--sprite-eye-x',`${(event.clientX-box.left-box.width/2)/14}px`);
    launcher.style.setProperty('--sprite-eye-y',`${(event.clientY-box.top-box.height/2)/18}px`);
  });
  launcher.addEventListener('pointerleave',()=>{launcher.style.setProperty('--sprite-eye-x','0px');launcher.style.setProperty('--sprite-eye-y','0px');});
})();

/* One input owner for surface lighting and pressure; no scroll interception. */
(() => {
  'use strict';
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const coarse=matchMedia('(hover: none)');
  const root=document.documentElement;
  const surfaces=[...document.querySelectorAll('.practice-glass,.work-card,.case-study,.contact-identity,.contact-methods,.studio-workbench')];
  for(const surface of surfaces)surface.dataset.materialSurface='';
  const timers=new Map();
  let held=null,surfaceHeld=null,frame=0,pending=null;
  const selector='.button,.practice-link,summary,.contact-copy,.dialog-close,.sprite-close,.sprite-form button,.sprite-answer-source,.sprite-resume,[data-control-glass] a,[data-control-glass] button,.film-button,.film-chapters button';
  const targetFor=target=>target?.closest?.(selector);
  function illuminate(node,x,y){
    const b=node.getBoundingClientRect();
    const nx=Math.max(0,Math.min(1,(x-b.left)/Math.max(1,b.width)));
    const ny=Math.max(0,Math.min(1,(y-b.top)/Math.max(1,b.height)));
    node.style.setProperty('--press-x',(nx*100).toFixed(1)+'%');
    node.style.setProperty('--press-y',(ny*100).toFixed(1)+'%');
    node.style.setProperty('--press-rx',((.5-ny)*3).toFixed(2)+'deg');
    node.style.setProperty('--press-ry',((nx-.5)*4).toFixed(2)+'deg');
  }
  function finish(animate=false){
    if(!held)return;
    const node=held.node;held=null;node.removeAttribute('data-glass-pressed');
    clearTimeout(timers.get(node));timers.delete(node);
    if(animate&&!reduced.matches&&!document.hidden){
      node.dataset.glassReleased='true';
      timers.set(node,setTimeout(()=>{node.removeAttribute('data-glass-released');timers.delete(node);},500));
    }else node.removeAttribute('data-glass-released');
  }
  function releaseSurface(animate=false){
    if(!surfaceHeld)return;
    const node=surfaceHeld.node;surfaceHeld=null;node.removeAttribute('data-surface-pressed');
    clearTimeout(timers.get(node));timers.delete(node);
    if(animate&&!reduced.matches&&!document.hidden){
      node.setAttribute('data-surface-released','');
      timers.set(node,setTimeout(()=>{node.removeAttribute('data-surface-released');timers.delete(node);},650));
    }
  }
  function press(node,id,x,y){
    finish();clearTimeout(timers.get(node));timers.delete(node);node.removeAttribute('data-glass-released');
    illuminate(node,x,y);held={node,id,x,y};node.dataset.glassPressed='true';
  }
  document.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0)return;
    const node=targetFor(event.target);
    if(!node){
      const surface=event.target.closest?.('[data-material-surface]');
      if(surface&&!event.target.closest('input,select,textarea,video,a,button,summary')){
        releaseSurface();const box=surface.getBoundingClientRect();
        surface.style.setProperty('--surface-x',((event.clientX-box.left)/box.width*100)+'%');
        surface.style.setProperty('--surface-y',((event.clientY-box.top)/box.height*100)+'%');
        surfaceHeld={node:surface,id:event.pointerId,x:event.clientX,y:event.clientY};surface.setAttribute('data-surface-pressed','');
      }
      return;
    }
    if(node.disabled)return;
    press(node,event.pointerId,event.clientX,event.clientY);
  },{passive:true});
  document.addEventListener('pointermove',event=>{
    if(surfaceHeld?.id===event.pointerId&&Math.hypot(event.clientX-surfaceHeld.x,event.clientY-surfaceHeld.y)>10)releaseSurface();
    if(held?.id===event.pointerId){
      if(Math.hypot(event.clientX-held.x,event.clientY-held.y)>12){finish();return;}
      illuminate(held.node,event.clientX,event.clientY);
    }
    if(reduced.matches||coarse.matches||document.hidden||event.pointerType!=='mouse')return;
    const surface=event.target.closest?.('[data-material-surface]');if(!surface)return;
    pending={surface,x:event.clientX,y:event.clientY};
    if(!frame)frame=requestAnimationFrame(()=>{
      frame=0;if(!pending||document.hidden||reduced.matches)return;
      const {surface,x,y}=pending,b=surface.getBoundingClientRect();pending=null;
      const nx=Math.max(0,Math.min(1,(x-b.left)/b.width)),ny=Math.max(0,Math.min(1,(y-b.top)/b.height));
      surface.style.setProperty('--surface-x',(nx*100).toFixed(1)+'%');surface.style.setProperty('--surface-y',(ny*100).toFixed(1)+'%');
      surface.style.setProperty('--surface-rx',((.5-ny)*1.7).toFixed(2)+'deg');surface.style.setProperty('--surface-ry',((nx-.5)*2.2).toFixed(2)+'deg');
      surface.setAttribute('data-surface-hover','');
    });
  },{passive:true});
  document.addEventListener('pointerup',event=>{if(held?.id===event.pointerId)finish(true);if(surfaceHeld?.id===event.pointerId)releaseSurface(true);},{passive:true});
  document.addEventListener('pointercancel',()=>{finish();releaseSurface();},{passive:true});
  document.addEventListener('keydown',event=>{
    if(event.defaultPrevented||event.repeat||event.isComposing||event.metaKey||event.ctrlKey||event.altKey||!['Enter',' '].includes(event.key))return;
    const node=targetFor(event.target);if(!node||node.disabled||node.matches('a')&&event.key===' ')return;
    const b=node.getBoundingClientRect();press(node,'keyboard',b.left+b.width/2,b.top+b.height/2);
  });
  document.addEventListener('keyup',event=>{if(held?.id==='keyboard'&&['Enter',' '].includes(event.key))finish(true);});
  document.addEventListener('focusout',()=>{if(held?.id==='keyboard')finish();});
  for(const surface of surfaces){
    surface.addEventListener('pointerleave',()=>{
      if(pending?.surface===surface)pending=null;
      resetSurface(surface);
    });
  }
  function resetSurface(surface){
    surface.style.removeProperty('--surface-rx');
    surface.style.removeProperty('--surface-ry');
    surface.removeAttribute('data-surface-hover');
  }
  function clear(){
    finish();releaseSurface();cancelAnimationFrame(frame);frame=0;pending=null;
    for(const [node,timer]of timers){clearTimeout(timer);node.removeAttribute('data-glass-released');node.removeAttribute('data-surface-released');}timers.clear();
    for(const surface of surfaces)resetSurface(surface);
  }
  function lifecycle(){root.dataset.scenePaused=String(document.hidden);if(document.hidden)clear();}
  document.addEventListener('visibilitychange',lifecycle);
  addEventListener('scroll',()=>{finish();releaseSurface();},{passive:true,capture:true});
  addEventListener('blur',clear);addEventListener('pagehide',()=>{root.dataset.scenePaused='true';clear();});
  addEventListener('pageshow',lifecycle);reduced.addEventListener('change',clear);coarse.addEventListener('change',clear);lifecycle();
})();

(() => {
  const select = document.querySelector('select[data-appearance]');
  if (!select) return;
  select.value = document.documentElement.dataset.appearance;
  select.addEventListener('change', () => window.PortfolioAppearance.apply(select.value, true));
  window.addEventListener('portfolio:appearance', () => {
    select.value = document.documentElement.dataset.appearance;
  });
})();

(() => {
  'use strict';

  const root = document.documentElement;
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const settingsKey = 'mjc-os-settings';
  const defaults = { accent: 'ice', text: 'normal', language: 'zh', reduce: false, haptics: false, music: false };
  const choices = { accent: ['ice', 'mint', 'violet'], text: ['normal', 'large', 'wide'], language: ['zh', 'en'] };
  let stored = {};
  try { stored = JSON.parse(localStorage.getItem(settingsKey)) || {}; } catch {}
  const preferences = { ...defaults };
  for (const key of Object.keys(defaults)) {
    if (choices[key]?.includes(stored[key]) || typeof stored[key] === 'boolean' && typeof defaults[key] === 'boolean') {
      preferences[key] = stored[key];
    }
  }

  if (root.lang === 'en') preferences.language = 'en';

  const reduced = () => motion.matches || preferences.reduce;
  const saveData = () => navigator.connection?.saveData === true;
  function applySettings() {
    root.dataset.accent = preferences.accent;
    root.dataset.textSize = preferences.text;
    root.dataset.motion = reduced() ? 'reduced' : 'full';
    root.dataset.osLanguage = preferences.language;
    document.querySelectorAll('[data-lang-en]').forEach(node => {
      if (!node.dataset.langZh) node.dataset.langZh = node.textContent;
      node.textContent = preferences.language === 'en' ? node.dataset.langEn : node.dataset.langZh;
    });
    window.dispatchEvent(new Event('portfolio:settings'));
  }
  const savePreferences = () => { try { localStorage.setItem(settingsKey, JSON.stringify(preferences)); } catch {} };
  const settings = document.querySelectorAll('[data-os-setting]');
  for (const field of settings) {
    const key = field.dataset.osSetting;
    if (field.type === 'checkbox') field.checked = preferences[key];
    else field.value = preferences[key];
    field.addEventListener('change', () => {
      preferences[key] = field.type === 'checkbox' ? field.checked : field.value;
      savePreferences();
      applySettings();
      if (key === 'language') {
        if (preferences.language === 'en' && root.lang !== 'en') location.assign('/en/');
        if (preferences.language === 'zh' && root.lang === 'en') location.assign('/');
      }
    });
  }
  applySettings();
  motion.addEventListener?.('change', applySettings);
  document.querySelectorAll('[data-os-enhancement]').forEach(node => { node.hidden = false; });

  const rail = document.querySelector('[data-os-rail]');
  const dock = document.querySelector('[data-glass-dock]');
  function scrollState() {
    const compact = scrollY > 90;
    rail?.toggleAttribute('data-compact', compact);
    dock?.toggleAttribute('data-compact', compact);
  }
  scrollState();
  addEventListener('scroll', scrollState, { passive: true });

  const island = document.querySelector('[data-os-island]');
  const notice = island?.querySelector('[data-os-notice]');
  const progress = island?.querySelector('progress');
  const film = document.querySelector('#intro-video');
  const musicButton = document.querySelector('[data-os-music]');
  let audio, expiry, message = '';
  function islandState() {
    if (!island) return;
    const filmPlaying = film && !film.paused && !film.ended;
    const musicPlaying = audio && !audio.paused && !audio.ended;
    island.hidden = !(message || filmPlaying || musicPlaying);
    notice.textContent = message || (filmPlaying ? '冰之圣殿' : musicPlaying ? '音乐播放中' : '');
    progress.hidden = !filmPlaying || !Number.isFinite(film.duration);
    if (!progress.hidden) {
      progress.max = film.duration;
      progress.value = film.currentTime;
    }
  }
  addEventListener('portfolio:feedback', event => {
    message = String(event.detail);
    clearTimeout(expiry);
    islandState();
    expiry = setTimeout(() => { message = ''; islandState(); }, 2400);
  });
  if (musicButton?.dataset.osMusic) {
    if (preferences.music) musicButton.textContent = '继续播放音乐';
    musicButton.addEventListener('click', async () => {
      if (!audio) {
        audio = new Audio(musicButton.dataset.osMusic);
        audio.loop = true;
        for (const event of ['play', 'pause', 'ended']) audio.addEventListener(event, () => {
          const playing = !audio.paused;
          musicButton.setAttribute('aria-pressed', String(playing));
          musicButton.textContent = playing ? '暂停音乐' : '播放音乐';
          islandState();
        });
      }
      if (!audio.paused) { preferences.music = false; savePreferences(); audio.pause(); }
      else {
        film?.pause();
        try { await audio.play(); preferences.music = true; savePreferences(); }
        catch { window.dispatchEvent(new CustomEvent('portfolio:feedback', { detail: '音乐暂不可播放' })); }
      }
    });
  } else if (musicButton) musicButton.hidden = true;
  for (const event of ['play', 'pause', 'ended', 'timeupdate']) film?.addEventListener(event, () => {
    if (event === 'play') audio?.pause();
    islandState();
  });
  addEventListener('pagehide', () => audio?.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) audio?.pause(); });

  function detent(sheet, full) {
    sheet.toggleAttribute('data-full', full);
    sheet.querySelector('[data-sheet-handle]').setAttribute('aria-pressed', String(full));
  }
  for (const sheet of document.querySelectorAll('[data-sheet]')) {
    const handle = sheet.querySelector('[data-sheet-handle]');
    let drag, dragged = false;
    const clear = () => sheet.style.removeProperty('--sheet-offset');
    handle.addEventListener('pointerdown', event => {
      if (!event.isPrimary || event.button !== 0) return;
      dragged = false;
      drag = { id: event.pointerId, y: event.clientY, lastY: event.clientY, lastAt: performance.now(), velocity: 0 };
      handle.setPointerCapture(event.pointerId);
    });
    handle.addEventListener('pointermove', event => {
      if (!drag || drag.id !== event.pointerId) return;
      const now = performance.now(), delta = event.clientY - drag.y;
      drag.velocity = (event.clientY - drag.lastY) / Math.max(1, now - drag.lastAt);
      drag.lastY = event.clientY;
      drag.lastAt = now;
      if (Math.abs(delta) > 8) dragged = true;
      const distance = delta < 0 ? -Math.sqrt(Math.abs(delta)) * 3 : Math.min(delta, sheet.clientHeight * .70);
      if (!reduced() && dragged) sheet.style.setProperty('--sheet-offset', distance + 'px');
    });
    handle.addEventListener('pointerup', event => {
      if (!drag || drag.id !== event.pointerId) return;
      const delta = event.clientY - drag.y;
      const glide = performance.now() - drag.lastAt < 80 ? Math.max(-50, Math.min(50, drag.velocity * 80)) : 0;
      const distance = delta + glide;
      drag = null;
      clear();
      if (!dragged) return;
      if (distance < -36) detent(sheet, true);
      if (distance > 52 && sheet.hasAttribute('data-full')) detent(sheet, false);
      else if (distance > 76) sheet.querySelector('[data-dialog-close]').click();
    });
    handle.addEventListener('pointercancel', () => { drag = null; dragged = false; clear(); });
    handle.addEventListener('click', event => {
      if (event.detail !== 0 && dragged) { dragged = false; return; }
      detent(sheet, !sheet.hasAttribute('data-full'));
    });
    sheet.addEventListener('close', () => detent(sheet, false));
  }

  const shortcutSheet = document.getElementById('dock-actions');
  const shortcuts = shortcutSheet?.querySelector('[data-dock-shortcuts]');
  let press, timer, consumed;
  function cancelPress() { clearTimeout(timer); press = null; }
  function showShortcuts(link) {
    if (!shortcuts) return;
    const current = document.createElement('a');
    current.href = link.href;
    current.textContent = link.textContent.trim();
    const all = [...dock.querySelectorAll('a[data-dock-link]')].filter(item => item !== link).map(item => {
      const button = document.createElement('a');
      button.href = item.href;
      button.textContent = item.textContent.trim();
      return button;
    });
    shortcuts.replaceChildren(current, ...all);
    if (window.PortfolioDialogs?.open(shortcutSheet, link) && preferences.haptics) navigator.vibrate?.(14);
  }
  dock?.addEventListener('pointerdown', event => {
    const link = event.target.closest('a[data-dock-link]');
    if (!link || !event.isPrimary || event.button !== 0) return;
    consumed = false;
    press = { x: event.clientX, y: event.clientY };
    timer = setTimeout(() => { cancelPress(); consumed = true; showShortcuts(link); }, 490);
  }, { passive: true });
  dock?.addEventListener('pointermove', event => {
    if (press && Math.hypot(event.clientX - press.x, event.clientY - press.y) > 10) cancelPress();
  }, { passive: true });
  for (const event of ['pointerup', 'pointercancel', 'pointerleave']) addEventListener(event, cancelPress, { passive: true });
  dock?.addEventListener('click', event => {
    if (consumed && event.detail !== 0) {
      event.preventDefault();
      event.stopImmediatePropagation();
      consumed = false;
    }
  }, true);
  dock?.addEventListener('keydown', event => {
    const link = event.target.closest('a[data-dock-link]');
    if (link && (event.key === 'ContextMenu' || event.key === 'F10' && event.shiftKey)) {
      event.preventDefault();
      showShortcuts(link);
    }
  });

  const searchTrigger = document.querySelector('.os-rail [data-open-companion]');
  document.addEventListener('keydown', event => {
    if (event.isComposing || event.altKey || event.shiftKey || !(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== 'k') return;
    if (!searchTrigger || document.querySelector('dialog[open]')) return;
    event.preventDefault();
    searchTrigger.click();
  });
  const pull = document.querySelector('[data-pull-search]');
  let starting;
  pull?.addEventListener('pointerdown', event => {
    if (event.pointerType === 'touch' && event.clientX > 30 && event.clientX < innerWidth - 30) {
      starting = { x: event.clientX, y: event.clientY };
      pull.setPointerCapture(event.pointerId);
    }
  });
  pull?.addEventListener('pointerup', event => {
    if (starting && event.clientY - starting.y > 42 && Math.abs(event.clientX - starting.x) < 40) searchTrigger?.click();
    starting = null;
  });
  pull?.addEventListener('pointercancel', () => { starting = null; });

  const continueGame = document.querySelector('[data-continue-game]');
  if (continueGame) {
    function hasSave() {
      try {
        return ['sprout-story-v5', 'sprout-story-v4'].some(key => {
          const save = JSON.parse(localStorage.getItem(key));
          return save && [4, 5, 6].includes(save.schema) && Number.isInteger(save.cleared) &&
            save.cleared > 0 && save.cleared <= (save.schema === 4 ? 12 : 20) &&
            (save.stars === undefined || Array.isArray(save.stars) && save.stars.every(n => Number.isInteger(n) && n >= 0 && n <= 3));
        });
      } catch { return false; }
    }
    const updateContinue = () => { continueGame.hidden = !hasSave(); };
    updateContinue();
    addEventListener('pageshow', updateContinue);
    addEventListener('storage', updateContinue);
  }

  addEventListener('portfolio:polish', () => {
    if (reduced() || saveData() || !('IntersectionObserver' in window)) return;
    const observeStats = new IntersectionObserver(entries => {
      for (const { target, isIntersecting } of entries) {
        if (!isIntersecting) continue;
        observeStats.unobserve(target);
        const original = target.textContent;
        const token = original.match(/\d[\d,]*/)?.[0];
        if (!token) continue;
        const number = Number(token.replaceAll(',', ''));
        target.setAttribute('aria-label', original);
        const start = performance.now();
        function animate(now) {
          const elapsed = Math.min(1, (now - start) / 620);
          if (elapsed === 1 || reduced() || document.hidden) { target.textContent = original; return; }
          const current = Math.round(number * (1 - (1 - elapsed) ** 3));
          target.textContent = original.replace(token, token.includes(',') ? current.toLocaleString('zh-CN') : String(current));
          requestAnimationFrame(animate);
        }
        requestAnimationFrame(animate);
      }
    }, { threshold: .65 });
    document.querySelectorAll('[data-roll]').forEach(value => observeStats.observe(value));
  }, { once: true });

  const splash = document.querySelector('[data-lockscreen]');
  if (splash && !reduced() && !saveData() && !location.hash) {
    let first = false;
    try {
      first = !localStorage.getItem('mjc-lockscreen-seen');
      if (first) localStorage.setItem('mjc-lockscreen-seen', '1');
    } catch {}
    if (first) {
      splash.querySelector('.os-lock-time').textContent = new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit' }).format(new Date());
      splash.hidden = false;
      const dismiss = () => { splash.hidden = true; };
      splash.querySelector('[data-lock-skip]').addEventListener('click', dismiss);
      setTimeout(dismiss, 1120);
      document.addEventListener('focusin', event => { if (!splash.contains(event.target)) dismiss(); }, { once: true });
    }
  }
})();

(() => {
  const key = 'mjc-shared-card';
  const root = document.documentElement;
  const pathKey = path => path.replace(/(?:index\.html)?$/, '').replace(/\/$/, '');
  const disabled = () => root.dataset.motion === 'reduced' || matchMedia('(prefers-reduced-motion: reduce)').matches;
  const native = 'onpageswap' in window && 'onpagereveal' in window;
  const heading = document.querySelector('[data-shared-target], .detail-hero, .ice-theater .film-heading, .story-page h1');
  let active, lastCard, outgoing = false;

  function settleNativeTransition(event) {
    const transition = event.viewTransition;
    if (!transition) return;
    // Keep the CSS opt-in stable. Cancel the current transition when the
    // motion preference changes, without leaving a rejected browser promise.
    transition.ready.catch(() => {});
    transition.finished.catch(() => {});
    transition.updateCallbackDone.catch(() => {});
    if (disabled()) transition.skipTransition();
  }
  addEventListener('pageswap', settleNativeTransition);
  addEventListener('pagereveal', settleNativeTransition);

  function remember(element, path, card, from, returning) {
    const { left, top, width, height } = element.getBoundingClientRect();
    const record = { path, x: left, y: top, width, height, start: Date.now(), card, from, returning };
    try { sessionStorage.setItem(key, JSON.stringify(record)); } catch {}
    if (native) {
      if (active && active !== element) active.style.removeProperty('view-transition-name');
      active = element;
      element.style.viewTransitionName = 'portfolio-card';
    }
  }

  document.addEventListener('click', event => {
    const link = event.target.closest('a[href]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.ctrlKey ||
        event.metaKey || event.altKey || event.shiftKey || disabled()) return;
    const url = new URL(link.href, location.href);
    const path = pathKey(url.pathname);
    if (url.origin !== location.origin || path === pathKey(location.pathname)) return;
    if (link.dataset.sharedCard) {
      remember(link, path, link.dataset.sharedCard, pathKey(location.pathname), false);
      outgoing = true;
    } else if (lastCard && heading && path === lastCard.from) {
      remember(heading, path, lastCard.card, pathKey(location.pathname), true);
      outgoing = true;
    }
  }, { passive: true });

  function take() {
    try {
      const previous = JSON.parse(sessionStorage.getItem(key));
      if (previous?.path === pathKey(location.pathname) && Date.now() - previous.start < 3500) {
        sessionStorage.removeItem(key);
        return previous;
      }
    } catch {}
    return null;
  }

  function arrive(useNative) {
    const record = take();
    if (!record || disabled()) return;
    const target = record.returning && typeof record.card === 'string'
      ? [...document.querySelectorAll('a[data-shared-card]')].find(link => link.dataset.sharedCard === record.card)
      : heading;
    if (!target) return;
    if (!record.returning) lastCard = record;
    if (!useNative) { flip(target, record); return; }
    target.style.viewTransitionName = 'portfolio-card';
    addEventListener('pagereveal', event => {
      const clear = () => target.style.removeProperty('view-transition-name');
      const fallback = () => { clear(); if (!disabled()) flip(target, record); };
      if (event.viewTransition) {
        event.viewTransition.ready.catch(fallback);
        event.viewTransition.finished.then(clear, clear);
      } else fallback();
    }, { once: true });
  }

  function flip(destination, record) {
    if (!destination.animate) return;
    const current = destination.getBoundingClientRect();
    if (current.width < 1 || current.height < 1) return;
    const scaleX = Math.max(.35, Math.min(1.3, record.width / current.width));
    const scaleY = Math.max(.35, Math.min(1.3, record.height / current.height));
    const x = Math.max(-180, Math.min(180, record.x - current.x));
    const y = Math.max(-180, Math.min(180, record.y - current.y));
    const animation = destination.animate([
      { transformOrigin: '0 0', transform: 'translate(' + x + 'px,' + y + 'px) scale(' + scaleX + ',' + scaleY + ')', opacity: .55 },
      { transformOrigin: '0 0', transform: 'none', opacity: 1 },
    ], { duration: 360, easing: 'cubic-bezier(.19,1,.22,1)' });
    for (const name of ['pointerdown', 'keydown', 'portfolio:settings']) addEventListener(name, () => animation.cancel(), { once: true });
  }
  arrive(native);
  addEventListener('pagehide', () => {
    if (!outgoing && !disabled() && heading && lastCard) {
      remember(heading, lastCard.from, lastCard.card, pathKey(location.pathname), true);
    }
  });
  addEventListener('pageshow', event => {
    outgoing = false;
    active?.style.removeProperty('view-transition-name');
    if (event.persisted) arrive(false);
  });
})();

(() => {
  const optionGroups = document.querySelectorAll('[data-lenses]');
  if (!optionGroups.length) return;
  const list = document.querySelector('[data-lens-list]');
  if (!list) return;
  const cards = [...list.querySelectorAll(':scope > [data-case-id]')];
  if (!cards.length) return;
  for (const group of optionGroups) {
    group.hidden = false;
    group.addEventListener('click', event => {
      const active = event.target.closest('[data-lens]');
      if (!active) return;
      const priority = (active.dataset.lensOrder || '').split(' ').filter(Boolean);
      const rank = id => priority.includes(id) ? priority.indexOf(id) : priority.length;
      const order = [...cards].sort((a, b) => rank(a.dataset.caseId) - rank(b.dataset.caseId));
      for (const card of order) {
        card.toggleAttribute('data-lens-highlight', priority.includes(card.dataset.caseId));
        list.appendChild(card);
      }
      group.querySelectorAll('[data-lens]').forEach(item => item.setAttribute('aria-pressed', String(item === active)));
    });
  }
})();

(() => {
  const serviceWorker = navigator.serviceWorker;
  const update = document.querySelector('[data-pwa-update]');
  if (!serviceWorker || !update || navigator.connection?.saveData || !isSecureContext) return;
  let updating = false;
  let returned = false;
  const check = () => {
    if (!document.hidden && navigator.onLine) serviceWorker.controller?.postMessage({ type: 'CHECK_RELEASE' });
  };
  serviceWorker.addEventListener('message', event => {
    if (returned || event.source?.scriptURL !== new URL('/sw.js', location.origin).href || event.data?.type !== 'OS_ROLLBACK') return;
    returned = true;
    location.replace('/');
  });
  addEventListener('pageshow', check);
  addEventListener('online', check);
  document.addEventListener('visibilitychange', check);
  setInterval(check, 60000);
  function watch(registration) {
    function show() { update.hidden = !(registration.waiting && serviceWorker.controller); }
    function watchInstaller() {
      registration.installing?.addEventListener('statechange', event => {
        if (event.target.state === 'installed') show();
      });
    }
    show();
    check();
    watchInstaller();
    registration.addEventListener('updatefound', watchInstaller);
    update.addEventListener('click', () => {
      if (!registration.waiting || updating) return;
      updating = true; update.disabled = true;
      registration.waiting.postMessage({ type: 'ACTIVATE_UPDATE' });
    });
    serviceWorker.addEventListener('controllerchange', () => {
      if (updating) location.reload();
      else show();
    });
  }
  function register() {
    serviceWorker.register('/sw.js', { scope: '/', updateViaCache: 'none' }).then(watch).catch(() => {});
  }
  let scheduled = false;
  let fallback;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    clearTimeout(fallback);
    removeEventListener('pointerup', schedule);
    removeEventListener('keydown', schedule);
    if ('requestIdleCallback' in window) requestIdleCallback(register, { timeout: 3500 });
    else setTimeout(register, 200);
  }
  function defer() {
    addEventListener('pointerup', schedule, { once: true, passive: true });
    addEventListener('keydown', schedule, { once: true });
    fallback = setTimeout(schedule, 8000);
  }
  if (document.readyState === 'complete') defer();
  else addEventListener('load', defer, { once: true });
})();

(() => {
  const clock = document.querySelector('[data-standby-time]');
  if (clock) {
    const date = document.querySelector('[data-standby-date]');
    const time = new Intl.DateTimeFormat('zh-CN', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
    const day = new Intl.DateTimeFormat('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' });
    function sync() {
      const now = new Date();
      clock.textContent = time.format(now);
      date.textContent = day.format(now);
    }
    sync();
    const timer = setInterval(() => { if (!document.hidden) sync(); }, 1000);
    addEventListener('pagehide', event => { if (!event.persisted) clearInterval(timer); });
    document.addEventListener('visibilitychange', sync);
  }

  const avatar = document.querySelector('[data-avatar-seed]');
  const sprout = document.querySelector('[data-avatar-sprout]');
  if (avatar && sprout) {
    let count = 0, last = 0, timer;
    avatar.addEventListener('click', () => {
      const now = performance.now();
      count = now - last < 1000 ? count + 1 : 1;
      last = now;
      if (count < 5) return;
      count = 0;
      clearTimeout(timer);
      sprout.hidden = false;
      window.dispatchEvent(new CustomEvent('portfolio:feedback', { detail: '萌芽生长了' }));
      timer = setTimeout(() => { sprout.hidden = true; }, 2900);
    });
  }
  const print = document.querySelector('[data-print-page]');
  if (print) {
    print.hidden = false;
    print.addEventListener('click', () => window.print());
  }
  let closed = [];
  addEventListener('beforeprint', () => {
    closed = [...document.querySelectorAll('main details:not([open])')];
    for (const item of closed) item.open = true;
  });
  addEventListener('afterprint', () => {
    for (const item of closed) item.open = false;
    closed = [];
  });
})();

(() => {
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const small = navigator.connection;
  const loader = document.currentScript.src;
  let loaded = document.readyState === 'complete', queued = false, activated = false;

  function allowed() {
    return loaded && !document.hidden && !reduced.matches &&
      root.dataset.motion !== 'reduced' && !small?.saveData;
  }

  function update() {
    if (!allowed()) {
      root.removeAttribute('data-polish');
      return;
    }
    if (queued || root.hasAttribute('data-polish')) return;
    queued = true;
    // Let the stable first frame paint before requesting decorative GPU work.
    requestAnimationFrame(() => requestAnimationFrame(() => {
      const activate = () => {
        queued = false;
        if (!allowed()) return;
        root.dataset.polish = 'ready';
        if (!activated) {
          activated = true;
          if (document.querySelector('[data-era-hero]')) {
            import(new URL('./polish-art.d10f97159592.mjs', loader)).catch(() => {});
          }
        }
        window.dispatchEvent(new Event('portfolio:polish'));
      };
      if ('requestIdleCallback' in window) requestIdleCallback(activate, { timeout: 2000 });
      else setTimeout(activate, 120);
    }));
  }

  if (!loaded) addEventListener('load', () => { loaded = true; update(); }, { once: true });
  document.addEventListener('visibilitychange', update);
  reduced.addEventListener?.('change', update);
  small?.addEventListener?.('change', update);
  addEventListener('portfolio:settings', update);
  update();
})();
