(() => {
  const settings = document.querySelector('.settings');
  const theme = settings.querySelector('[data-theme-choice]');
  const size = settings.querySelector('[data-size-choice]');
  const root = document.documentElement;
  theme.value = root.dataset.theme || 'auto';
  size.value = root.dataset.textSize || 'normal';
  function change(control, property, key, fallback) {
    control.addEventListener('change', () => {
      if (control.value === fallback) delete root.dataset[property];
      else root.dataset[property] = control.value;
      try { localStorage.setItem(key, control.value); } catch {}
    });
  }
  change(theme, 'theme', 'portfolio-theme', 'auto');
  change(size, 'textSize', 'portfolio-size', 'normal');
  settings.querySelectorAll('[data-setting]').forEach(label => { label.hidden = false; });

  document.addEventListener('keydown', event => {
    if (event.key !== 'Escape' || !settings.open) return;
    settings.open = false;
    settings.querySelector('summary').focus();
  });
  document.addEventListener('pointerdown', event => {
    if (settings.open && !settings.contains(event.target)) settings.open = false;
  });
})();

(() => {
  const serviceWorker = navigator.serviceWorker;
  const update = document.querySelector('[data-pwa-update]');
  if (!serviceWorker || !update || navigator.connection?.saveData || !isSecureContext) return;
  let updating = false;
  let returned = false;
  const check = () => {
    if (!document.hidden && navigator.onLine) serviceWorker.controller?.postMessage({ type: 'CHECK_RELEASE' });
  };
  serviceWorker.addEventListener('message', event => {
    if (returned || event.source?.scriptURL !== new URL('/sw.js', location.origin).href || event.data?.type !== 'OS_ROLLBACK') return;
    returned = true;
    location.replace('/');
  });
  addEventListener('pageshow', check);
  addEventListener('online', check);
  document.addEventListener('visibilitychange', check);
  setInterval(check, 60000);
  function watch(registration) {
    function show() { update.hidden = !(registration.waiting && serviceWorker.controller); }
    function watchInstaller() {
      registration.installing?.addEventListener('statechange', event => {
        if (event.target.state === 'installed') show();
      });
    }
    show();
    check();
    watchInstaller();
    registration.addEventListener('updatefound', watchInstaller);
    update.addEventListener('click', () => {
      if (!registration.waiting || updating) return;
      updating = true; update.disabled = true;
      registration.waiting.postMessage({ type: 'ACTIVATE_UPDATE' });
    });
    serviceWorker.addEventListener('controllerchange', () => {
      if (updating) location.reload();
      else show();
    });
  }
  function register() {
    serviceWorker.register('/sw.js', { scope: '/', updateViaCache: 'none' }).then(watch).catch(() => {});
  }
  let scheduled = false;
  let fallback;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    clearTimeout(fallback);
    removeEventListener('pointerup', schedule);
    removeEventListener('keydown', schedule);
    if ('requestIdleCallback' in window) requestIdleCallback(register, { timeout: 3500 });
    else setTimeout(register, 200);
  }
  function defer() {
    addEventListener('pointerup', schedule, { once: true, passive: true });
    addEventListener('keydown', schedule, { once: true });
    fallback = setTimeout(schedule, 8000);
  }
  if (document.readyState === 'complete') defer();
  else addEventListener('load', defer, { once: true });
})();
