/* Progressive portfolio interactions. Include once with defer; no dependencies. */
(() => {
  'use strict';
  const all = (selector, root = document) => [...root.querySelectorAll(selector)];
  const byId = id => id ? document.getElementById(id.replace(/^#/, '')) : null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const focusable = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const isOpen = dialog => Boolean(dialog?.hasAttribute('open'));
  const canFocus = node => node && !node.hidden && node.getClientRects().length > 0;
  const fallbackStates = new WeakMap();
  const modalSupported = typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const openers = new WeakMap();
  const triggers = new WeakMap();
  let activeDialog = null;
  let priorOverflow = '';
  let priorGutter = '';
  const outsideStarts = new WeakMap();

  function finishClose(dialog, restoreFocus = true) {
    if (isOpen(dialog) || activeDialog !== dialog) return;
    all('video, audio', dialog).forEach(media => media.pause());
    const opener = openers.get(dialog);
    triggers.get(dialog)?.setAttribute('aria-expanded', 'false');
    const fallback = fallbackStates.get(dialog);
    if (fallback) {
      fallback.backdrop.remove();
      fallback.background.forEach(({ node, inert, hidden }) => {
        if ('inert' in node) node.inert = inert;
        if (hidden === null) node.removeAttribute('aria-hidden'); else node.setAttribute('aria-hidden', hidden);
      });
      if (fallback.style === null) dialog.removeAttribute('style'); else dialog.setAttribute('style', fallback.style);
      if (fallback.role === null) dialog.removeAttribute('role'); else dialog.setAttribute('role', fallback.role);
      dialog.removeAttribute('aria-modal');
      fallbackStates.delete(dialog);
    }
    document.documentElement.style.overflow = priorOverflow;
    document.documentElement.style.scrollbarGutter = priorGutter;
    activeDialog = null;
    if (restoreFocus && opener?.isConnected && canFocus(opener) && !opener.closest('dialog:not([open])')) opener.focus({ preventScroll: true });
  }
  function close(dialog, restoreFocus = true) {
    if (!isOpen(dialog)) return;
    if (fallbackStates.has(dialog)) dialog.removeAttribute('open');
    else dialog.close();
    // Native close events are queued: settle this session before opening another.
    finishClose(dialog, restoreFocus);
  }
  function open(dialog, opener) {
    if (!dialog || dialog.tagName !== 'DIALOG') return false;
    if (isOpen(dialog)) return true;
    const returnOpener = activeDialog && opener?.closest('dialog') === activeDialog ? openers.get(activeDialog) : opener;
    if (activeDialog && activeDialog !== dialog) close(activeDialog, false);
    openers.set(dialog, returnOpener);
    triggers.set(dialog, opener);
    priorOverflow = document.documentElement.style.overflow;
    priorGutter = document.documentElement.style.scrollbarGutter;
    // Reserve the scrollbar lane so opening a dialog does not shift the page.
    document.documentElement.style.scrollbarGutter = 'stable';
    document.documentElement.style.overflow = 'hidden';
    // Older WebViews still receive a usable, focus-contained dialog.
    let nativeOpened = false;
    if (modalSupported) {
      try { dialog.showModal(); nativeOpened = true; } catch (_) { /* Use the local fallback. */ }
    }
    if (!nativeOpened) {
      const backdrop = document.createElement('div');
      backdrop.setAttribute('aria-hidden', 'true');
      backdrop.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(12,20,32,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)';
      const background = all('body > *').filter(node => node !== dialog && !['SCRIPT', 'STYLE'].includes(node.tagName))
        .map(node => ({ node, inert: node.inert, hidden: node.getAttribute('aria-hidden') }));
      fallbackStates.set(dialog, { backdrop, background, style: dialog.getAttribute('style'), role: dialog.getAttribute('role') });
      background.forEach(({ node }) => { if ('inert' in node) node.inert = true; else node.setAttribute('aria-hidden', 'true'); });
      document.body.append(backdrop);
      backdrop.addEventListener('click', () => close(dialog));
      dialog.setAttribute('open', '');
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      Object.assign(dialog.style, { display: 'block', position: 'fixed', zIndex: '9999', inset: '0', margin: 'auto', overflow: 'auto', maxHeight: 'calc(100% - 24px)' });
    }
    activeDialog = dialog;
    opener?.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => {
      if (activeDialog !== dialog || !isOpen(dialog)) return;
      const target = dialog.querySelector('[autofocus]') ||
        dialog.querySelector('[data-dialog-close], button, a[href], input');
      if (target) target.focus({ preventScroll: true });
      else { dialog.tabIndex = -1; dialog.focus({ preventScroll: true }); }
    });
    return true;
  }

  all('dialog').forEach(dialog => {
    if (!modalSupported) dialog.style.display = 'none';
    dialog.addEventListener('close', () => {
      // Ignore an older queued close if this dialog has already reopened.
      finishClose(dialog);
    });
    const outside = event => {
      const box = dialog.getBoundingClientRect();
      return event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom);
    };
    dialog.addEventListener('pointerdown', event => { outsideStarts.set(dialog, outside(event)); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(dialog); });
    dialog.addEventListener('click', event => {
      // A drag starting inside the dialog must never dismiss it on release.
      const startedOutside = outsideStarts.get(dialog);
      outsideStarts.delete(dialog);
      if (!startedOutside || event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close(dialog);
    });
    all('[data-dialog-close], [data-portrait-close]', dialog).forEach(button => button.addEventListener('click', () => close(dialog)));
  });

  all('[data-dialog-open], [data-portrait-open], [data-image-open]').forEach(opener => {
    const id = opener.dataset.dialogOpen || opener.dataset.imageTarget || 'portrait-dialog';
    const dialog = byId(id);
    if (!dialog) {
      // Keep real hrefs operational; dead buttons should not appear interactive.
      if (opener.tagName === 'BUTTON') opener.hidden = true;
      return;
    }
    opener.setAttribute('aria-controls', dialog.id);
    opener.setAttribute('aria-haspopup', 'dialog');
    opener.setAttribute('aria-expanded', 'false');
    opener.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (opener.hasAttribute('data-image-open')) {
        const image = dialog.querySelector('[data-dialog-image]');
        const source = opener.dataset.imageSrc || opener.getAttribute('href');
        if (image && source) {
          let url;
          try { url = new URL(source, location.href); } catch (_) { return; }
          if (!['https:', 'http:'].includes(url.protocol)) return;
          image.src = url.href;
          image.alt = opener.dataset.imageAlt || opener.querySelector('img')?.alt || '作品图片';
        }
      }
      if (open(dialog, opener)) event.preventDefault();
    });
  });

  document.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.defaultPrevented) return;
    if (activeDialog && event.key === 'Escape') { event.preventDefault(); close(activeDialog); return; }
    if (!activeDialog || !fallbackStates.has(activeDialog)) return;
    if (event.key === 'Tab') {
      const targets = all(focusable, activeDialog).filter(canFocus);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) { event.preventDefault(); activeDialog.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    }
  });

  // No autoplay, scroll hijacking, or automatic audio resumption.
  // Native video controls remain the single playback surface.
  const pauseMedia = () => all('video').forEach(media => media.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMedia(); });
  window.addEventListener('pagehide', pauseMedia);

  // A small, explicit choice illustrates the mechanism; no timed advancement.
  all('.growth-demo').forEach(demo => {
    const buttons = all('button[data-growth-step]', demo);
    const panels = all('[data-growth-panel]', demo);
    if (!buttons.length || !panels.length) return;
    const select = step => {
      const chosen = panels.find(panel => panel.dataset.growthPanel === step);
      if (!chosen) return;
      buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.growthStep === step)));
      panels.forEach(panel => { panel.hidden = panel !== chosen; });
    };
    buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.growthStep)));
    const initial = buttons.find(button => button.getAttribute('aria-pressed') === 'true') || buttons[0];
    select(initial.dataset.growthStep);
    demo.classList.add('is-enhanced');
  });

  document.documentElement.classList.add('js-ready');

  // Content remains visible if JS fails or IntersectionObserver is unsupported.
  const reveal = all('[data-reveal]');
  let observer;
  const settleReveal = () => {
    observer?.disconnect();
    reveal.forEach(node => { node.classList.remove('reveal-pending'); node.classList.add('is-visible'); });
  };
  if (!reduce.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    reveal.forEach(node => {
      // Above-the-fold content is immediately readable, even on a slow device.
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight && box.bottom > 0) node.classList.add('is-visible');
      else { observer.observe(node); node.classList.add('reveal-pending'); }
    });
    document.addEventListener('focusin', event => {
      const section = event.target.closest?.('[data-reveal]');
      if (section) { section.classList.remove('reveal-pending'); section.classList.add('is-visible'); observer.unobserve(section); }
    });
    window.addEventListener('beforeprint', settleReveal);
    window.addEventListener('pageshow', event => { if (event.persisted) settleReveal(); });
  } else settleReveal();
  // Only active reveal effects respond to the motion preference.
  const motionChanged = () => { if (reduce.matches) settleReveal(); };
  if (reduce.addEventListener) reduce.addEventListener('change', motionChanged);
  else reduce.addListener(motionChanged);
})();

/* The dock keeps real links and native vertical scrolling. Only a deliberate
   horizontal drag becomes a liquid selection gesture. No page-wide effects. */
(() => {
  'use strict';
  const dock = document.querySelector('[data-glass-dock]');
  if (!dock || dock.dataset.glassReady) return;
  const lens = dock.querySelector('[data-dock-lens]');
  const links = [...dock.querySelectorAll('[data-dock-item]')];
  const isLink = item => item.hasAttribute('data-dock-link');
  if (!lens || !links.length) return;
  dock.dataset.glassReady = 'true';
  // Anchors remain ordinary links, but their browser drag ghost would cancel
  // the pointer stream before our horizontal liquid gesture can take ownership.
  links.forEach(link => {
    link.setAttribute('draggable', 'false');
    link.querySelectorAll('svg,img').forEach(node => node.setAttribute('draggable', 'false'));
  });
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const aborter = new AbortController();
  const signal = aborter.signal;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  let selected = Math.max(0, links.findIndex(link => link.hasAttribute('aria-current')));
  let dockLeft = 0, measuredRect = null;
  let boxes = [], current = 0, target = 0, width = 0, targetWidth = 0;
  let velocity = 0, frame = 0, lastTime = 0, gesture = null;
  let suppressClickUntil = 0, navigationTimer = 0, dragActivation = false;
  let heldScale = 0, heldVelocity = 0;
  let resizeObserver = null, contrastObserver = null, pendingHref = '';
  const contrastSources = [...document.querySelectorAll('video, .dark, [data-dock-tone=dark]')];
  function observeContrast() {
    contrastObserver?.disconnect();
    if (!contrastSources.length || !('IntersectionObserver' in window)) return;
    const box = dock.getBoundingClientRect();
    const viewportHeight = window.innerHeight, viewportWidth = window.innerWidth;
    const center = box.top + box.height / 2;
    const active = new Set();
    contrastObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) active.add(entry.target); else active.delete(entry.target); });
      dock.toggleAttribute('data-over-media', active.size > 0);
    }, {rootMargin:`${-center}px ${-(viewportWidth - box.right)}px ${-(viewportHeight - center - 1)}px ${-box.left}px`, threshold:0});
    contrastSources.forEach(node => contrastObserver.observe(node));
  }
  const handoffKey = 'portfolio-dock-handoff-v2';
  const normalizedPath = pathname => pathname.replace(/\/index\.html$/, '/');
  function samePage(a, b) {
    return a.origin === b.origin && normalizedPath(a.pathname) === normalizedPath(b.pathname) && a.search === b.search;
  }
  function clearHandoff() {
    pendingHref = '';
    try { sessionStorage.removeItem(handoffKey); } catch (_) { /* Storage may be disabled. */ }
  }
  function saveHandoff() {
    if (!pendingHref || reduce.matches || boxes.length < 2) return;
    const span = boxes.at(-1).x - boxes[0].x;
    if (span <= 0) return;
    try {
      sessionStorage.setItem(handoffKey, JSON.stringify({
        href: pendingHref, at: Date.now(), fraction: (current - boxes[0].x) / span,
        speed: clamp(velocity / span, -3, 3), lift: heldScale
      }));
    } catch (_) { /* Ordinary anchor navigation remains available without storage. */ }
  }
  function restoreHandoff() {
    let state;
    try {
      state = JSON.parse(sessionStorage.getItem(handoffKey));
      sessionStorage.removeItem(handoffKey);
    } catch (_) { return; }
    if (reduce.matches || !state || typeof state.href !== 'string' ||
        !Number.isFinite(state.at) || Date.now() - state.at < 0 || Date.now() - state.at > 10000 ||
        !Number.isFinite(state.fraction) || state.fraction < -.1 || state.fraction > 1.1 ||
        !Number.isFinite(state.speed) || !Number.isFinite(state.lift)) return;
    try { if (!samePage(new URL(state.href, location.href), new URL(location.href))) return; } catch (_) { return; }
    const span = boxes.at(-1).x - boxes[0].x;
    current = boxes[0].x + state.fraction * span;
    velocity = clamp(state.speed, -3, 3) * span;
    heldScale = clamp(state.lift, 0, 1);
    paint(1 + heldScale * .09, 1 + heldScale * .16);
    animate();
  }

  // The shell alone samples the backdrop. The empty lens is one composited
  // surface: no filters, cloned labels, width animation or per-item frame writes.
  function paint(stretch = 1, squash = 1) {
    lens.style.setProperty('--lens-x', `${current.toFixed(3)}px`);
    lens.style.setProperty('--lens-stretch', stretch.toFixed(4));
    lens.style.setProperty('--lens-squash', squash.toFixed(4));
    lens.style.setProperty('--lens-glint-shift', `${clamp(velocity * .008, -10, 10).toFixed(3)}px`);
    lens.style.setProperty('--lens-glint-alpha', (.2 + Math.min(.45, Math.abs(velocity) * .0003 + Math.abs(heldScale) * .24)).toFixed(3));
  }
  function tick(time) {
    frame = 0;
    if (document.hidden) return;
    const dt = clamp((time - (lastTime || time - 16.667)) / 1000, .001, 1);
    lastTime = time;
    // Closed-form springs are stable across long frames: use real elapsed time
    // so rendering pressure cannot stretch a short release into idle animation.
    if (gesture?.dragging) {
      // Coalesce input into one paint per display frame; do not make the finger
      // chase a spring. Only the released lens settles with inertia.
      velocity = (target - current) / dt;
      current = target;
    } else {
      const omega = 24;
      const offset = current - target, c = velocity + omega * offset;
      const decay = Math.exp(-omega * dt);
      current = target + (offset + c * dt) * decay;
      velocity = (velocity - omega * c * dt) * decay;
    }
    const heldTarget = gesture ? 1 : 0;
    // Closed-form damped droplet response: one restrained release ripple,
    // independent of display refresh rate and with no geometry/filter animation.
    const frequency = 30, damping = .72, decayLift = Math.exp(-damping * frequency * dt);
    const damped = frequency * Math.sqrt(1 - damping * damping);
    const liftOffset = heldScale - heldTarget;
    const liftB = (heldVelocity + damping * frequency * liftOffset) / damped;
    const liftCos = Math.cos(damped * dt), liftSin = Math.sin(damped * dt);
    heldScale = heldTarget + decayLift * (liftOffset * liftCos + liftB * liftSin);
    heldVelocity = decayLift * ((-damping * frequency * liftOffset + damped * liftB) * liftCos
      + (-damping * frequency * liftB - damped * liftOffset) * liftSin);
    const strain = Math.min(.15, Math.abs(velocity) * .00013);
    paint(1 + strain + heldScale * .09, 1 - strain * .32 + heldScale * .16);
    if (Math.abs(current - target) > .03 || Math.abs(velocity) > .15 || Math.abs(heldTarget - heldScale) > .002 || Math.abs(heldVelocity) > .04) {
      frame = requestAnimationFrame(tick);
    } else {
      current = target; velocity = 0; lastTime = 0; heldScale = heldTarget; heldVelocity = 0;
      dock.removeAttribute('data-settling');
      paint(1 + heldScale * .09, 1 + heldScale * .16);
    }
  }
  function animate() {
    if (reduce.matches) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; velocity = 0; lastTime = 0; current = target; width = targetWidth; heldScale = 0; heldVelocity = 0;
      paint(); return;
    }
    if (!frame && !document.hidden) {
      if (!lastTime) lastTime = performance.now();
      frame = requestAnimationFrame(tick);
    }
  }
  function measure(snap = false) {
    const rect = dock.getBoundingClientRect();
    measuredRect = {left:rect.left, width:rect.width, height:rect.height};
    dockLeft = rect.left + dock.clientLeft;
    boxes = links.map(link => {
      const box = link.getBoundingClientRect();
      return {x: box.left - rect.left - dock.clientLeft, width: box.width, center: box.left + box.width / 2};
    });
    const geometryIndex = selected;
    target = boxes[geometryIndex].x; targetWidth = boxes[geometryIndex].width;
    width = targetWidth;
    lens.style.setProperty('--lens-width', `${width.toFixed(3)}px`);
    if (snap || !width) { current = target; width = targetWidth; velocity = 0; paint(); }
    else animate();
  }
  function select(index, snap = false) {
    selected = clamp(index, 0, links.length - 1);
    links.forEach((link, i) => {
      if (i === selected && isLink(link)) link.setAttribute('data-active', 'true');
      else link.removeAttribute('data-active');
      if (i === selected && isLink(link)) link.setAttribute('aria-current', new URL(link.href, location.href).hash ? 'location' : 'page');
      else link.removeAttribute('aria-current');
    });
    if (!boxes.length) return;
    target = boxes[selected].x; targetWidth = boxes[selected].width;
    if (snap) { current = target; width = targetWidth; velocity = 0; paint(); }
    else { dock.setAttribute('data-settling', ''); animate(); }
  }
  function nearest(clientX) {
    return boxes.reduce((best, box, index) => Math.abs(clientX - box.center) < Math.abs(clientX - boxes[best].center) ? index : best, 0);
  }
  function releaseCapture(pointerId) {
    if (dock.hasPointerCapture?.(pointerId)) dock.releasePointerCapture(pointerId);
  }
  function cancelGesture() {
    const old = gesture; gesture = null;
    velocity = 0;
    dock.removeAttribute('data-dragging');
    if (old) releaseCapture(old.id);
    select(selected, reduce.matches);
  }
  dock.addEventListener('contextmenu', event => {
    // Keep desktop link menus (including Ctrl-click on macOS) available. Only
    // the touch hold needs suppression to avoid callouts and selected labels.
    if (event.button === 2 || event.ctrlKey || event.pointerType === 'mouse') return;
    event.preventDefault();
    if (gesture && !gesture.dragging) { suppressClickUntil = performance.now() + 900; cancelGesture(); }
  }, {signal});
  dock.addEventListener('selectstart', event => event.preventDefault(), {signal});
  dock.addEventListener('dragstart', event => event.preventDefault(), {signal});
  dock.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || event.target.closest('a')?.hasAttribute('download')) return;
    if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = 0; clearHandoff(); }
    measure();
    gesture = {id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), dragging: false};
    animate();
  }, {signal, passive: true});
  dock.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
    if (!gesture.dragging) {
      if (Math.abs(dy) > 9 && Math.abs(dy) > Math.abs(dx)) { cancelGesture(); return; }
      if (Math.abs(dx) < 7 || Math.abs(dx) < Math.abs(dy) * 1.15) return;
      gesture.dragging = true;
      dock.setPointerCapture?.(event.pointerId);
      dock.setAttribute('data-dragging', 'true');
    }
    if (event.cancelable) event.preventDefault();
    const first = boxes[0].x, last = boxes.at(-1).x;
    // Once horizontal intent is established, the lens belongs underneath the
    // finger even if the gesture began over an unselected destination.
    const raw = event.clientX - dockLeft - width / 2;
    target = raw < first ? first + (raw - first) * .16 : raw > last ? last + (raw - last) * .16 : raw;
    animate();
  }, {signal, passive: false});
  dock.addEventListener('pointerup', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const wasDragging = gesture.dragging;
    const held = performance.now() - gesture.started;
    gesture = null;
    dock.removeAttribute('data-dragging');
    releaseCapture(event.pointerId);
    if (!wasDragging) {
      // A held press can already have settled and stopped its frame loop.
      // Always restart on release, even when no click follows the long hold.
      animate();
      if (held > 550) suppressClickUntil = performance.now() + 450;
      return;
    }
    velocity = clamp(velocity, -750, 750);
    const next = nearest(event.clientX);
    if (isLink(links[next])) select(next);
    else select(selected);
    // Consume only the compatibility click generated by this drag. Dispatch a
    // real anchor click first so existing navigation handlers remain in charge.
    dragActivation = event.isTrusted;
    links[next].click();
    dragActivation = false;
    suppressClickUntil = performance.now() + 450;
  }, {signal});
  dock.addEventListener('click', event => {
    if (performance.now() < suppressClickUntil && event.isTrusted && event.detail > 0) {
      suppressClickUntil = 0;
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const link = event.target.closest('[data-dock-item]');
    if (!link || !isLink(link) || link.hasAttribute('download') || link.getAttribute('target') === '_blank' || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
    select(links.indexOf(link));
    const url = new URL(link.href, location.href);
    const currentURL = new URL(location.href);
    // Native cross-document navigation otherwise destroys the selection animation
    // before its first frame. A short, cancellable handoff makes it visible.
    if ((event.isTrusted || dragActivation) && url.origin === location.origin &&
        !samePage(url, currentURL)) {
      event.preventDefault();
      if (navigationTimer) clearTimeout(navigationTimer);
      pendingHref = url.href;
      if (reduce.matches) { clearHandoff(); location.assign(url.href); }
      else navigationTimer = setTimeout(() => {
        navigationTimer = 0;
        saveHandoff();
        location.assign(url.href);
      }, 110);
    }
  }, {signal, capture: true});
  dock.addEventListener('pointercancel', cancelGesture, {signal});
  // A mouse press has no implicit capture. If it leaves the dock before a
  // horizontal drag begins, its release never reaches the dock listener.
  // Clear that held state without activating an unrelated destination.
  addEventListener('pointerup', event => {
    if (gesture && event.pointerId === gesture.id && !dock.contains(event.target)) cancelGesture();
  }, {signal});
  addEventListener('blur', () => { if (gesture) cancelGesture(); }, {signal});
  dock.addEventListener('lostpointercapture', event => {
    // Touch starts with implicit capture on the anchor. Moving capture to the
    // dock emits a bubbling lostpointercapture for that anchor; it is not loss
    // of the dock's newly acquired pointer and must not cancel the drag.
    if (gesture && event.pointerId === gesture.id && !dock.hasPointerCapture?.(gesture.id)) cancelGesture();
  }, {signal});
  // Native Tab/Enter activation and the focus-visible ring provide keyboard
  // navigation. Focus alone never moves the page-selection lens to a different
  // destination, so a focused control cannot look like a second current page.
  const onResize = event => {
    // ResizeObserver delivers an initial notification even without a resize.
    // Snapping that notification would erase a just-restored cross-page spring.
    const rect = dock.getBoundingClientRect();
    const changed = !measuredRect || rect.left !== measuredRect.left || rect.width !== measuredRect.width || rect.height !== measuredRect.height;
    if (!changed && !event?.type) return;
    if (gesture) cancelGesture();
    measure(true);
    observeContrast();
  };
  addEventListener('resize', onResize, {signal, passive: true});
  if ('ResizeObserver' in window) {
    resizeObserver = new ResizeObserver(onResize); resizeObserver.observe(dock);
  }
  const onMotion = () => { cancelGesture(); measure(true); animate(); };
  reduce.addEventListener('change', onMotion, {signal});
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0; cancelGesture();
    } else { measure(true); }
  }, {signal});
  // Each tab now names a separate page, including contact. Scrolling inside a
  // document never changes its current-page semantics or runs a section observer.
  measure(true); select(selected, true); restoreHandoff(); observeContrast();
  addEventListener('pagehide', event => {
    // Capture the actual departure position after loading time, rather than the
    // earlier click position, so the next document continues the same movement.
    saveHandoff();
    cancelGesture();
    if (frame) cancelAnimationFrame(frame);
    frame = 0; velocity = 0; lastTime = 0;
    if (navigationTimer) clearTimeout(navigationTimer);
    navigationTimer = 0;
    if (event.persisted) return;
    aborter.abort(); resizeObserver?.disconnect(); contrastObserver?.disconnect();
    if (frame) cancelAnimationFrame(frame);
  }, {signal});
  addEventListener('pageshow', event => {
    if (!event.persisted) return;
    suppressClickUntil = 0;
    heldScale = 0; heldVelocity = 0; velocity = 0;
    measure(true); select(selected, true);
  }, {signal});
})();

/* Direct contact: show which real control is pressed without owning its click or scroll. */
(() => {
  'use strict';
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const interactive = 'a.capability-card,a.premium-story,a.button,button:not([disabled]),summary,.role-path a,.premium-experience-list>a,.contact-methods a,[data-dialog-open],[data-portrait-open],[data-image-open]';
  const surfaces = '.capability-card,.case-study,.role-path,.premium-story,.home-field';
  const releaseTimers = new WeakMap();
  let active = null, frame = 0, point = null;
  try { localStorage.removeItem('portfolio-glass-appearance-v1'); } catch { /* Private mode. */ }
  function syncMotion() {
    root.dataset.sceneMotion = reduced.matches ? 'off' : 'on';
    root.dataset.scenePaused = document.hidden ? 'true' : 'false';
    if (document.hidden || reduced.matches) clearContact(false);
  }
  function controlFor(target) {
    const control = target.closest?.(interactive);
    // The dock owns its own drag spring; disabled and dialog-close controls stay native.
    return control && !control.matches('.dialog-close,[data-dialog-close]') && !control.closest('[data-glass-dock]') ? control : null;
  }
  document.querySelectorAll(interactive).forEach(control => {
    if (!control.matches('.dialog-close,[data-dialog-close]') && !control.closest('[data-glass-dock]')) control.dataset.glassControl = '';
  });
  function locate(control, x, y) {
    const r = control.getBoundingClientRect();
    const localX = Math.max(0, Math.min(r.width, x-r.left));
    const localY = Math.max(0, Math.min(r.height, y-r.top));
    control.style.setProperty('--press-x', `${localX}px`);
    control.style.setProperty('--press-y', `${localY}px`);
    control.style.setProperty('--press-rx', `${-(localY/Math.max(1,r.height)-.5)*2}deg`);
    control.style.setProperty('--press-ry', `${(localX/Math.max(1,r.width)-.5)*2}deg`);
    control.style.setProperty('--light-x', `${localX}px`);
    control.style.setProperty('--light-y', `${localY}px`);
  }
  function clearContact(activate) {
    if (!active) return;
    const {control} = active;
    active = null;
    delete control.dataset.glassPressed;
    if (activate && !reduced.matches) {
      control.dataset.glassReleased = 'true';
      clearTimeout(releaseTimers.get(control));
      releaseTimers.set(control, setTimeout(() => { delete control.dataset.glassReleased; }, 700));
    } else delete control.dataset.glassReleased;
  }
  function begin(control, x, y, id) {
    clearContact(false);
    clearTimeout(releaseTimers.get(control));
    control.dataset.glassControl = '';
    delete control.dataset.glassReleased;
    locate(control, x, y);
    control.dataset.glassPressed = 'true';
    active = {control, x, y, id};
  }
  document.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    const control = controlFor(event.target);
    if (control) begin(control, event.clientX, event.clientY, event.pointerId);
  }, {passive:true});
  document.addEventListener('pointermove', event => {
    if (active && event.pointerId === active.id) {
      // A vertical swipe always belongs to the browser, never to this material effect.
      if (Math.hypot(event.clientX-active.x,event.clientY-active.y)>12) clearContact(false);
    }
    if (reduced.matches || document.hidden) return;
    point = {x:event.clientX,y:event.clientY,target:event.target};
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      if (!point || reduced.matches || document.hidden) return;
      root.style.setProperty('--scene-x', `${(point.x/innerWidth-.5)*24}px`);
      root.style.setProperty('--scene-y', `${(point.y/innerHeight-.5)*18}px`);
      const surface = point.target.closest?.(surfaces);
      if (surface) {
        const r = surface.getBoundingClientRect();
        surface.style.setProperty('--light-x', `${point.x-r.left}px`);
        surface.style.setProperty('--light-y', `${point.y-r.top}px`);
      }
    });
  }, {passive:true});
  document.addEventListener('pointerup', event => { if (active?.id===event.pointerId) clearContact(true); }, {passive:true});
  document.addEventListener('pointercancel', () => clearContact(false), {passive:true});
  document.addEventListener('keydown', event => {
    if (event.repeat || !['Enter',' '].includes(event.key)) return;
    const control = controlFor(event.target);
    if (!control || (event.key===' ' && control.matches('a'))) return;
    const r = control.getBoundingClientRect();
    begin(control,r.left+r.width/2,r.top+r.height/2,'keyboard');
  });
  document.addEventListener('focusout', event => { if (active?.id==='keyboard' && active.control===event.target) clearContact(false); });
  document.addEventListener('keyup', event => { if (['Enter',' '].includes(event.key) && active?.id==='keyboard') clearContact(true); });
  for (const event of ['blur','pagehide','resize','scroll','contextmenu']) addEventListener(event, () => clearContact(false), {passive:true});
  reduced.addEventListener('change', syncMotion);
  document.addEventListener('visibilitychange', syncMotion);
  addEventListener('pageshow', syncMotion);
  syncMotion();
})();

/* Live light field. The generated 1,228,800 samples supply height and normals;
 * time, pointer input and game actions change their refraction every frame. */
(() => {
  'use strict';
  if (document.querySelector('[data-optical-scene]')) return;
  const water = document.createElement('div');
  water.className = 'water-events';
  water.setAttribute('aria-hidden', 'true');
  // Each event has an actual falling lens followed by two expanding surface rings.
  for (const [x, y, delay] of [[16,28,0],[77,52,-1.05],[34,78,-2.1],[87,18,-3.15]]) {
    const event = document.createElement('span');
    event.className = 'water-event';
    event.style.cssText = `--water-x:${x}%;--water-y:${y}%;--water-delay:${delay}s`;
    event.innerHTML = '<i class="water-drop"></i><i class="water-ring"></i><i class="water-ring water-ring-echo"></i>';
    water.append(event);
  }
  (document.querySelector('.ambient-field') || document.body).append(water);
  const source = new URL('glass-flow.0decc9aa5b10.png', document.currentScript.src).href;
  const canvas = document.createElement('canvas');
  canvas.className = 'optical-scene';
  canvas.dataset.opticalScene = 'loading';
  canvas.setAttribute('aria-hidden', 'true');
  (document.querySelector('.ambient-field') || document.body).prepend(canvas);
  const gameplay = !!document.querySelector('#garden');
  const arenaOverlay = gameplay ? document.querySelector('#overlay') : null;
  let battleActive = !!arenaOverlay?.hidden;
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const contrast = matchMedia('(prefers-contrast: more)');
  const transparency = matchMedia('(prefers-reduced-transparency: reduce)');
  const gl = canvas.getContext('webgl', {alpha: false, antialias: false,
    depth: false, stencil: false, powerPreference: 'high-performance'});
  if (!gl) { canvas.remove(); return; } // The authored CSS field stays visible.
  const rendererInfo = gl.getExtension('WEBGL_debug_renderer_info');
  const software = !!rendererInfo && /SwiftShader|llvmpipe|software/i.test(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL));
  const vertex = 'attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}';
  // Analytic waves animate the sampled surface; highlights follow its normals.
  // Everything lives behind the page, so refraction never distorts readable type.
  const fragment = `precision highp float;
    varying vec2 uv; uniform sampler2D field; uniform float clock;
    uniform vec2 pointer; uniform vec3 pulses[4]; uniform float aspect; uniform float pressure;
    uniform float contactRadius;
    // Champagne, pearl and blue-grey folds: a luminous adaptation of the
    // supplied wallpaper. The floor preserves contrast under transparent type.
    vec3 waterColor(vec2 q){
      float breath=sin(clock*.30)*.055;
      vec3 pearl=vec3(.94,.925,.90);
      vec3 champagne=vec3(.86,.74,.57);
      vec3 blueGrey=vec3(.62,.69,.79);
      vec3 c=mix(pearl,champagne,exp(-length((q-vec2(.12,.13))*vec2(1.1,1.6))*2.4)*.68);
      c=mix(c,blueGrey,smoothstep(.42,1.12,q.y)*.57);
      // Fold the coordinate once instead of shading each sheet separately.
      // Parallel S-curves preserve the lip/shadow profile at a third of the cost
      // in every refracted lens sample, including on mobile fragment processors.
      float folded=q.y+.32*q.x-.20*sin(q.x*3.9+clock*.19)
                   -breath*sin(q.x*3.);
      float distance=(fract((folded-.14)/.34+.5)-.5)*.34;
      float sheet=exp(-pow((distance-.075)/.115,2.));
      float edge=exp(-pow(distance/.006,2.));
      float glow=exp(-pow((distance+.018)/.045,2.));
      float taper=1.-smoothstep(.12,.17,abs(distance));
      c-=sheet*taper*vec3(.105,.098,.084);
      c+=glow*vec3(.065,.061,.055)+edge*vec3(.12,.115,.105);
      vec2 amber=(q-vec2(.17+sin(clock*.21)*.12,.27))*vec2(1.,1.7);
      c+=exp(-dot(amber,amber)*9.)*vec3(.048,.018,-.018);
      return clamp(c,vec3(.69,.70,.72),vec3(.98));
    }
    float surface(vec2 p){
      return sin(p.x*4.8+p.y*3.2-clock*.67)*.46
        +sin(p.x*-2.7+p.y*7.1+clock*.53)*.28
        +sin(p.x*8.2-p.y*2.4+sin(p.y*3.-clock*.31))*.08;
    }
    // A wave packet has a finite front and a trailing wake, rather than a
    // CSS outline expanding independently from the refracted environment.
    vec2 waveSlope(vec2 delta,float age){
      float radius=length(delta),front=radius-age*.36;
      float envelope=exp(-front*front*145.-age*.72)*smoothstep(0.,.12,age);
      // A narrow leading ridge and softer wake catch opposite sides of the light.
      float ridge=cos(front*72.)+cos((front+.035)*48.)*.32;
      return delta/max(radius,.002)*ridge*envelope*3.15;
    }
    void main(){
      vec2 q=vec2(uv.x,1.-uv.y), metric=vec2(aspect,1.);
      vec2 p=q*metric+(pointer-.5)*.028;
      float h=surface(p);
      vec2 slope=vec2(surface(p+vec2(.003,0.))-h,surface(p+vec2(0.,.003))-h)/.003;
      for(int i=0;i<4;i++){
        if(pulses[i].z>=0.){
          float age=max(0.,clock-pulses[i].z);
          slope+=waveSlope((q-pulses[i].xy)*metric,age)*1.45;
        }
      }
      // Automatic droplets share one clock with their impact waves. They land
      // in the same coordinate system; refraction continues into the wake.
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*1.83,5.5)-1.05;
        vec2 center=vec2(.17+id*.32,.25+mod(id*.29,.6));
        if(age>=0.) slope+=waveSlope((q-center)*metric,age);
      }
      vec2 contact=(q-pointer)*metric;
      // Keep the fingertip lens a consistent physical size on phones and desktops.
      float contactSize=max(.025,contactRadius);
      vec2 finger=contact/contactSize;
      float fingerDepth=exp(-dot(finger,finger)*1.8)*pressure;
      slope+=finger*fingerDepth*3.8;
      vec2 drift=vec2(sin(clock*.16),cos(clock*.13))*.035;
      vec3 optical=texture2D(field,clamp(q*.88+.06+drift,.001,.999)).rgb;
      vec3 normal=normalize(vec3(-slope*.18+(optical.gb-.5)*.045,1.));
      vec2 refracted=q+normal.xy*.24/metric;
      vec3 color=waterColor(refracted);
      vec3 key=normalize(vec3(-.48,-.62,1.));
      float light=pow(max(dot(normal,key),0.),42.);
      float caustic=pow(.5+.5*sin(h*6.+optical.r*.6),26.);
      color+=light*.19+caustic*.045;
      // Pressure forms a shallow clear dimple with an illuminated meniscus.
      float meniscus=exp(-pow((length(finger)-.84)*9.,2.))*pressure;
      color+=meniscus*.075-fingerDepth*.026;
      // Three shallow, noncircular lenses have thickness, dispersion and a
      // grazing reflection. Their centers remain transparent to the water.
      for(int i=0;i<3;i++){
        float id=float(i),r=.12+id*.045;
        vec2 center=vec2(.14+id*.35+sin(clock*(.23-id*.025)+id*3.)*.065,
                         .20+id*.27+cos(clock*.20+id*2.)*.065);
        vec2 local=(q-center)*metric/vec2(r*1.35,r);
        float angle=atan(local.y,local.x);
        float d=length(local)/(1.+.055*sin(angle*3.+clock*.22+id));
        float mask=1.-smoothstep(.985,1.015,d);
        float curve=sqrt(max(.001,1.-min(d*d,1.)));
        vec2 bend=local*r*(.18+.38*curve)/metric;
        vec3 lens=waterColor(refracted+bend);
        float rim=pow(smoothstep(.63,1.,d),5.);
        lens.r=waterColor(refracted+bend*(1.+rim*.055)).r;
        lens.b=waterColor(refracted+bend*(1.-rim*.055)).b;
        vec3 ln=normalize(vec3(local*.82,curve));
        float highlight=pow(max(dot(ln,key),0.),64.);
        float fresnel=pow(1.-curve,4.);
        lens=mix(lens,vec3(.99,1.,1.),fresnel*.36)+highlight*.34;
        color=mix(color,lens,mask);
        float edge=exp(-pow((d-.994)*145.,2.));
        float direction=dot(normalize(local+vec2(.001)),normalize(vec2(-.5,-.8)));
        color+=edge*(.035+.075*direction);
        color-=exp(-pow((d-1.025)*48.,2.))*.028;
      }
      // A falling bead shrinks into its impact; no decorative overlay covers text.
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*1.83,5.5)-1.05;
        if(age<0.){
          float fall=clamp((age+1.05)/1.05,0.,1.);
          vec2 center=vec2(.17+id*.32,.25+mod(id*.29,.6)-.26*(1.-fall*fall));
          vec2 local=(q-center)*metric/vec2(.021,.037-.013*fall);
          float d=length(local),mask=1.-smoothstep(.94,1.04,d);
          vec3 bead=waterColor(q+local*.035/metric);
          bead+=pow(max(dot(normalize(vec3(local,sqrt(max(.001,1.-d*d)))),key),0.),24.)*.4;
          color=mix(color,bead,mask*smoothstep(0.,.22,fall));
        }
      }
      gl_FragColor=vec4(clamp(color,0.,1.),1.);
    }`;
  function shader(type, text) {
    const result = gl.createShader(type);
    if (type === gl.FRAGMENT_SHADER && !gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)?.precision) text = text.replace('precision highp float;', 'precision mediump float;');
    gl.shaderSource(result, text); gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) throw Error('Optical shader compilation failed');
    return result;
  }
  let program, texture, frame = 0, last = 0, elapsed = 0, ready = false, lost = false, needsPaint = true, suspended = false;
  const pointer = [.5, .5], pulses = new Float32Array([.5,.5,-1,.5,.5,-1,.5,.5,-1,.5,.5,-1]);
  let pulseIndex = 0, held = false, pressure = 0, lastTrail = 0, contactId = null;
  let buffer = null, locations = null;
  function clearPressure() { held = false; pressure = 0; contactId = null; }
  function clearWaves() { for (let i = 2; i < pulses.length; i += 3) pulses[i] = -1; }
  function position(event) {
    pointer[0] = Math.max(0, Math.min(1, event.clientX / innerWidth));
    pointer[1] = Math.max(0, Math.min(1, event.clientY / innerHeight));
  }
  function stopped() { return suspended || battleActive || document.hidden || contrast.matches || transparency.matches || lost; }
  function resize() {
    // Native GPUs keep the full-resolution field. CPU-only rasterizers get a
    // smaller backing buffer so material never competes with direct manipulation.
    const scale = gameplay
      ? Math.min(.75, 640 / innerWidth, 480 / innerHeight)
      : software ? Math.min(1, 640 / innerWidth, 480 / innerHeight)
      : Math.min(devicePixelRatio || 1, 1.5, 1920 / innerWidth, 1440 / innerHeight);
    needsPaint = true;
    canvas.width = Math.max(1, Math.round(innerWidth * scale));
    canvas.height = Math.max(1, Math.round(innerHeight * scale));
  }
  function draw(now = 0) {
    frame = 0;
    if (!ready || stopped() || (motion.matches && !needsPaint)) { last = 0; return; }
    if (last && now - last < (gameplay ? 50 : software ? 32 : 15) && !motion.matches) { frame = requestAnimationFrame(draw); return; }
    if (last && !motion.matches) elapsed += Math.min(.1, (now - last) / 1000);
    last = now;
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.useProgram(program);
    gl.uniform1f(locations.clock, elapsed);
    gl.uniform1f(locations.aspect, canvas.width / canvas.height);
    gl.uniform2fv(locations.pointer, pointer);
    pressure += ((held ? 1 : 0) - pressure) * .24;
    gl.uniform1f(locations.pressure, pressure);
    gl.uniform1f(locations.contactRadius, 72 / innerHeight);
    gl.uniform3fv(locations.pulses, pulses);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    needsPaint = false;
    canvas.dataset.opticalFrames = String(Number(canvas.dataset.opticalFrames || 0) + 1);
    if (!motion.matches) frame = requestAnimationFrame(draw);
  }
  function resume() {
    if (frame) cancelAnimationFrame(frame);
    frame = 0; last = 0;
    if (stopped() || motion.matches) { clearPressure(); clearWaves(); }
    document.documentElement.dataset.waterPaused = document.hidden || battleActive ? 'true' : 'false';
    canvas.dataset.opticalMotion = motion.matches ? 'still' : 'live';
    if (ready && !stopped() && (!motion.matches || needsPaint)) frame = requestAnimationFrame(draw);
  }
  if (arenaOverlay) new MutationObserver(() => {
    const next = arenaOverlay.hidden;
    if (next === battleActive) return;
    battleActive = next; resume();
  }).observe(arenaOverlay, {attributes:true, attributeFilter:['hidden']});
  const image = new Image();
  function initialize() {
    try {
      if (program && !lost) { gl.deleteProgram(program); gl.deleteTexture(texture); gl.deleteBuffer(buffer); }
      program = gl.createProgram();
      const vs = shader(gl.VERTEX_SHADER, vertex), fs = shader(gl.FRAGMENT_SHADER, fragment);
      gl.attachShader(program, vs); gl.attachShader(program, fs); gl.linkProgram(program);
      gl.deleteShader(vs); gl.deleteShader(fs);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('Optical shader linking failed');
      gl.useProgram(program);
      locations = Object.fromEntries(['clock','aspect','pointer','pressure','contactRadius'].map(name => [name, gl.getUniformLocation(program, name)]));
      locations.pulses = gl.getUniformLocation(program, 'pulses[0]');
      buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]), gl.STATIC_DRAW);
      const attribute = gl.getAttribLocation(program, 'a');
      gl.enableVertexAttribArray(attribute); gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
      texture = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
      gl.uniform1i(gl.getUniformLocation(program, 'field'), 0);
      canvas.hidden = false;
      canvas.dataset.opticalScene = 'webgl';
      water.hidden = true; // CSS droplets are only the no-WebGL fallback.
      canvas.dataset.opticalSamples = String(image.width * image.height);
      ready = true; resize(); resume();
    } catch { ready = false; canvas.hidden = true; water.hidden = false; }
  }
  image.onload = initialize;
  image.onerror = () => canvas.remove();
  image.src = source;
  addEventListener('resize', () => { resize(); resume(); }, {passive: true});
  document.addEventListener('visibilitychange', resume);
  addEventListener('pagehide', event => {
    suspended = true; held = false; resume();
    if (!event.persisted) gl.getExtension('WEBGL_lose_context')?.loseContext();
  });
  addEventListener('pageshow', () => { suspended = false; resume(); });
  for (const preference of [motion, contrast, transparency]) preference.addEventListener('change', () => { needsPaint = true; resume(); });
  document.addEventListener('pointermove', event => {
    if (!event.isPrimary || motion.matches || stopped() || (contactId !== null && event.pointerId !== contactId)) return;
    position(event);
    if (held && event.timeStamp - lastTrail > 90) { lastTrail = event.timeStamp; ripple(pointer[0], pointer[1]); }
  }, {passive: true});
  function ripple(x, y) {
    if (motion.matches || stopped()) return;
    const offset = (pulseIndex++ % 4) * 3;
    pulses[offset] = x; pulses[offset+1] = y; pulses[offset+2] = elapsed;
    canvas.dataset.opticalInputs = String(Number(canvas.dataset.opticalInputs || 0) + 1);
  }
  document.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0 || motion.matches || stopped()) return;
    position(event); contactId = event.pointerId;
    held = true; ripple(pointer[0], pointer[1]);
  }, {passive: true});
  addEventListener('pointerup', event => {
    if (event.pointerId !== contactId) return;
    position(event); held = false; contactId = null;
    ripple(pointer[0], pointer[1]);
  }, {passive: true});
  addEventListener('pointercancel', event => { if (event.pointerId === contactId) clearPressure(); }, {passive: true});
  for (const event of ['blur','pagehide']) addEventListener(event, clearPressure, {passive: true});
  document.addEventListener('visibilitychange', () => { if (document.hidden) held = false; });
  addEventListener('gardenoptics', event => ripple(event.detail?.x ?? .5, event.detail?.y ?? .5));
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); lost = true; canvas.hidden = true; water.hidden = false; resume(); });
  canvas.addEventListener('webglcontextrestored', () => { lost = false; initialize(); });
})();
