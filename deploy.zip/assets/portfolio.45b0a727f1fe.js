/* Progressive portfolio interactions. Include once with defer; no dependencies. */
(() => {
  'use strict';
  const all = (selector, root = document) => [...root.querySelectorAll(selector)];
  const byId = id => id ? document.getElementById(id.replace(/^#/, '')) : null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const focusable = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const isOpen = dialog => Boolean(dialog?.hasAttribute('open'));
  const canFocus = node => node && !node.hidden && node.getClientRects().length > 0;
  const fallbackStates = new WeakMap();
  const modalSupported = typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const openers = new WeakMap();
  const triggers = new WeakMap();
  let activeDialog = null;
  let priorOverflow = '';
  let priorGutter = '';
  const outsideStarts = new WeakMap();
  const announce = (selector, message) => { const node = document.querySelector(selector); if (node) node.textContent = message; };

  function finishClose(dialog, restoreFocus = true) {
    if (isOpen(dialog) || activeDialog !== dialog) return;
    all('video, audio', dialog).forEach(media => media.pause());
    const opener = openers.get(dialog);
    triggers.get(dialog)?.setAttribute('aria-expanded', 'false');
    const fallback = fallbackStates.get(dialog);
    if (fallback) {
      fallback.backdrop.remove();
      fallback.background.forEach(({ node, inert, hidden }) => {
        if ('inert' in node) node.inert = inert;
        if (hidden === null) node.removeAttribute('aria-hidden'); else node.setAttribute('aria-hidden', hidden);
      });
      if (fallback.style === null) dialog.removeAttribute('style'); else dialog.setAttribute('style', fallback.style);
      if (fallback.role === null) dialog.removeAttribute('role'); else dialog.setAttribute('role', fallback.role);
      dialog.removeAttribute('aria-modal');
      fallbackStates.delete(dialog);
    }
    document.documentElement.style.overflow = priorOverflow;
    document.documentElement.style.scrollbarGutter = priorGutter;
    activeDialog = null;
    if (restoreFocus && opener?.isConnected && canFocus(opener) && !opener.closest('dialog:not([open])')) opener.focus({ preventScroll: true });
  }
  function close(dialog, restoreFocus = true) {
    if (!isOpen(dialog)) return;
    if (fallbackStates.has(dialog)) dialog.removeAttribute('open');
    else dialog.close();
    // Native close events are queued: settle this session before opening another.
    finishClose(dialog, restoreFocus);
  }
  function open(dialog, opener) {
    if (!dialog || dialog.tagName !== 'DIALOG') return false;
    if (isOpen(dialog)) return true;
    const returnOpener = activeDialog && opener?.closest('dialog') === activeDialog ? openers.get(activeDialog) : opener;
    if (activeDialog && activeDialog !== dialog) close(activeDialog, false);
    openers.set(dialog, returnOpener);
    triggers.set(dialog, opener);
    priorOverflow = document.documentElement.style.overflow;
    priorGutter = document.documentElement.style.scrollbarGutter;
    // Reserve the scrollbar lane so opening a dialog does not shift the page.
    document.documentElement.style.scrollbarGutter = 'stable';
    document.documentElement.style.overflow = 'hidden';
    // Older WebViews still receive a usable, focus-contained dialog.
    let nativeOpened = false;
    if (modalSupported) {
      try { dialog.showModal(); nativeOpened = true; } catch (_) { /* Use the local fallback. */ }
    }
    if (!nativeOpened) {
      const backdrop = document.createElement('div');
      backdrop.setAttribute('aria-hidden', 'true');
      backdrop.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(12,20,32,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)';
      const background = all('body > *').filter(node => node !== dialog && !['SCRIPT', 'STYLE'].includes(node.tagName))
        .map(node => ({ node, inert: node.inert, hidden: node.getAttribute('aria-hidden') }));
      fallbackStates.set(dialog, { backdrop, background, style: dialog.getAttribute('style'), role: dialog.getAttribute('role') });
      background.forEach(({ node }) => { if ('inert' in node) node.inert = true; else node.setAttribute('aria-hidden', 'true'); });
      document.body.append(backdrop);
      backdrop.addEventListener('click', () => close(dialog));
      dialog.setAttribute('open', '');
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      Object.assign(dialog.style, { display: 'block', position: 'fixed', zIndex: '9999', inset: '0', margin: 'auto', overflow: 'auto', maxHeight: 'calc(100% - 24px)' });
    }
    activeDialog = dialog;
    opener?.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => {
      if (activeDialog !== dialog || !isOpen(dialog)) return;
      // A selector list follows DOM order; explicitly prioritize the search field.
      const target = dialog.querySelector('[autofocus]') || dialog.querySelector('[data-search-input]') ||
        dialog.querySelector('[data-dialog-close], button, a[href], input');
      if (target) target.focus({ preventScroll: true });
      else { dialog.tabIndex = -1; dialog.focus({ preventScroll: true }); }
    });
    return true;
  }

  all('dialog').forEach(dialog => {
    if (!modalSupported) dialog.style.display = 'none';
    dialog.addEventListener('close', () => {
      // Ignore an older queued close if this dialog has already reopened.
      finishClose(dialog);
    });
    const outside = event => {
      const box = dialog.getBoundingClientRect();
      return event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom);
    };
    dialog.addEventListener('pointerdown', event => { outsideStarts.set(dialog, outside(event)); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(dialog); });
    dialog.addEventListener('click', event => {
      // A drag starting inside the dialog must never dismiss it on release.
      const startedOutside = outsideStarts.get(dialog);
      outsideStarts.delete(dialog);
      if (!startedOutside || event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close(dialog);
    });
    all('[data-dialog-close], [data-search-close], [data-portrait-close]', dialog).forEach(button => button.addEventListener('click', () => close(dialog)));
  });

  function navigateFromDialog(event, anchor, dialog) {
    // Modified clicks keep the current modal and preserve native new-tab behavior.
    if (event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
    if (anchor.matches('[data-search-open], [data-dialog-open], [data-portrait-open], [data-image-open]')) return;
    const url = new URL(anchor.href, location.href);
    const pagePath = pathname => pathname.replace(/\/index\.html$/, '/');
    const samePage = url.origin === location.origin && pagePath(url.pathname) === pagePath(location.pathname) && url.search === location.search;
    let target = null;
    if (samePage && url.hash) {
      try { target = byId(decodeURIComponent(url.hash.slice(1))); } catch (_) { /* Preserve malformed native URLs. */ }
    }
    // Downloads and new windows leave this document in place: restore its focus.
    if (anchor.target === '_blank' || anchor.hasAttribute('download')) { close(dialog); return; }
    close(dialog, !target);
    if (!target) return;
    event.preventDefault();
    if (location.hash !== url.hash) history.pushState(null, '', url.href);
    // Move both the reading position and keyboard focus to the selected section.
    const temporaryTabIndex = !target.hasAttribute('tabindex') && target.tabIndex < 0;
    if (temporaryTabIndex) {
      target.setAttribute('tabindex', '-1');
      target.addEventListener('blur', () => target.removeAttribute('tabindex'), { once: true });
    }
    target.focus({ preventScroll: true });
    target.scrollIntoView({ behavior: 'auto', block: 'start' });
  }

  all('[data-search-open], [data-dialog-open], [data-portrait-open], [data-image-open]').forEach(opener => {
    const id = opener.dataset.dialogOpen || opener.dataset.searchTarget || opener.dataset.imageTarget ||
      (opener.hasAttribute('data-search-open') ? 'search-dialog' : 'portrait-dialog');
    const dialog = byId(id);
    if (!dialog) {
      // Keep real hrefs operational; dead buttons should not appear interactive.
      if (opener.tagName === 'BUTTON') opener.hidden = true;
      return;
    }
    opener.setAttribute('aria-controls', dialog.id);
    opener.setAttribute('aria-haspopup', 'dialog');
    opener.setAttribute('aria-expanded', 'false');
    opener.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (opener.hasAttribute('data-image-open')) {
        const image = dialog.querySelector('[data-dialog-image]');
        const source = opener.dataset.imageSrc || opener.getAttribute('href');
        if (image && source) {
          let url;
          try { url = new URL(source, location.href); } catch (_) { return; }
          if (!['https:', 'http:'].includes(url.protocol)) return;
          image.src = url.href;
          image.alt = opener.dataset.imageAlt || opener.querySelector('img')?.alt || '作品图片';
        }
      }
      if (open(dialog, opener)) event.preventDefault();
    });
  });

  const normalize = value => value.normalize('NFKC').toLocaleLowerCase().replace(/\s+/g, ' ').trim();
  const searchStates = new WeakMap();
  all('[data-search-input]').forEach(input => {
    const scope = input.closest('dialog') || input.closest('[data-search]');
    if (!scope) return;
    const results = all('a[data-search-item]', scope);
    const records = results.map((anchor, index) => ({
      anchor, index,
      title: normalize(anchor.querySelector('strong')?.textContent || anchor.textContent),
      text: normalize(anchor.textContent),
      keywords: normalize(anchor.dataset.searchKeywords || '')
    }));
    const container = scope.querySelector('.search-results');
    const empty = scope.querySelector('[data-search-empty]');
    const count = scope.querySelector('[data-search-count]');
    let visible = [];
    let composing = false;
    const filter = () => {
      const query = normalize(input.value);
      const terms = query.split(' ').filter(Boolean);
      const matches = records.map(record => {
        const haystack = `${record.text} ${record.keywords}`;
        if (!terms.every(term => haystack.includes(term))) return null;
        // A direct answer ranks above a page that merely mentions the same word.
        const score = terms.reduce((sum, term) => sum + (record.title.includes(term) ? 12 : record.text.includes(term) ? 5 : record.keywords.split(' ').includes(term) ? 9 : 2), 0)
          + (query && record.title === query ? 20 : 0);
        return { ...record, score };
      }).filter(Boolean).sort((a, b) => b.score - a.score || a.index - b.index);
      visible = (query ? matches : matches.slice(0, 6)).map(record => record.anchor);
      const shown = new Set(visible);
      results.forEach(anchor => { anchor.hidden = !shown.has(anchor); });
      // Moving the same elements preserves their listeners, link semantics and labels.
      if (container) {
        const fragment = document.createDocumentFragment();
        const matched = new Set(matches.map(({ anchor }) => anchor));
        matches.forEach(({ anchor }) => fragment.append(anchor));
        records.filter(record => !matched.has(record.anchor)).forEach(({ anchor }) => fragment.append(anchor));
        container.append(fragment);
      }
      if (empty) empty.hidden = matches.length > 0;
      if (count) count.textContent = query ? `找到 ${matches.length} 项相关内容` : '常用信息 · 可搜索作品、经历、学历与联系方式';
    };
    input.addEventListener('compositionstart', () => { composing = true; });
    input.addEventListener('compositionend', () => { composing = false; filter(); });
    input.addEventListener('input', () => { if (!composing) filter(); });
    all('[data-search-query]', scope).forEach(button => button.addEventListener('click', () => {
      input.value = button.dataset.searchQuery || '';
      filter();
      input.focus();
    }));
    input.addEventListener('keydown', event => {
      if (composing || event.isComposing || event.keyCode === 229) return;
      if (event.key === 'ArrowDown' && visible.length) { event.preventDefault(); visible[0].focus(); }
      if (event.key === 'Enter' && visible.length) { event.preventDefault(); visible[0].click(); }
    });
    results.forEach(anchor => {
      anchor.addEventListener('click', event => navigateFromDialog(event, anchor, scope));
      anchor.addEventListener('keydown', event => {
        if (!['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key) || event.isComposing) return;
        const index = visible.indexOf(anchor);
        event.preventDefault();
        if (event.key === 'ArrowUp' && index <= 0) input.focus();
        else if (event.key === 'Home') visible[0]?.focus();
        else if (event.key === 'End') visible[visible.length - 1]?.focus();
        else visible[Math.min(visible.length - 1, Math.max(0, index + (event.key === 'ArrowDown' ? 1 : -1)))]?.focus();
      });
    });
    searchStates.set(scope, { input, filter });
    filter();
  });
  const appleKeyboard = /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent);
  all('[data-search-shortcut]').forEach(node => { node.textContent = appleKeyboard ? '⌘ K' : 'Ctrl K'; });
  document.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.defaultPrevented) return;
    if ((event.metaKey || event.ctrlKey) && !event.altKey && !event.shiftKey && event.key.toLowerCase() === 'k') {
      const trigger = all('[data-search-open]').find(canFocus);
      if (trigger) {
        event.preventDefault();
        const dialog = byId(trigger.getAttribute('aria-controls'));
        if (activeDialog === dialog) searchStates.get(dialog)?.input.focus();
        else trigger.click();
      }
      return;
    }
    // Search inputs can consume Escape before the native dialog cancel event.
    if (activeDialog && event.key === 'Escape') { event.preventDefault(); close(activeDialog); return; }
    if (!activeDialog || !fallbackStates.has(activeDialog)) return;
    if (event.key === 'Tab') {
      const targets = all(focusable, activeDialog).filter(canFocus);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) { event.preventDefault(); activeDialog.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    }
  });

  // No autoplay, scroll hijacking, or automatic audio resumption.
  const audio = document.querySelector('audio[data-ambient]');
  let soundPending = false;
  if (audio) audio.volume = 0.24;
  all('[data-sound]').forEach(button => {
    if (!audio) { button.hidden = true; return; }
    button.addEventListener('click', async () => {
      if (!audio.paused) { audio.pause(); return; }
      if (soundPending) return;
      if (all('video').some(video => !video.paused && !video.muted)) {
        announce('[data-sound-status]', '请先暂停视频，再开启轻音乐。');
        return;
      }
      soundPending = true;
      button.setAttribute('aria-busy', 'true');
      try { await audio.play(); announce('[data-sound-status]', '轻音乐已开启。'); }
      catch (_) { announce('[data-sound-status]', '音乐暂时无法播放，请稍后再试。'); }
      finally { soundPending = false; button.removeAttribute('aria-busy'); }
    });
  });
  const refreshSound = () => {
    const playing = Boolean(audio && !audio.paused);
    all('[data-sound]').forEach(button => {
      button.setAttribute('aria-pressed', String(playing));
      const label = button.querySelector('[data-sound-label]');
      if (label) label.textContent = playing ? '暂停轻音乐' : '开启轻音乐';
    });
  };
  if (audio) {
    ['play', 'pause', 'ended'].forEach(type => audio.addEventListener(type, refreshSound));
    audio.addEventListener('error', () => announce('[data-sound-status]', '音乐暂时无法加载，请稍后再试。'));
  }
  refreshSound();
  document.addEventListener('play', event => {
    const media = event.target;
    if (!(media instanceof HTMLVideoElement)) return;
    audio?.pause();
    all('video').filter(video => video !== media).forEach(video => video.pause());
  }, true);
  const pauseMedia = () => all('video, audio').forEach(media => media.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMedia(); });
  window.addEventListener('pagehide', pauseMedia);

  all('[data-video-play], [data-preview-toggle]').forEach(button => {
    const video = byId(button.getAttribute('aria-controls')) || button.closest('[data-video-player], [data-preview-film]')?.querySelector('video');
    if (!video) { button.hidden = true; return; }
    let status = button.closest('[data-video-player], [data-preview-film], section')?.querySelector('[data-video-status]');
    if (!status) {
      status = document.createElement('p');
      status.className = 'sr-only';
      status.dataset.videoStatus = '';
      status.setAttribute('role', 'status');
      button.parentNode.insertBefore(status, button.nextSibling);
    }
    video.addEventListener('error', () => { status.textContent = '视频暂时无法加载，请尝试下载观看。'; });
    const refresh = () => {
      const playing = !video.paused;
      button.setAttribute('aria-pressed', String(playing));
      const label = button.querySelector('[data-preview-label], [data-video-label]');
      if (label) label.textContent = playing ? '暂停播放' : '播放视频';
      else button.textContent = playing ? '暂停播放' : '播放视频';
    };
    ['play', 'pause', 'ended'].forEach(type => video.addEventListener(type, refresh));
    button.addEventListener('click', async () => {
      if (!video.paused) video.pause();
      else try { status.textContent = ''; await video.play(); } catch (_) { status.textContent = '播放暂时失败，可使用视频原生控件或下载观看。'; }
    });
    refresh();
  });

  // A small, explicit choice illustrates the mechanism; no timed advancement.
  all('.growth-demo').forEach(demo => {
    const buttons = all('button[data-growth-step]', demo);
    const panels = all('[data-growth-panel]', demo);
    if (!buttons.length || !panels.length) return;
    const select = step => {
      const chosen = panels.find(panel => panel.dataset.growthPanel === step);
      if (!chosen) return;
      buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.growthStep === step)));
      panels.forEach(panel => { panel.hidden = panel !== chosen; });
    };
    buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.growthStep)));
    const initial = buttons.find(button => button.getAttribute('aria-pressed') === 'true') || buttons[0];
    select(initial.dataset.growthStep);
    demo.classList.add('is-enhanced');
  });

  document.documentElement.classList.add('js-ready');

  // Content remains visible if JS fails or IntersectionObserver is unsupported.
  const reveal = all('[data-reveal]');
  let observer;
  const settleReveal = () => {
    observer?.disconnect();
    reveal.forEach(node => { node.classList.remove('reveal-pending'); node.classList.add('is-visible'); });
  };
  if (!reduce.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    reveal.forEach(node => {
      // Above-the-fold content is immediately readable, even on a slow device.
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight && box.bottom > 0) node.classList.add('is-visible');
      else { observer.observe(node); node.classList.add('reveal-pending'); }
    });
    document.addEventListener('focusin', event => {
      const section = event.target.closest?.('[data-reveal]');
      if (section) { section.classList.remove('reveal-pending'); section.classList.add('is-visible'); observer.unobserve(section); }
    });
    window.addEventListener('beforeprint', settleReveal);
    window.addEventListener('pageshow', event => { if (event.persisted) settleReveal(); });
  } else settleReveal();
  // Scroll work shares one passive, scheduled update. Native scrolling stays intact.
  const artwork = all('[data-parallax], [data-drift]');
  const moving = new Set();
  let scrollFrame = 0;
  const drawScroll = () => {
    scrollFrame = 0;
    if (reduce.matches) return;
    moving.forEach(node => {
      const box = node.getBoundingClientRect();
      const distance = Math.max(-1, Math.min(1, (box.top + box.height / 2 - innerHeight / 2) / innerHeight));
      node.style.setProperty('--drift', `${(distance * -18).toFixed(2)}px`);
    });
  };
  const queueScroll = () => { if (!scrollFrame) scrollFrame = requestAnimationFrame(drawScroll); };
  if ('IntersectionObserver' in window && artwork.length) {
    const artworkObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => entry.isIntersecting ? moving.add(entry.target) : moving.delete(entry.target));
      queueScroll();
    }, { rootMargin: '100px' });
    artwork.forEach(node => artworkObserver.observe(node));
  }
  addEventListener('scroll', queueScroll, { passive: true });
  addEventListener('resize', queueScroll, { passive: true });
  addEventListener('pageshow', queueScroll);
  if ('ResizeObserver' in window) new ResizeObserver(queueScroll).observe(document.body);
  queueScroll();
  // A preference change immediately settles animations already in progress.
  const motionChanged = () => {
    if (reduce.matches) {
      settleReveal();
      artwork.forEach(node => node.style.setProperty('--drift', '0px'));
    }
    queueScroll();
  };
  if (reduce.addEventListener) reduce.addEventListener('change', motionChanged);
  else reduce.addListener(motionChanged);

})();

/* The dock keeps real links and native vertical scrolling. Only a deliberate
   horizontal drag becomes a liquid selection gesture. No page-wide effects. */
(() => {
  'use strict';
  const dock = document.querySelector('[data-glass-dock]');
  if (!dock || dock.dataset.glassReady) return;
  const lens = dock.querySelector('[data-dock-lens]');
  const links = [...dock.querySelectorAll('[data-dock-item]')];
  const isLink = item => item.hasAttribute('data-dock-link');
  if (!lens || !links.length) return;
  dock.dataset.glassReady = 'true';
  // Anchors remain ordinary links, but their browser drag ghost would cancel
  // the pointer stream before our horizontal liquid gesture can take ownership.
  links.forEach(link => {
    link.setAttribute('draggable', 'false');
    link.querySelectorAll('svg,img').forEach(node => node.setAttribute('draggable', 'false'));
  });
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const aborter = new AbortController();
  const signal = aborter.signal;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  let selected = Math.max(0, links.findIndex(link => link.hasAttribute('aria-current')));
  let dockLeft = 0;
  let boxes = [], current = 0, target = 0, width = 0, targetWidth = 0;
  let velocity = 0, frame = 0, lastTime = 0, gesture = null;
  let scrollImpulse = 0, previousScroll = scrollY, suppressClickUntil = 0;
  let observer = null, resizeObserver = null;

  function paint(stretch = 1, squash = 1) {
    dock.style.setProperty('--lens-x', `${current.toFixed(3)}px`);
    dock.style.setProperty('--lens-width', `${width.toFixed(3)}px`);
    dock.style.setProperty('--lens-stretch', stretch.toFixed(4));
    dock.style.setProperty('--lens-squash', squash.toFixed(4));

    dock.style.setProperty('--lens-velocity', String(clamp(velocity / 22, -1, 1)));
    // Each icon and label is drawn once. Magnify the real content, never a
    // duplicate hidden behind a moving mask (which tears in mobile Safari).
    const center = current + width / 2;
    links.forEach((item, index) => {
      const box = boxes[index];
      const proximity = box ? Math.max(0, 1 - Math.abs(box.x + box.width / 2 - center) / box.width) : 0;
      item.style.setProperty('--dock-scale', String(reduce.matches ? 1 : 1 + proximity * (gesture?.dragging ? .1 : .035)));
    });
  }
  function tick(time) {
    frame = 0;
    if (document.hidden) return;
    const dt = clamp((time - (lastTime || time - 16.667)) / 16.667, .3, 2);
    lastTime = time;
    const delta = target - current;
    velocity = (velocity + delta * .13 * dt) * Math.pow(.66, dt);
    current += velocity * dt;
    width += (targetWidth - width) * (1 - Math.pow(.73, dt));
    scrollImpulse *= Math.pow(.78, dt);
    const strain = Math.min(.20, Math.abs(velocity) * .0055);
    const held = gesture?.dragging ? .045 : 0;
    paint(1 + strain + held, 1 - strain * .43 + held * .45 - Math.min(.012, Math.abs(scrollImpulse) * .0005));
    if (Math.abs(delta) > .035 || Math.abs(velocity) > .035 || Math.abs(width - targetWidth) > .035 || Math.abs(scrollImpulse) > .02) {
      frame = requestAnimationFrame(tick);
    } else {
      current = target; width = targetWidth; velocity = 0; lastTime = 0;
      dock.removeAttribute('data-settling'); paint();
    }
  }
  function animate() {
    if (reduce.matches) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; velocity = 0; lastTime = 0; current = target; width = targetWidth;
      paint(); return;
    }
    if (!frame && !document.hidden) frame = requestAnimationFrame(tick);
  }
  function measure(snap = false) {
    const rect = dock.getBoundingClientRect();
    dockLeft = rect.left + dock.clientLeft;
    boxes = links.map(link => {
      const box = link.getBoundingClientRect();
      return {x: box.left - rect.left - dock.clientLeft, width: box.width, center: box.left + box.width / 2};
    });
    const geometryIndex = selected;
    target = boxes[geometryIndex].x; targetWidth = boxes[geometryIndex].width;
    if (snap || !width) { current = target; width = targetWidth; velocity = 0; paint(); }
    else animate();
  }
  function select(index, snap = false) {
    selected = clamp(index, 0, links.length - 1);
    links.forEach((link, i) => {
      if (i === selected && isLink(link)) link.setAttribute('data-active', 'true');
      else link.removeAttribute('data-active');
      if (i === selected && isLink(link)) link.setAttribute('aria-current', new URL(link.href, location.href).hash ? 'location' : 'page');
      else link.removeAttribute('aria-current');
    });
    if (!boxes.length) return;
    target = boxes[selected].x; targetWidth = boxes[selected].width;
    if (snap) { current = target; width = targetWidth; velocity = 0; paint(); }
    else { dock.setAttribute('data-settling', ''); animate(); }
  }
  function nearest(clientX) {
    return boxes.reduce((best, box, index) => Math.abs(clientX - box.center) < Math.abs(clientX - boxes[best].center) ? index : best, 0);
  }
  function releaseCapture(pointerId) {
    if (dock.hasPointerCapture?.(pointerId)) dock.releasePointerCapture(pointerId);
  }
  function cancelGesture() {
    const old = gesture; gesture = null;
    dock.removeAttribute('data-dragging');
    if (old) releaseCapture(old.id);
    select(selected, reduce.matches);
  }
  dock.addEventListener('contextmenu', event => {
    event.preventDefault();
    if (gesture && !gesture.dragging) { suppressClickUntil = performance.now() + 900; cancelGesture(); }
  }, {signal});
  dock.addEventListener('selectstart', event => event.preventDefault(), {signal});
  dock.addEventListener('dragstart', event => event.preventDefault(), {signal});
  dock.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || event.target.closest('a')?.hasAttribute('download')) return;
    measure();
    gesture = {id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), dragging: false};
  }, {signal, passive: true});
  dock.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
    if (!gesture.dragging) {
      if (Math.abs(dy) > 9 && Math.abs(dy) > Math.abs(dx)) { cancelGesture(); return; }
      if (Math.abs(dx) < 7 || Math.abs(dx) < Math.abs(dy) * 1.15) return;
      gesture.dragging = true;
      dock.setPointerCapture?.(event.pointerId);
      dock.setAttribute('data-dragging', 'true');
    }
    if (event.cancelable) event.preventDefault();
    const first = boxes[0].x, last = boxes.at(-1).x;
    targetWidth = boxes[nearest(event.clientX)].width;
    // Once horizontal intent is established, the lens belongs underneath the
    // finger even if the gesture began over an unselected destination.
    const raw = event.clientX - dockLeft - width / 2;
    target = raw < first ? first + (raw - first) * .16 : raw > last ? last + (raw - last) * .16 : raw;
    animate();
  }, {signal, passive: false});
  dock.addEventListener('pointerup', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const wasDragging = gesture.dragging;
    const held = performance.now() - gesture.started;
    gesture = null;
    dock.removeAttribute('data-dragging');
    releaseCapture(event.pointerId);
    if (!wasDragging) {
      if (held > 550) suppressClickUntil = performance.now() + 450;
      return;
    }
    const next = nearest(event.clientX);
    if (isLink(links[next])) select(next);
    else select(selected);
    // Consume only the compatibility click generated by this drag. Dispatch a
    // real anchor click first so existing navigation handlers remain in charge.
    links[next].click();
    suppressClickUntil = performance.now() + 450;
  }, {signal});
  dock.addEventListener('click', event => {
    if (performance.now() < suppressClickUntil && event.isTrusted && event.detail > 0) {
      suppressClickUntil = 0;
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const link = event.target.closest('[data-dock-item]');
    if (link && isLink(link) && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) select(links.indexOf(link));
  }, {signal, capture: true});
  dock.addEventListener('pointercancel', cancelGesture, {signal});
  dock.addEventListener('lostpointercapture', event => {
    // Touch starts with implicit capture on the anchor. Moving capture to the
    // dock emits a bubbling lostpointercapture for that anchor; it is not loss
    // of the dock's newly acquired pointer and must not cancel the drag.
    if (gesture && event.pointerId === gesture.id && !dock.hasPointerCapture?.(gesture.id)) cancelGesture();
  }, {signal});
  // Native Tab/Enter activation and the focus-visible ring provide keyboard
  // navigation. Focus alone never moves the page-selection lens to a different
  // destination, so a focused control cannot look like a second current page.
  addEventListener('scroll', () => {
    const next = scrollY, difference = next - previousScroll; previousScroll = next;
    if (reduce.matches || document.hidden || gesture) return;
    scrollImpulse = clamp(scrollImpulse + difference * .12, -18, 18);
    animate();
  }, {signal, passive: true});
  const onResize = () => { if (gesture) cancelGesture(); measure(true); };
  addEventListener('resize', onResize, {signal, passive: true});
  if ('ResizeObserver' in window) {
    resizeObserver = new ResizeObserver(onResize); resizeObserver.observe(dock);
  }
  const onMotion = () => { cancelGesture(); scrollImpulse = 0; measure(true); animate(); };
  reduce.addEventListener('change', onMotion, {signal});
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0; scrollImpulse = 0; cancelGesture();
    } else { previousScroll = scrollY; measure(true); }
  }, {signal});
  // Mark in-page destinations as the reader moves through the portfolio.
  const normalizedPath = pathname => pathname.replace(/\/index\.html$/, '/');
  const sameDocument = url => url.origin === location.origin && normalizedPath(url.pathname) === normalizedPath(location.pathname);
  const homeIndex = links.findIndex(link => { if (!isLink(link)) return false; const url = new URL(link.href, location.href); return sameDocument(url) && !url.hash; });
  const localSections = links.map((link, index) => {
    if (!isLink(link)) return null;
    const url = new URL(link.href, location.href);
    return sameDocument(url) && url.hash ? {node: document.getElementById(decodeURIComponent(url.hash.slice(1))), index} : null;
  }).filter(item => item?.node);
  if ('IntersectionObserver' in window && localSections.length) {
    const sectionVisibility = new Map();
    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => sectionVisibility.set(entry.target, entry));
      if (gesture || dock.contains(document.activeElement)) return;
      const visible = [...sectionVisibility.values()].filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio);
      if (visible.length) select(localSections.find(item => item.node === visible[0].target).index);
      else if (homeIndex >= 0) select(homeIndex);
    }, {rootMargin: '-15% 0px -45% 0px', threshold: [0, .15, .4]});
    localSections.forEach(item => observer.observe(item.node));
  }
  measure(true); select(selected, true);
  addEventListener('pagehide', event => {
    cancelGesture();
    if (frame) cancelAnimationFrame(frame);
    frame = 0; velocity = 0; lastTime = 0; scrollImpulse = 0;
    if (event.persisted) return;
    aborter.abort(); observer?.disconnect(); resizeObserver?.disconnect();
    if (frame) cancelAnimationFrame(frame);
  }, {signal});
  addEventListener('pageshow', event => {
    if (!event.persisted) return;
    suppressClickUntil = 0; previousScroll = scrollY;
    measure(true); select(selected, true);
  }, {signal});
})();
