/* Progressive portfolio interactions. Include once with defer; no dependencies. */
(() => {
  'use strict';
  const all = (selector, root = document) => [...root.querySelectorAll(selector)];
  const byId = id => id ? document.getElementById(id.replace(/^#/, '')) : null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const focusable = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const isOpen = dialog => Boolean(dialog?.hasAttribute('open'));
  const canFocus = node => node && !node.hidden && node.getClientRects().length > 0;
  const fallbackStates = new WeakMap();
  const modalSupported = typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const openers = new WeakMap();
  const triggers = new WeakMap();
  let activeDialog = null;
  let priorOverflow = '';
  let priorGutter = '';
  const outsideStarts = new WeakMap();

  function finishClose(dialog, restoreFocus = true) {
    if (isOpen(dialog) || activeDialog !== dialog) return;
    all('video, audio', dialog).forEach(media => media.pause());
    const opener = openers.get(dialog);
    triggers.get(dialog)?.setAttribute('aria-expanded', 'false');
    const fallback = fallbackStates.get(dialog);
    if (fallback) {
      fallback.backdrop.remove();
      fallback.background.forEach(({ node, inert, hidden }) => {
        if ('inert' in node) node.inert = inert;
        if (hidden === null) node.removeAttribute('aria-hidden'); else node.setAttribute('aria-hidden', hidden);
      });
      if (fallback.style === null) dialog.removeAttribute('style'); else dialog.setAttribute('style', fallback.style);
      if (fallback.role === null) dialog.removeAttribute('role'); else dialog.setAttribute('role', fallback.role);
      dialog.removeAttribute('aria-modal');
      fallbackStates.delete(dialog);
    }
    document.documentElement.style.overflow = priorOverflow;
    document.documentElement.style.scrollbarGutter = priorGutter;
    activeDialog = null;
    if (restoreFocus && opener?.isConnected && canFocus(opener) && !opener.closest('dialog:not([open])')) opener.focus({ preventScroll: true });
  }
  function close(dialog, restoreFocus = true) {
    if (!isOpen(dialog)) return;
    if (fallbackStates.has(dialog)) dialog.removeAttribute('open');
    else dialog.close();
    // Native close events are queued: settle this session before opening another.
    finishClose(dialog, restoreFocus);
  }
  function open(dialog, opener) {
    if (!dialog || dialog.tagName !== 'DIALOG') return false;
    if (isOpen(dialog)) return true;
    const returnOpener = activeDialog && opener?.closest('dialog') === activeDialog ? openers.get(activeDialog) : opener;
    if (activeDialog && activeDialog !== dialog) close(activeDialog, false);
    openers.set(dialog, returnOpener);
    triggers.set(dialog, opener);
    priorOverflow = document.documentElement.style.overflow;
    priorGutter = document.documentElement.style.scrollbarGutter;
    // Reserve the scrollbar lane so opening a dialog does not shift the page.
    document.documentElement.style.scrollbarGutter = 'stable';
    document.documentElement.style.overflow = 'hidden';
    // Older WebViews still receive a usable, focus-contained dialog.
    let nativeOpened = false;
    if (modalSupported) {
      try { dialog.showModal(); nativeOpened = true; } catch (_) { /* Use the local fallback. */ }
    }
    if (!nativeOpened) {
      const backdrop = document.createElement('div');
      backdrop.setAttribute('aria-hidden', 'true');
      backdrop.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(12,20,32,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)';
      const background = all('body > *').filter(node => node !== dialog && !['SCRIPT', 'STYLE'].includes(node.tagName))
        .map(node => ({ node, inert: node.inert, hidden: node.getAttribute('aria-hidden') }));
      fallbackStates.set(dialog, { backdrop, background, style: dialog.getAttribute('style'), role: dialog.getAttribute('role') });
      background.forEach(({ node }) => { if ('inert' in node) node.inert = true; else node.setAttribute('aria-hidden', 'true'); });
      document.body.append(backdrop);
      backdrop.addEventListener('click', () => close(dialog));
      dialog.setAttribute('open', '');
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      Object.assign(dialog.style, { display: 'block', position: 'fixed', zIndex: '9999', inset: '0', margin: 'auto', overflow: 'auto', maxHeight: 'calc(100% - 24px)' });
    }
    activeDialog = dialog;
    opener?.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => {
      if (activeDialog !== dialog || !isOpen(dialog)) return;
      const target = dialog.querySelector('[autofocus]') ||
        dialog.querySelector('[data-dialog-close], button, a[href], input');
      if (target) target.focus({ preventScroll: true });
      else { dialog.tabIndex = -1; dialog.focus({ preventScroll: true }); }
    });
    return true;
  }

  all('dialog').forEach(dialog => {
    if (!modalSupported) dialog.style.display = 'none';
    dialog.addEventListener('close', () => {
      // Ignore an older queued close if this dialog has already reopened.
      finishClose(dialog);
    });
    const outside = event => {
      const box = dialog.getBoundingClientRect();
      return event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom);
    };
    dialog.addEventListener('pointerdown', event => { outsideStarts.set(dialog, outside(event)); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(dialog); });
    dialog.addEventListener('click', event => {
      // A drag starting inside the dialog must never dismiss it on release.
      const startedOutside = outsideStarts.get(dialog);
      outsideStarts.delete(dialog);
      if (!startedOutside || event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close(dialog);
    });
    all('[data-dialog-close], [data-portrait-close]', dialog).forEach(button => button.addEventListener('click', () => close(dialog)));
  });

  all('[data-dialog-open], [data-portrait-open], [data-image-open]').forEach(opener => {
    const id = opener.dataset.dialogOpen || opener.dataset.imageTarget || 'portrait-dialog';
    const dialog = byId(id);
    if (!dialog) {
      // Keep real hrefs operational; dead buttons should not appear interactive.
      if (opener.tagName === 'BUTTON') opener.hidden = true;
      return;
    }
    opener.setAttribute('aria-controls', dialog.id);
    opener.setAttribute('aria-haspopup', 'dialog');
    opener.setAttribute('aria-expanded', 'false');
    opener.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (opener.hasAttribute('data-image-open')) {
        const image = dialog.querySelector('[data-dialog-image]');
        const source = opener.dataset.imageSrc || opener.getAttribute('href');
        if (image && source) {
          let url;
          try { url = new URL(source, location.href); } catch (_) { return; }
          if (!['https:', 'http:'].includes(url.protocol)) return;
          image.src = url.href;
          image.alt = opener.dataset.imageAlt || opener.querySelector('img')?.alt || '作品图片';
        }
      }
      if (open(dialog, opener)) event.preventDefault();
    });
  });

  document.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.defaultPrevented) return;
    if (activeDialog && event.key === 'Escape') { event.preventDefault(); close(activeDialog); return; }
    if (!activeDialog || !fallbackStates.has(activeDialog)) return;
    if (event.key === 'Tab') {
      const targets = all(focusable, activeDialog).filter(canFocus);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) { event.preventDefault(); activeDialog.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    }
  });

  // No autoplay, scroll hijacking, or automatic audio resumption.
  // Native video controls remain the single playback surface.
  const pauseMedia = () => all('video').forEach(media => media.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMedia(); });
  window.addEventListener('pagehide', pauseMedia);

  // A small, explicit choice illustrates the mechanism; no timed advancement.
  all('.growth-demo').forEach(demo => {
    const buttons = all('button[data-growth-step]', demo);
    const panels = all('[data-growth-panel]', demo);
    if (!buttons.length || !panels.length) return;
    let growthMotion=null;
    const select = (step,animate=true) => {
      growthMotion?.cancel();
      const chosen = panels.find(panel => panel.dataset.growthPanel === step);
      if (!chosen) return;
      buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.growthStep === step)));
      panels.forEach(panel => { panel.hidden = panel !== chosen; });
      if(animate&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
        const plant=chosen.querySelector('img');
        if(plant){growthMotion=plant.animate([{opacity:.45,transform:'translateY(10px) scale(.86)'},{opacity:1,transform:'none'}],{duration:300,easing:'cubic-bezier(.2,.8,.2,1)'});growthMotion.finished.catch(()=>{});}
      }
    };
    buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.growthStep)));
    const initial = buttons.find(button => button.getAttribute('aria-pressed') === 'true') || buttons[0];
    select(initial.dataset.growthStep,false);
    demo.classList.add('is-enhanced');
  });

  document.documentElement.classList.add('js-ready');

  // Content remains visible if JS fails or IntersectionObserver is unsupported.
  const reveal = all('[data-reveal]');
  let observer;
  const settleReveal = () => {
    observer?.disconnect();
    reveal.forEach(node => { node.classList.remove('reveal-pending'); node.classList.add('is-visible'); });
  };
  if (!reduce.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    reveal.forEach(node => {
      // Above-the-fold content is immediately readable, even on a slow device.
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight && box.bottom > 0) node.classList.add('is-visible');
      else { observer.observe(node); node.classList.add('reveal-pending'); }
    });
    document.addEventListener('focusin', event => {
      const section = event.target.closest?.('[data-reveal]');
      if (section) { section.classList.remove('reveal-pending'); section.classList.add('is-visible'); observer.unobserve(section); }
    });
    window.addEventListener('beforeprint', settleReveal);
    window.addEventListener('pageshow', event => { if (event.persisted) settleReveal(); });
  } else settleReveal();
  // Only active reveal effects respond to the motion preference.
  const motionChanged = () => { if (reduce.matches) settleReveal(); };
  if (reduce.addEventListener) reduce.addEventListener('change', motionChanged);
  else reduce.addListener(motionChanged);
})();

/* The dock keeps real links and native vertical scrolling. Only a deliberate
   horizontal drag becomes a liquid selection gesture. No page-wide effects. */
(() => {
  'use strict';
  const dock = document.querySelector('[data-glass-dock]');
  if (!dock || dock.dataset.glassReady) return;
  const lens = dock.querySelector('[data-dock-lens]');
  const links = [...dock.querySelectorAll('[data-dock-item]')];
  const isLink = item => item.hasAttribute('data-dock-link');
  if (!lens || !links.length) return;
  dock.dataset.glassReady = 'true';
  // Anchors remain ordinary links, but their browser drag ghost would cancel
  // the pointer stream before our horizontal liquid gesture can take ownership.
  links.forEach(link => {
    link.setAttribute('draggable', 'false');
    link.querySelectorAll('svg,img').forEach(node => node.setAttribute('draggable', 'false'));
  });
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const aborter = new AbortController();
  const signal = aborter.signal;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  let selected = Math.max(0, links.findIndex(link => link.hasAttribute('aria-current')));
  let dockLeft = 0, measuredRect = null;
  let boxes = [], current = 0, target = 0, width = 0, targetWidth = 0;
  let velocity = 0, frame = 0, lastTime = 0, gesture = null;
  let suppressClickUntil = 0, navigationTimer = 0, dragActivation = false;
  let heldScale = 0, heldVelocity = 0;
  let resizeObserver = null, contrastObserver = null, pendingHref = '';
  const contrastSources = [...document.querySelectorAll('video, .dark, [data-dock-tone=dark]')];
  function observeContrast() {
    contrastObserver?.disconnect();
    if (!contrastSources.length || !('IntersectionObserver' in window)) return;
    const box = dock.getBoundingClientRect();
    const viewportHeight = window.innerHeight, viewportWidth = window.innerWidth;
    const center = box.top + box.height / 2;
    const active = new Set();
    contrastObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) active.add(entry.target); else active.delete(entry.target); });
      dock.toggleAttribute('data-over-media', active.size > 0);
    }, {rootMargin:`${-center}px ${-(viewportWidth - box.right)}px ${-(viewportHeight - center - 1)}px ${-box.left}px`, threshold:0});
    contrastSources.forEach(node => contrastObserver.observe(node));
  }
  const handoffKey = 'portfolio-dock-handoff-v2';
  const normalizedPath = pathname => pathname.replace(/\/index\.html$/, '/');
  function samePage(a, b) {
    return a.origin === b.origin && normalizedPath(a.pathname) === normalizedPath(b.pathname) && a.search === b.search;
  }
  function clearHandoff() {
    pendingHref = '';
    try { sessionStorage.removeItem(handoffKey); } catch (_) { /* Storage may be disabled. */ }
  }
  function saveHandoff() {
    if (!pendingHref || reduce.matches || boxes.length < 2) return;
    const span = boxes.at(-1).x - boxes[0].x;
    if (span <= 0) return;
    try {
      sessionStorage.setItem(handoffKey, JSON.stringify({
        href: pendingHref, at: Date.now(), fraction: (current - boxes[0].x) / span,
        speed: clamp(velocity / span, -3, 3), lift: heldScale
      }));
    } catch (_) { /* Ordinary anchor navigation remains available without storage. */ }
  }
  function restoreHandoff() {
    let state;
    try {
      state = JSON.parse(sessionStorage.getItem(handoffKey));
      sessionStorage.removeItem(handoffKey);
    } catch (_) { return; }
    if (reduce.matches || !state || typeof state.href !== 'string' ||
        !Number.isFinite(state.at) || Date.now() - state.at < 0 || Date.now() - state.at > 10000 ||
        !Number.isFinite(state.fraction) || state.fraction < -.1 || state.fraction > 1.1 ||
        !Number.isFinite(state.speed) || !Number.isFinite(state.lift)) return;
    try { if (!samePage(new URL(state.href, location.href), new URL(location.href))) return; } catch (_) { return; }
    const span = boxes.at(-1).x - boxes[0].x;
    current = boxes[0].x + state.fraction * span;
    velocity = clamp(state.speed, -3, 3) * span;
    heldScale = clamp(state.lift, 0, 1);
    paint(1 + heldScale * .09, 1 + heldScale * .16);
    animate();
  }

  // The shell alone samples the backdrop. The empty lens is one composited
  // surface: no filters, cloned labels, width animation or per-item frame writes.
  function paint(stretch = 1, squash = 1) {
    lens.style.setProperty('--lens-x', `${current.toFixed(3)}px`);
    lens.style.setProperty('--lens-stretch', stretch.toFixed(4));
    lens.style.setProperty('--lens-squash', squash.toFixed(4));
    lens.style.setProperty('--lens-glint-shift', `${clamp(velocity * .008, -10, 10).toFixed(3)}px`);
    lens.style.setProperty('--lens-glint-alpha', (.2 + Math.min(.45, Math.abs(velocity) * .0003 + Math.abs(heldScale) * .24)).toFixed(3));
  }
  function tick(time) {
    frame = 0;
    if (document.hidden) return;
    const dt = clamp((time - (lastTime || time - 16.667)) / 1000, .001, 1);
    lastTime = time;
    // Closed-form springs are stable across long frames: use real elapsed time
    // so rendering pressure cannot stretch a short release into idle animation.
    if (gesture?.dragging) {
      // Coalesce input into one paint per display frame; do not make the finger
      // chase a spring. Only the released lens settles with inertia.
      velocity = (target - current) / dt;
      current = target;
    } else {
      const omega = 24;
      const offset = current - target, c = velocity + omega * offset;
      const decay = Math.exp(-omega * dt);
      current = target + (offset + c * dt) * decay;
      velocity = (velocity - omega * c * dt) * decay;
    }
    const heldTarget = gesture ? 1 : 0;
    // Closed-form damped droplet response: one restrained release ripple,
    // independent of display refresh rate and with no geometry/filter animation.
    const frequency = 30, damping = .72, decayLift = Math.exp(-damping * frequency * dt);
    const damped = frequency * Math.sqrt(1 - damping * damping);
    const liftOffset = heldScale - heldTarget;
    const liftB = (heldVelocity + damping * frequency * liftOffset) / damped;
    const liftCos = Math.cos(damped * dt), liftSin = Math.sin(damped * dt);
    heldScale = heldTarget + decayLift * (liftOffset * liftCos + liftB * liftSin);
    heldVelocity = decayLift * ((-damping * frequency * liftOffset + damped * liftB) * liftCos
      + (-damping * frequency * liftB - damped * liftOffset) * liftSin);
    const strain = Math.min(.15, Math.abs(velocity) * .00013);
    paint(1 + strain + heldScale * .09, 1 - strain * .32 + heldScale * .16);
    if (Math.abs(current - target) > .03 || Math.abs(velocity) > .15 || Math.abs(heldTarget - heldScale) > .002 || Math.abs(heldVelocity) > .04) {
      frame = requestAnimationFrame(tick);
    } else {
      current = target; velocity = 0; lastTime = 0; heldScale = heldTarget; heldVelocity = 0;
      dock.removeAttribute('data-settling');
      paint(1 + heldScale * .09, 1 + heldScale * .16);
    }
  }
  function animate() {
    if (reduce.matches) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; velocity = 0; lastTime = 0; current = target; width = targetWidth; heldScale = 0; heldVelocity = 0;
      paint(); return;
    }
    if (!frame && !document.hidden) {
      if (!lastTime) lastTime = performance.now();
      frame = requestAnimationFrame(tick);
    }
  }
  function measure(snap = false) {
    const rect = dock.getBoundingClientRect();
    measuredRect = {left:rect.left, width:rect.width, height:rect.height};
    dockLeft = rect.left + dock.clientLeft;
    boxes = links.map(link => {
      const box = link.getBoundingClientRect();
      return {x: box.left - rect.left - dock.clientLeft, width: box.width, center: box.left + box.width / 2};
    });
    const geometryIndex = selected;
    target = boxes[geometryIndex].x; targetWidth = boxes[geometryIndex].width;
    width = targetWidth;
    lens.style.setProperty('--lens-width', `${width.toFixed(3)}px`);
    if (snap || !width) { current = target; width = targetWidth; velocity = 0; paint(); }
    else animate();
  }
  function select(index, snap = false) {
    selected = clamp(index, 0, links.length - 1);
    links.forEach((link, i) => {
      if (i === selected && isLink(link)) link.setAttribute('data-active', 'true');
      else link.removeAttribute('data-active');
      if (i === selected && isLink(link)) link.setAttribute('aria-current', new URL(link.href, location.href).hash ? 'location' : 'page');
      else link.removeAttribute('aria-current');
    });
    if (!boxes.length) return;
    target = boxes[selected].x; targetWidth = boxes[selected].width;
    if (snap) { current = target; width = targetWidth; velocity = 0; paint(); }
    else { dock.setAttribute('data-settling', ''); animate(); }
  }
  function nearest(clientX) {
    return boxes.reduce((best, box, index) => Math.abs(clientX - box.center) < Math.abs(clientX - boxes[best].center) ? index : best, 0);
  }
  function releaseCapture(pointerId) {
    if (dock.hasPointerCapture?.(pointerId)) dock.releasePointerCapture(pointerId);
  }
  function cancelGesture() {
    const old = gesture; gesture = null;
    velocity = 0;
    dock.removeAttribute('data-dragging');
    if (old) releaseCapture(old.id);
    select(selected, reduce.matches);
  }
  dock.addEventListener('contextmenu', event => {
    // Keep desktop link menus (including Ctrl-click on macOS) available. Only
    // the touch hold needs suppression to avoid callouts and selected labels.
    if (event.button === 2 || event.ctrlKey || event.pointerType === 'mouse') return;
    event.preventDefault();
    if (gesture && !gesture.dragging) { suppressClickUntil = performance.now() + 900; cancelGesture(); }
  }, {signal});
  dock.addEventListener('selectstart', event => event.preventDefault(), {signal});
  dock.addEventListener('dragstart', event => event.preventDefault(), {signal});
  dock.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || event.target.closest('a')?.hasAttribute('download')) return;
    if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = 0; clearHandoff(); }
    measure();
    gesture = {id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), dragging: false};
    animate();
  }, {signal, passive: true});
  dock.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
    if (!gesture.dragging) {
      if (Math.abs(dy) > 9 && Math.abs(dy) > Math.abs(dx)) { cancelGesture(); return; }
      if (Math.abs(dx) < 7 || Math.abs(dx) < Math.abs(dy) * 1.15) return;
      gesture.dragging = true;
      dock.setPointerCapture?.(event.pointerId);
      dock.setAttribute('data-dragging', 'true');
    }
    if (event.cancelable) event.preventDefault();
    const first = boxes[0].x, last = boxes.at(-1).x;
    // Once horizontal intent is established, the lens belongs underneath the
    // finger even if the gesture began over an unselected destination.
    const raw = event.clientX - dockLeft - width / 2;
    target = raw < first ? first + (raw - first) * .16 : raw > last ? last + (raw - last) * .16 : raw;
    animate();
  }, {signal, passive: false});
  dock.addEventListener('pointerup', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const wasDragging = gesture.dragging;
    const held = performance.now() - gesture.started;
    gesture = null;
    dock.removeAttribute('data-dragging');
    releaseCapture(event.pointerId);
    if (!wasDragging) {
      // A held press can already have settled and stopped its frame loop.
      // Always restart on release, even when no click follows the long hold.
      animate();
      if (held > 550) suppressClickUntil = performance.now() + 450;
      return;
    }
    velocity = clamp(velocity, -750, 750);
    const next = nearest(event.clientX);
    if (isLink(links[next])) select(next);
    else select(selected);
    // Consume only the compatibility click generated by this drag. Dispatch a
    // real anchor click first so existing navigation handlers remain in charge.
    dragActivation = event.isTrusted;
    links[next].click();
    dragActivation = false;
    suppressClickUntil = performance.now() + 450;
  }, {signal});
  dock.addEventListener('click', event => {
    if (performance.now() < suppressClickUntil && event.isTrusted && event.detail > 0) {
      suppressClickUntil = 0;
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const link = event.target.closest('[data-dock-item]');
    if (!link || !isLink(link) || link.hasAttribute('download') || link.getAttribute('target') === '_blank' || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
    select(links.indexOf(link));
    const url = new URL(link.href, location.href);
    const currentURL = new URL(location.href);
    // Native cross-document navigation otherwise destroys the selection animation
    // before its first frame. A short, cancellable handoff makes it visible.
    if ((event.isTrusted || dragActivation) && url.origin === location.origin &&
        !samePage(url, currentURL)) {
      event.preventDefault();
      if (navigationTimer) clearTimeout(navigationTimer);
      pendingHref = url.href;
      if (reduce.matches) { clearHandoff(); location.assign(url.href); }
      else navigationTimer = setTimeout(() => {
        navigationTimer = 0;
        saveHandoff();
        location.assign(url.href);
      }, 110);
    }
  }, {signal, capture: true});
  dock.addEventListener('pointercancel', cancelGesture, {signal});
  // A mouse press has no implicit capture. If it leaves the dock before a
  // horizontal drag begins, its release never reaches the dock listener.
  // Clear that held state without activating an unrelated destination.
  addEventListener('pointerup', event => {
    if (gesture && event.pointerId === gesture.id && !dock.contains(event.target)) cancelGesture();
  }, {signal});
  addEventListener('blur', () => { if (gesture) cancelGesture(); }, {signal});
  dock.addEventListener('lostpointercapture', event => {
    // Touch starts with implicit capture on the anchor. Moving capture to the
    // dock emits a bubbling lostpointercapture for that anchor; it is not loss
    // of the dock's newly acquired pointer and must not cancel the drag.
    if (gesture && event.pointerId === gesture.id && !dock.hasPointerCapture?.(gesture.id)) cancelGesture();
  }, {signal});
  // Native Tab/Enter activation and the focus-visible ring provide keyboard
  // navigation. Focus alone never moves the page-selection lens to a different
  // destination, so a focused control cannot look like a second current page.
  const onResize = event => {
    // ResizeObserver delivers an initial notification even without a resize.
    // Snapping that notification would erase a just-restored cross-page spring.
    const rect = dock.getBoundingClientRect();
    const changed = !measuredRect || rect.left !== measuredRect.left || rect.width !== measuredRect.width || rect.height !== measuredRect.height;
    if (!changed && !event?.type) return;
    if (gesture) cancelGesture();
    measure(true);
    observeContrast();
  };
  addEventListener('resize', onResize, {signal, passive: true});
  if ('ResizeObserver' in window) {
    resizeObserver = new ResizeObserver(onResize); resizeObserver.observe(dock);
  }
  const onMotion = () => { cancelGesture(); measure(true); animate(); };
  reduce.addEventListener('change', onMotion, {signal});
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0; cancelGesture();
    } else { measure(true); }
  }, {signal});
  // Each tab now names a separate page, including contact. Scrolling inside a
  // document never changes its current-page semantics or runs a section observer.
  measure(true); select(selected, true); restoreHandoff(); observeContrast();
  addEventListener('pagehide', event => {
    // Capture the actual departure position after loading time, rather than the
    // earlier click position, so the next document continues the same movement.
    saveHandoff();
    cancelGesture();
    if (frame) cancelAnimationFrame(frame);
    frame = 0; velocity = 0; lastTime = 0;
    if (navigationTimer) clearTimeout(navigationTimer);
    navigationTimer = 0;
    if (event.persisted) return;
    aborter.abort(); resizeObserver?.disconnect(); contrastObserver?.disconnect();
    if (frame) cancelAnimationFrame(frame);
  }, {signal});
  addEventListener('pageshow', event => {
    if (!event.persisted) return;
    suppressClickUntil = 0;
    heldScale = 0; heldVelocity = 0; velocity = 0;
    measure(true); select(selected, true);
  }, {signal});
})();

/* Small portfolio-only keyboard improvements. Existing springs, pointer input,
 * native scrolling, dialogs and click activation each keep their single owner. */
(() => {
  'use strict';
  if (!document.body.matches('.home-page,.inner-page')) return;

  // Preserve saved links to business cards whose full cases now live in Experience.
  if (/\/projects\/(?:index\.html)?$/.test(location.pathname)) {
    const destination = {'#service-work':'ecommerce','#campus-work':'printing'}[location.hash];
    if (destination) { location.replace(new URL('../experience/index.html#'+destination,location.href)); return; }
  }

  const dock = document.querySelector('[data-glass-dock]');
  if (dock && !dock.dataset.keyboardNavigation) {
    dock.dataset.keyboardNavigation = 'ready';
    dock.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey || event.isComposing) return;
      const links = [...dock.querySelectorAll('a[data-dock-link][href]')];
      const current = links.indexOf(event.target);
      if (current < 0) return;
      const reverse = getComputedStyle(dock).direction === 'rtl' ? -1 : 1;
      let next;
      if (event.key === 'ArrowRight') next = (current + reverse + links.length) % links.length;
      else if (event.key === 'ArrowLeft') next = (current - reverse + links.length) % links.length;
      else if (event.key === 'Home') next = 0;
      else if (event.key === 'End') next = links.length - 1;
      else return;
      // Arrow keys only move focus. Current-page semantics and the material
      // selection remain truthful until the user activates a real destination.
      event.preventDefault();
      links[next].focus({preventScroll:true});
    });
  }

  const focusDeepLink = () => {
    if (!location.hash || document.querySelector('dialog[open]')) return;
    let id;
    try { id = decodeURIComponent(location.hash.slice(1)); } catch { return; }
    const target = document.getElementById(id);
    if (!target || !target.closest('main') || !target.getClientRects().length) return;
    const active = document.activeElement;
    if (active && active !== document.body && active !== document.documentElement && active.tagName !== 'A') return;
    if (active?.tagName === 'A') {
      let destination;
      try { destination = new URL(active.href,location.href); } catch { return; }
      if (destination.pathname !== location.pathname || destination.hash !== location.hash) return;
    }
    const heading = target.matches('h1,h2,h3') ? target : target.querySelector('h1,h2,h3');
    const destination = heading || target;
    const previous = destination.getAttribute('tabindex');
    destination.setAttribute('tabindex','-1');
    destination.dataset.anchorFocus = '';
    // The browser owns the anchor scroll. This moves only the reading/focus
    // position, so keyboard and screen-reader users arrive at the same section.
    destination.focus({preventScroll:true});
    destination.addEventListener('blur', () => {
      if (previous === null) destination.removeAttribute('tabindex');
      else destination.setAttribute('tabindex',previous);
      delete destination.dataset.anchorFocus;
    }, {once:true});
  };
  addEventListener('hashchange',focusDeepLink);
  addEventListener('pageshow',event => { if (!event.persisted) focusDeepLink(); });
  // Once-only reading transitions: content is visible before JavaScript and
  // pressure/focus always wins over an entrance that is still in progress.
  const motionPreference=matchMedia('(prefers-reduced-motion: reduce)');
  const entranceAnimations=new Map();
  let entranceObserver;
  function clearEntrances(){
    entranceObserver?.disconnect();
    for(const animation of entranceAnimations.values())animation.cancel();
    entranceAnimations.clear();
  }
  function observeEntrances(){
    if(motionPreference.matches||!('IntersectionObserver' in window))return;
    const nodes=[...document.querySelectorAll('.practice-glass,.work-card,.detail-row-list,.case-study,.detail-split,.contact-identity')];
    entranceObserver=new IntersectionObserver(entries=>{
      if(motionPreference.matches)return;
      for(const entry of entries){
        if(!entry.isIntersecting)continue;
        const node=entry.target;entranceObserver.unobserve(node);
        if(node.dataset.motionEntered)continue;
        node.dataset.motionEntered='true';
        if(node.matches(':focus-within,[data-glass-pressed="true"]'))continue;
        const animation=node.animate([{opacity:.65,translate:'0 20px'},{opacity:1,translate:'0 0'}],{duration:650,easing:'cubic-bezier(.22,1,.36,1)'});
        entranceAnimations.set(node,animation);
        animation.finished.catch(()=>{}).finally(()=>{if(entranceAnimations.get(node)===animation)entranceAnimations.delete(node);});
      }
    },{threshold:.12});
    nodes.filter(node=>!node.dataset.motionEntered&&!node.closest('[data-reveal]')).forEach(node=>entranceObserver.observe(node));
  }
  function yieldToInput(event){
    for(const [node,animation] of entranceAnimations)if(node.contains(event.target)){animation.cancel();entranceAnimations.delete(node);}
  }
  document.addEventListener('pointerdown',yieldToInput,{passive:true,capture:true});
  document.addEventListener('focusin',yieldToInput,{passive:true});
  motionPreference.addEventListener('change',()=>{clearEntrances();observeEntrances();});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clearEntrances();else observeEntrances();});
  addEventListener('pagehide',clearEntrances);
  addEventListener('pageshow',event=>{if(event.persisted)observeEntrances();});
  observeEntrances();
})();

/* Actual previews and direct contact utilities, progressively enhanced. */
(() => {
  'use strict';
  if (!document.body.matches('.home-page,.inner-page')) return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  for(const workbench of document.querySelectorAll('[data-studio-preview]')) {
    const tabs=[...workbench.querySelectorAll('[data-studio-tab]')];
    const panels=[...workbench.querySelectorAll('[data-studio-panel]')];
    if(!tabs.length||tabs.length!==panels.length)continue;
    let active=0,transition=null,heightTransition=null;
    const tablist=workbench.querySelector('[role="tablist"]');
    function measureSelection(){
      const selected=tabs[active];
      tablist.style.setProperty('--studio-tab-x',selected.offsetLeft+'px');
      tablist.style.setProperty('--studio-tab-width',selected.offsetWidth+'px');
    }
    function select(index,focus=false,animate=true){
      if(index<0||index>=tabs.length)return;
      const before=workbench.getBoundingClientRect().height;
      transition?.cancel();heightTransition?.cancel();
      active=index;
      tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;});
      panels.forEach((panel,i)=>{panel.hidden=i!==index;panel.tabIndex=i===index?0:-1;});
      measureSelection();
      if(focus)tabs[index].focus({preventScroll:true});
      if(animate&&!reduced.matches&&panels[index].animate){
        const after=workbench.getBoundingClientRect().height;
        heightTransition=workbench.animate([{height:before+'px'},{height:after+'px'}],{duration:460,easing:'cubic-bezier(.22,1,.36,1)'});
        heightTransition.finished.catch(()=>{});
        transition=panels[index].animate([{opacity:.45,transform:'perspective(1000px) translate3d(0,16px,-18px) scale(.985)'},{opacity:1,transform:'none'}],{duration:460,easing:'cubic-bezier(.22,1,.36,1)'});
        transition.finished.catch(()=>{});
      }
    }
    tabs.forEach((tab,index)=>{
      tab.addEventListener('click',()=>select(index));
      tab.addEventListener('keydown',event=>{
        if(event.altKey||event.ctrlKey||event.metaKey||event.shiftKey)return;
        const focused=tabs.indexOf(event.currentTarget);
        const current=focused<0?active:focused;
        let index;
        if(event.key==='ArrowRight')index=(current+1)%tabs.length;
        else if(event.key==='ArrowLeft')index=(current-1+tabs.length)%tabs.length;
        else if(event.key==='Home')index=0;
        else if(event.key==='End')index=tabs.length-1;
        else return;
        event.preventDefault();select(index,true);
      });
    });
    workbench.querySelector('[role="tablist"]').hidden=false;
    workbench.classList.add('is-interactive');
    select(0,false,false);
    workbench.dataset.studioReady='true';
    if('ResizeObserver' in window)new ResizeObserver(measureSelection).observe(tablist);
    document.fonts?.ready.then(measureSelection);
    // A horizontal gesture changes the actual work preview; vertical scrolling stays native.
    let gesture=null,suppressClick=false,clickTimer;
    const clearGesture=()=>{
      if(gesture){gesture.panel.style.removeProperty('translate');gesture.panel.removeAttribute('data-studio-dragging');}
      gesture=null;
    };
    workbench.addEventListener('pointerdown',event=>{
      if(gesture||!event.isPrimary||event.button!==0||!['touch','pen'].includes(event.pointerType))return;
      const panel=event.target.closest('[data-studio-panel]');
      if(!panel||panel.hidden||event.target.closest('button,input,video,summary'))return;
      transition?.cancel();gesture={id:event.pointerId,x:event.clientX,y:event.clientY,panel,dx:0,locked:false};
    },{passive:true});
    workbench.addEventListener('pointermove',event=>{
      if(!gesture||event.pointerId!==gesture.id)return;
      const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y;
      if(!gesture.locked){
        if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){clearGesture();return;}
        if(Math.abs(dx)<12||Math.abs(dx)<Math.abs(dy)*1.25)return;
        gesture.locked=true;
        try{gesture.panel.setPointerCapture(event.pointerId);}catch{/* Synthetic inputs do not own native capture. */}
        gesture.panel.setAttribute('data-studio-dragging','');
      }
      gesture.dx=dx;
      if(!reduced.matches)gesture.panel.style.translate=Math.max(-55,Math.min(55,dx*.25))+'px 0';
    },{passive:true});
    const finishGesture=event=>{
      if(!gesture||event.pointerId!==gesture.id)return;
      const ended=gesture,commit=event.type==='pointerup'&&ended.locked&&Math.abs(ended.dx)>55;
      if(ended.locked){
        suppressClick=true;clearTimeout(clickTimer);clickTimer=setTimeout(()=>{suppressClick=false;},400);
      }
      clearGesture();
      if(commit){
        const direction=getComputedStyle(workbench).direction==='rtl'?-1:1;
        const next=Math.max(0,Math.min(tabs.length-1,active+(ended.dx<0?1:-1)*direction));
        if(next!==active)select(next);
      }
    };
    workbench.addEventListener('pointerup',finishGesture);
    workbench.addEventListener('pointercancel',finishGesture);
    workbench.addEventListener('lostpointercapture',event=>{if(gesture?.id===event.pointerId&&event.target===gesture.panel)clearGesture();});
    workbench.addEventListener('click',event=>{if(suppressClick){event.preventDefault();event.stopPropagation();suppressClick=false;}},true);
    reduced.addEventListener('change',()=>{transition?.cancel();heightTransition?.cancel();clearGesture();measureSelection();});
    addEventListener('pagehide',()=>{heightTransition?.cancel();transition?.cancel();clearGesture();clearTimeout(clickTimer);suppressClick=false;});
  }
  document.addEventListener('click',event=>{
    const trigger=event.target.closest?.('[data-play-intro]');
    if(!trigger||event.defaultPrevented||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const video=document.querySelector('#intro-video');if(!video)return;
    event.preventDefault();
    video.scrollIntoView({behavior:reduced.matches?'instant':'smooth',block:'center'});
    video.play().catch(()=>{video.tabIndex=0;video.focus({preventScroll:true});});
  });
  // Material follows the surface beneath the dock; no extra navigation layer.
  const hero=document.querySelector('[data-era-hero]');
  const dock=document.querySelector('[data-glass-dock]');
  if(hero&&dock){
    let scheduled=false;
    const update=()=>{
      scheduled=false;
      const scene=hero.getBoundingClientRect(),control=dock.getBoundingClientRect();
      document.body.dataset.eraDark=String(scene.top<=control.top&&scene.bottom>=control.bottom);
    };
    const schedule=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update);}};
    addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});
    update();
  }
  // Offscreen geometry pauses instead of running unseen for the full page.
  if('IntersectionObserver' in window){
    const scenes=new IntersectionObserver(entries=>{
      for(const entry of entries)entry.target.toggleAttribute('data-paused',!entry.isIntersecting);
    },{rootMargin:'80px'});
    document.querySelectorAll('.era-silk').forEach(scene=>scenes.observe(scene));
  }
  // Native anchor links keep their URL and keyboard behavior; the index follows reading.
  const caseIndex=document.querySelector('.case-index');
  if(caseIndex){
    const links=[...caseIndex.querySelectorAll('a[href^="#"]')];
    const entries=links.map(link=>({link,section:document.querySelector(link.getAttribute('href'))})).filter(item=>item.section);
    let scheduled=false,intent=null;
    const update=()=>{
      scheduled=false;const edge=Math.max(160,innerHeight*.25);
      const atEdge=entries.filter(item=>item.section.getBoundingClientRect().top<=edge).at(-1);
      if(intent&&(performance.now()>intent.until||atEdge===intent.item))intent=null;
      const current=intent?.item||atEdge;
      for(const item of entries){if(item===current)item.link.setAttribute('aria-current','location');else item.link.removeAttribute('aria-current');}
    };
    const schedule=()=>{if(!scheduled){scheduled=true;requestAnimationFrame(update);}};
    caseIndex.addEventListener('click',event=>{
      if(event.defaultPrevented||event.button>0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey)return;
      const link=event.target.closest('a[href]'),item=entries.find(item=>item.link===link);
      if(item){intent={item,until:performance.now()+2000};update();}
    });
    const clearIntent=()=>{if(intent){intent=null;schedule();}};
    addEventListener('scrollend',clearIntent,{passive:true});
    addEventListener('wheel',clearIntent,{passive:true});
    addEventListener('pointerdown',clearIntent,{passive:true});
    addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule,{passive:true});update();
  }
  for(const button of document.querySelectorAll('[data-copy-value]')){
    button.hidden=false;
    let timer;
    button.addEventListener('click',async()=>{
      const status=button.closest('[data-contact-row]')?.querySelector('[data-copy-status]');
      try{
        if(!navigator.clipboard?.writeText)throw Error('clipboard unavailable');
        await navigator.clipboard.writeText(button.dataset.copyValue);
        button.textContent='已复制';if(status)status.textContent='已复制到剪贴板';
      }catch{if(status)status.textContent='可长按上方地址复制';}
      clearTimeout(timer);timer=setTimeout(()=>{button.textContent='复制';if(status)status.textContent='';},3500);
    });
  }
})();

/* The optical-glass artwork keeps its geometry, native loading and motion lifecycle. */
(() => {
  'use strict';
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  for(const scene of document.querySelectorAll('.era-silk')){
    const image=scene.querySelector('.spatial-hero-art');if(!image)continue;
    const ready=()=>{if(image.naturalWidth>0){scene.dataset.artState='ready';scene.removeAttribute('data-art-error');}};
    const fallback=()=>{scene.dataset.artState='fallback';scene.setAttribute('data-art-error','');image.hidden=true;};
    image.addEventListener('load',ready,{once:true});image.addEventListener('error',fallback,{once:true});
    if(image.complete){if(image.naturalWidth)ready();else fallback();}
  }
  const hero=document.querySelector('.home-page [data-era-hero]');if(!hero)return;
  let frame=0,active=true,contact=null,last=0;
  const state={x:0,y:0,z:0,read:0},target={x:0,y:0,z:0,read:0};
  function render(now){
    const seconds=last?Math.min((now-last)/1000,.1):1/60;last=now;const damping=1-Math.exp(-seconds*16);
    frame=0;if(document.hidden||!active||reduced.matches)return;
    let remaining=0;
    for(const axis of ['x','y','z','read']){const delta=target[axis]-state[axis];state[axis]+=delta*damping;remaining+=Math.abs(delta);}
    hero.style.setProperty('--art-rotate-x',state.x.toFixed(3)+'deg');
    hero.style.setProperty('--art-rotate-y',state.y.toFixed(3)+'deg');
    hero.style.setProperty('--art-lift',state.z.toFixed(3)+'px');
    hero.style.setProperty('--art-read',state.read.toFixed(4));
    if(remaining>.015)frame=requestAnimationFrame(render);else last=0;
  }
  function schedule(){if(!frame&&active&&!document.hidden&&!reduced.matches)frame=requestAnimationFrame(render);}
  function reset(){
    target.x=target.y=target.z=0;contact=null;
    if(reduced.matches||document.hidden||!active)target.read=0;
    if(reduced.matches||document.hidden||!active){
      if(frame)cancelAnimationFrame(frame);frame=0;last=0;state.x=state.y=state.z=state.read=0;
      hero.style.setProperty('--art-read','0');
      hero.style.setProperty('--hero-light-x','78%');hero.style.setProperty('--hero-light-y','45%');
      hero.style.setProperty('--art-rotate-x','0deg');hero.style.setProperty('--art-rotate-y','0deg');hero.style.setProperty('--art-lift','0px');
    }else schedule();
  }
  function position(event){
    const box=hero.getBoundingClientRect();
    target.x=(Math.max(0,Math.min(1,(event.clientY-box.top)/box.height))-.5)*-9;
    target.y=(Math.max(0,Math.min(1,(event.clientX-box.left)/box.width))-.5)*12;
    hero.style.setProperty('--hero-light-x',((event.clientX-box.left)/box.width*100).toFixed(1)+'%');
    hero.style.setProperty('--hero-light-y',((event.clientY-box.top)/box.height*100).toFixed(1)+'%');
    schedule();
  }
  const read=()=>{if(reduced.matches||document.hidden||!active)return;const box=hero.getBoundingClientRect();target.read=Math.max(0,Math.min(1,-box.top/Math.max(1,box.height)));schedule();};
  addEventListener('scroll',read,{passive:true});addEventListener('resize',read,{passive:true});
  hero.addEventListener('pointermove',event=>{
    if(!event.isPrimary||reduced.matches||(event.pointerType==='touch'&&contact!==event.pointerId))return;
    position(event);
  },{passive:true});
  hero.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0||reduced.matches)return;
    contact=event.pointerId;target.z=14;position(event);
  },{passive:true});
  function release(event){if(contact===event.pointerId)reset();}
  addEventListener('pointerup',release,{passive:true});addEventListener('pointercancel',release,{passive:true});
  hero.addEventListener('pointerleave',reset);
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{active=entries[0].isIntersecting;if(!active)reset();},{rootMargin:'40px'}).observe(hero);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)reset();});
  reduced.addEventListener('change',reset);
  addEventListener('blur',reset);addEventListener('pagehide',reset);
})();

/* Local, source-bound answer composition. Every biographical statement comes
   from the supplied release records; this module makes no network requests. */
(() => {
  'use strict';
  const normalize = value => String(value || '').normalize('NFKC').toLowerCase()
    .replace(/[學歷畢業專聯繫郵電話獎榮譽證書職項經驗戲製營銷視頻軟體華東鐵號絡門點實資頒選擇]/g, c => ({'學':'学','歷':'历','畢':'毕','業':'业','專':'专','聯':'联','繫':'系','郵':'邮','電':'电','話':'话','獎':'奖','榮':'荣','譽':'誉','證':'证','書':'书','職':'职','項':'项','經':'经','驗':'验','戲':'戏','製':'制','營':'营','銷':'销','視':'视','頻':'频','軟':'软','體':'体','華':'华','東':'东','鐵':'铁','號':'号','絡':'络','門':'门','點':'点','實':'实','資':'资','頒':'颁','選':'选','擇':'择'}[c] || c))
    .replace(/([\u3400-\u9fff])\s+(?=[\u3400-\u9fff])/g,'$1');
  const topics = [
    {id:'education', title:'教育背景', section:'教育经历', test:/学历|学厉|教育|学校|院校|大学|本科|专科|专业|毕业|读书|上学|\b(?:degree|education|educational|university|college|school|graduat(?:e|ion)|stud(?:y|ied))\b/, path:/#education$/, followups:['什么时候毕业？','会用哪些工具？','适合什么岗位？']},
    {id:'career', title:'求职方向与已有实践', section:'求职方向', test:/求职|岗位|找工作|应聘|招聘|职业|什么工作|(?:适合|能做|可以做|能胜任|能应聘).*(?:工作|运营|商务|市场|产品|项目执行)|\b(?:career|job|hiring|position)\b/, path:/#roles$/, followups:['有哪些项目成果？','会用哪些工具？','联系方式与简历']},
    {id:'tools', title:'工具与工作方法', section:'工具与工作方法', test:/工具|技能|软件|擅长|能力|会用|办公|\b(?:excel|word|powerpoint|ppt|canva|skills?|tools?|software)\b/, path:/#skills$/, followups:['AI 影像是怎么做的？','有哪些项目成果？','适合什么岗位？']},
    {id:'ecommerce', title:'电商教学与用户增长', section:'电商教学', test:/电商|网店|开店|教学|课程|288|学员|学费|收费|盈利|利润|收入|推广伙伴|获客|分红|\b(?:commerce|tuition|profit)\b/, path:/#ecommerce$/, followups:['具体做了哪些行动？','有哪些实际成果？','适合什么岗位？']},
    {id:'printing', title:'宿舍打印店创业', section:'校园打印创业', test:/打印|彩印|宿舍|寝室|送货上门|一份起送|\bprinting\b/, path:/#printing$/, followups:[]},
    {id:'business', title:'多项目经营成果', section:'经营成果', test:/多项目|所有项目|全部项目|一共赚|总共赚|创业总/, path:/^index\.html#career-lens$/, followups:[]},
    {id:'contact', title:'联系与个人简历', section:'联系与合作', test:/联系|邮箱|电话|手机|微信|合作|简历|履历|\b(?:contact|email|resume|cv)\b|reach you|get in touch/, path:/^contact\//, followups:['适合什么岗位？','30秒了解嘉程','有哪些项目成果？']},
    {id:'ai', title:'AI 影像与内容制作', section:'AI 影像', test:/ai\s*(?:影像|视频)|短视频|影片|剪辑|分镜|seedance|seedream|视频作品/, path:/projects\/ai-content\/|#ai-work$/, followups:['会用哪些工具？','有哪些项目成果？','联系方式与简历']},
    {id:'game', title:'萌芽保卫队与数字产品', section:'萌芽保卫队', test:/萌芽|游戏|塔防|codex|\bgame\b/, path:/projects\/sprout-patrol\/|#digital-work$/, followups:['项目是如何交付的？','会用哪些工具？','AI 影像']},
    {id:'livestream', title:'直播运营实践', section:'直播运营', test:/直播|主播|直播间|抖音/, path:/#livestream$/, followups:['有哪些实际成果？','电商教学','适合什么岗位？']},
    {id:'store', title:'门店经营实践', section:'门店经营', test:/门店|餐饮|餐厅|炸鸡|加盟|采购|实体店/, path:/#store$/, followups:['具体做了哪些行动？','活动策划','适合什么岗位？']},
    {id:'events', title:'活动策划与执行', section:'活动实践', test:/活动|面包|挑战|线下|地推/, path:/#field$/, followups:['有哪些实际成果？','门店经营','联系方式与简历']},
    {id:'honors', title:'荣誉与证书', section:'荣誉与证书', test:/荣誉|获奖|奖项|证书|普通话|学生干部|\b(?:awards?|certificates?)\b/, path:/^honor\//, followups:['教育经历','适合什么岗位？','联系方式与简历']},
    {id:'projects', title:'作品与项目成果', section:'作品与项目', test:/作品|项目|做过什么|成果|\b(?:portfolio|projects?)\b/, path:/^projects\/|#ecommerce$|#printing$|#livestream$|#store$|#field$/, followups:['电商教学有哪些成果？','萌芽保卫队','AI 影像']}
  ];
  // A small vocabulary resolves visitors' own wording to published sections.
  // It never supplies facts: every answer and every hit still comes from records.
  const vocabulary = {
    education:['教育背景','教育经历','毕业院校','毕业学校','学业经历','学厉','学藉','学籍','最高文凭','文凭','学位','哪个学校','哪所学校','哪年毕业','学的什么','读的什么','大学学什么','在哪上过学','在哪读过书','大专','education','degree','university','college','school','graduation'],
    career:['职业规划','职业方向','工作方向','求职意向','意向岗位','就业方向','想找什么','想做什么','愿意做什么','能干什么','适合做什么','career','position','hiring'],
    tools:['技术栈','办公软件','办公能力','工作方法','操作什么','熟悉什么','拿手什么','skills','tools','software','powerpoint'],
    ecommerce:['电子商务','电子商物','电商教课','招生','招学生','教开店','教网店','售后辅导','培训','培训费','商业变现','推广合作','拉新','转化','用户增长','营销','ecommerce','e-commerce','tuition','profit'],
    printing:['打印店','宿舍打印','寝室打印','校园打印','校园创业','校园服务','送货上门','一份起送','黑白打印','彩色打印','彩印','printing'],
    business:['多项目经营','创业总成果','所有项目利润','总共赚了多少'],
    contact:['联络','联糸','邮相','邮件','邮件地址','电话号码','手机号码','手机号','微信号','联系方试','联系方法','个人资料','投递简历','下载简历','resume','contact','email','wechat'],
    ai:['人工智能影像','人工智能视频','叙事短片','影像制作','内容创作','视频制作','成片','剪映','seedance','seedream'],
    game:['网页开发','网站开发','平台开发','软件开发','数字产品','产品开发','做网站','写网站','开发游戏','萌牙保卫队','萌芽保卫对','萌芽保卫','sprout','codex','game'],
    livestream:['直播策划','直播互动','开播','家乡荣耀季','短视频直播','livestream'],
    store:['开店经营','店铺经营','线下经营','实体经营','门店运营','选址','加盟店','炸鸡店','餐馆'],
    events:['线下活动','活动执行','现场执行','活动组织','面包挑战','活动策化','地推活动'],
    honors:['资格证','资格证书','获奖经历','竞赛奖项','荣誉证书','荣誉证件','获奖情况','奖状','awards','certificate'],
    projects:['实践经历','工作经历','项目经历','项目成果','案例','做过哪些事','做过哪些事情','做过什么事','portfolio','projects']
  };
  function oneEditApart(a,b) {
    if (Math.abs(a.length-b.length)>1) return false;
    if (a.length===b.length) {
      const different=[];
      for(let i=0;i<a.length;i++) if(a[i]!==b[i]) different.push(i);
      if(different.length===2) {
        const [i,j]=different;
        if(j===i+1 && a[i]===b[j] && a[j]===b[i]) return true;
      }
    }
    let i=0,j=0,edits=0;
    while(i<a.length && j<b.length) {
      if(a[i]===b[j]) {i++;j++;continue;}
      if(++edits>1) return false;
      if(a.length>=b.length)i++;
      if(b.length>=a.length)j++;
    }
    return edits+(i<a.length || j<b.length ? 1 : 0)<=1;
  }
  function questionWords(key) {
    const core=key.replace(/^(?:你好|小程|请问|请|我想了解一下|我想了解|想了解|我想知道|想知道|告诉我|介绍一下|能不能介绍一下|你能介绍一下|你的|你|嘉程的|马嘉程的)+/,'')
      .replace(/(?:是什么|有哪些|有什么|怎么样|如何|吗|呢|呀|啊|一下|介绍一下|[？?！!。\s])+$/,'');
    return [...new Set([core,...(key.match(/[a-z]+(?:-[a-z]+)?|[\u3400-\u9fff]+/g)||[])])];
  }
  function wordMatch(key,term) {
    if (/^[a-z-]+$/.test(term)) return new RegExp('(?:^|[^a-z])'+term+'(?:$|[^a-z])').test(key);
    return key.includes(term);
  }
  function matchTopics(key) {
    const words=questionWords(key);
    const rejected=[];
    const selected=topics.filter(topic=>{
      const terms=vocabulary[topic.id] || [];
      const exact=topic.test.test(key) || terms.some(term=>wordMatch(key,term)) || (topic.id==='events' && words[0]==='策划');
      const fuzzy=!exact && words.some(word=>terms.some(term=>term.length>=(/^[a-z-]+$/.test(term)?5:4) && oneEditApart(word,term)));
      if(!exact && !fuzzy)return false;
      // Only a clause-local, explicit refusal suppresses a topic. Other words,
      // such as “不太了解学历”, are not negative search filters.
      const clauses=key.split(/[，,。；;！!？?]|(?:只看|只想看|改看|而是)/);
      const refusal=clauses.some(clause=>{
        const scope=clause.trim().split(/还有|以外|之外/)[0];
        return /^(?:我)?(?:不要|不看|排除|不用|别看|不是|除了)/.test(scope) && (topic.test.test(scope) || terms.some(term=>wordMatch(scope,term)));
      });
      if(refusal){rejected.push(topic.id);return false;}
      return true;
    });
    return {selected,rejected};
  }
  const overviewTest = /(?:30|三十)\s*秒|认识嘉程|了解嘉程|介绍(?:一下)?(?:马)?嘉程|自我介绍|你是谁|嘉程是谁|关于(?:你|嘉程)|\b(?:overview|introduce yourself|about you)\b/;
  const contextualTest = /^(?:那|那么|这个|这段|它|他|还有|再|具体|详细|能否|可以)|(?:呢|怎么样|多少|成果|结果|行动|流程|费用|成本|时间|多久|什么时候|怎么做|如何做|收获|职责|分工|交付)[？?！!。\s]*$/;
  const excludedTest = /身份证|家庭住址|家庭地址|银行卡|密码|薪资|薪酬|工资|期望薪|天气|量子|火星|明天.*(?:下雨|温度)|\b(?:weather|password|salary)\b/;
  const creationTest = /(?:请|帮我|为我)(?:写|生成|编写|创作|制定|翻译|计算|算一下)|^(?:写一|写个|写份|生成一|编写一|创作一|制定一|翻译成|计算|算一下)|(?:数学题|方程|微积分|编程题)/;
  const safeRecord = r => r && typeof r.title === 'string' && typeof r.text === 'string' && typeof r.url === 'string'
    && r.text.trim() && /^(?:index\.html|experience\/|projects\/|contact\/|honor\/|poster\/|updates\/)/.test(r.url)
    && !/[<>\\]|\.\./.test(r.url);
  const unique = list => list.filter((item, i, all) => all.findIndex(other => other.text === item.text && other.url === item.url) === i);
  function excerpt(text, limit = 330) {
    const clean = text.trim().replace(/\n{3,}/g, '\n\n');
    if (clean.length <= limit) return clean;
    const segment = clean.slice(0, limit);
    const end = Math.max(segment.lastIndexOf('。'), segment.lastIndexOf('；'), segment.lastIndexOf('\n\n'));
    return end > limit / 3 ? segment.slice(0, end + 1).trim() : segment.trim() + '…';
  }
  function select(topic, records, query) {
    const key = normalize(query);
    const focusActions = /行动|怎么做|如何做|流程|职责|分工/.test(key);
    const focusResults = /成果|结果|成效|收获/.test(key);
    return records.filter(r => topic.path.test(r.url) || r.section === topic.section).map(r => {
      let score = 0;
      if (topic.id === 'education') {
        const priorDegree=/专科|大专/.test(key) && !/本科|最高|学历/.test(key);
        score += /本科/.test(r.text) ? (priorDegree?70:90) : /专科/.test(r.text) ? (priorDegree?100:70) : 0;
      }
      if (topic.id === 'career') score += /希望面向/.test(r.text) ? 50 : 0;
      if (topic.id === 'tools') score += /Excel|Word|PowerPoint|ChatGPT|Codex|Canva|Seedance|Seedream/.test(r.text) ? 40 : 0;
      if (topic.id === 'ecommerce') score += /288.*1,?000|累计去重学员/.test(r.text) ? 65 : 0;
      if (focusActions && /我的行动|我做了什么|目标与职责|如何|分工/.test(r.title)) score += /我的行动|我做了什么/.test(r.title)?140:110;
      if (focusResults && /交付与结果|成果|结果/.test(r.title)) score += 140;
      if (topic.id === 'projects') score += /交付与结果|成果|交付|项目/.test(r.title) ? 35 : 0;
      if (topic.id === 'contact') score += /邮箱|手机|@|198700/.test(r.text) ? 50 : 0;
      score += Math.min(20, (r.text.match(/[0-9]/g) || []).length);
      return {r,score};
    }).sort((a,b) => b.score - a.score).map(item => item.r);
  }
  function topicFacts(topic, sources) {
    const facts = [];
    if (topic.id === 'education') {
      for (const source of sources.filter(r => /本科|专科/.test(r.text)).slice(0,2)) {
        facts.push({label:source.title.split(' · ').pop(), value:source.text});
      }
    }
    if (topic.id === 'ecommerce') {
      const text = sources.map(r => r.text).join('\n');
      const fee = text.match(/\d[\d,，]*(?:\.\d+)?\s*元\s*[/／]\s*人/);
      const students = text.match(/(?:(?:约|近)\s*)?\d[\d,，]*\s*人(?=\s*[·•|]\s*累计去重学员)/)
        || text.match(/约\s*1[，,]?000\s*人/);
      const partners = text.match(/(?:约\s*)?\d+\s*[–—-]\s*\d+\s*(?:人|名)(?=\s*[·•|]\s*推广合作伙伴)/)
        || text.match(/(?:约\s*)?\d+\s*[–—-]\s*\d+\s*(?:人|名)(?=[^。\n]{0,25}推广伙伴)/);
      if (fee) facts.push({label:'教学服务学费', value:fee[0]});
      if (students) facts.push({label:'累计去重学员', value:students[0]});
      if (partners) facts.push({label:'推广合作伙伴', value:partners[0]});
    }
    if (topic.id === 'contact') {
      const text = sources.map(r => r.text).join('\n');
      const email = text.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i);
      const phone = text.match(/(?:手机|电话|手机号|手机号码)[：:\s]*([1][3-9]\d{9})\b/);
      if (email) facts.push({label:'邮箱',value:email[0]});
      if (phone) facts.push({label:'手机',value:phone[1]});
    }
    return facts;
  }
  function answer(query, sourceRecords, context = {}) {
    if (typeof query !== 'string' || !Array.isArray(sourceRecords)) return null;
    const original = query.trim().slice(0,140);
    if (!original || /[<>]|javascript:|\bonerror\s*=/i.test(original)) return null;
    const key = normalize(original);
    if (excludedTest.test(key) || creationTest.test(key)) return null;
    const records = unique(sourceRecords.filter(safeRecord));
    if (!records.length) return null;
    // School tuition and personal salary cannot be inferred from the separate
    // commerce teaching fee; do not blend these unrelated meanings of tuition.
    if (/(?:学校|大学|本科|专科|院校).*(?:学费|费用|收费)|(?:学费|费用|收费).*(?:学校|大学|本科|专科|院校)/.test(key)) return null;
    const overview = overviewTest.test(key);
    let {selected} = matchTopics(key);
    if(selected.some(topic=>['printing','business'].includes(topic.id))&&!/电商|教学|课程|学员|288/.test(key))selected=selected.filter(topic=>topic.id!=='ecommerce');
    const previous = topics.find(topic => topic.id === context?.topic);
    // Named new subjects win; generic outcome/process questions stay with the
    // concrete project the visitor was already reading. A bare "项目" does not
    // erase the previous game/commerce subject in a follow-up.
    const concrete = selected.filter(topic => topic.id !== 'projects');
    const genericDetail = /行动|成果|结果|成效|收获|流程|职责|分工|交付|怎么做|如何/.test(key);
    const keepProject = previous && ['ecommerce','printing','business','ai','game','livestream','store','events'].includes(previous.id)
      && !concrete.length && genericDetail && !/全部|所有|其他|各个|整体/.test(key);
    const contextual = Boolean(previous && (contextualTest.test(key) || keepProject));
    if (contextual && !overview && !concrete.length && (!selected.length || keepProject)) selected = [previous];
    if (/费用|成本/.test(key) && !/电商|课程|教学|学费|打印|彩印/.test(key) && !['ecommerce','printing'].includes(previous?.id)) return null;
    if (overview) selected = ['education','career','ecommerce','game'].map(id=>topics.find(topic=>topic.id===id));
    if (!selected.length) return null;
    // Generic "project results" should not drown a specifically named project.
    if (selected.length > 1 && selected.some(topic => ['ecommerce','printing','business','ai','game','livestream','store','events'].includes(topic.id))) {
      selected = selected.filter(topic => topic.id !== 'projects');
    }
    selected = selected.slice(0,4);
    const sources = [], paragraphs = [], facts = [];
    const isProfit = /净?利润|赚(?:了)?(?:多少|多[少久]?钱)|挣(?:了)?(?:多少|多[少久]?钱)|总收入|总收益|盈利多少/.test(key);
    const isResults = /成果|结果|成效/.test(key);
    for (const topic of selected) {
      let chosen = select(topic, records, original);
      if (topic.id === 'projects' && isResults) chosen = chosen.filter(r => /交付与结果|成果|结果|288/.test(r.title + r.text)).concat(chosen.filter(r => !/交付与结果|成果|结果|288/.test(r.title + r.text)));
      const count = overview ? 1 : selected.length > 1 ? 2 : topic.id === 'education' ? 2 : topic.id === 'career' || topic.id === 'tools' ? 4 : 3;
      chosen = unique(chosen).slice(0,count);
      if (!chosen.length) continue;
      sources.push(...chosen);
      let detailFacts=topicFacts(topic,chosen);
      let factOnly=false;
      if(!overview && topic.id==='contact' && detailFacts.length){
        const emailOnly=/邮箱|邮件|\bemail\b/.test(key) && !/手机|电话|联系|contact|简历|resume|\bcv\b/.test(key);
        const phoneOnly=/手机|电话|手机号/.test(key) && !/邮箱|邮件|联系|contact|简历|resume|\bcv\b/.test(key);
        if(emailOnly)detailFacts=detailFacts.filter(fact=>fact.label==='邮箱');
        if(phoneOnly)detailFacts=detailFacts.filter(fact=>fact.label==='手机');
        factOnly=true;
      }
      if(!overview && topic.id==='ecommerce' && !isProfit && !genericDetail && !isResults){
        const feeOnly=/288|学费|收费|费用|培训费|tuition/.test(key);
        const learnersOnly=/(?:学员|学生).*(?:多少|人数|规模)|(?:多少|几)(?:名|个|位)?(?:学员|学生)|学员数|累计去重/.test(key);
        const partnersOnly=/(?:推广|合作)(?:伙伴|人数)|伙伴.*(?:多少|人数|规模)/.test(key);
        const wanted=feeOnly?'教学服务学费':learnersOnly?'累计去重学员':partnersOnly?'推广合作伙伴':null;
        if(wanted && detailFacts.some(fact=>fact.label===wanted)){
          detailFacts=detailFacts.filter(fact=>fact.label===wanted);factOnly=true;
        }
      }
      facts.push(...detailFacts);
      if(factOnly)continue;
      for (const source of chosen.slice(0,overview ? 1 : selected.length > 1 ? 1 : topic.id === 'education' ? 2 : 3)) {
        if(!overview && topic.id==='ecommerce' && detailFacts.length && /教学服务学费|累计去重学员/.test(source.text))continue;
        const passage = topic.id === 'education' ? `${source.title.split(' · ').pop()}：${source.text}` : excerpt(source.text,overview ? 220 : 350);
        const display = overview ? `${topic.title}：${passage}` : passage;
        if (!paragraphs.includes(display)) paragraphs.push(display);
      }
    }
    if (!sources.length || (!paragraphs.length && !facts.length)) return null;
    if (isProfit && selected.some(topic=>topic.id === 'ecommerce')) {
      const netSource=records.find(record=>/#ecommerce$/.test(record.url)&&(/该项目累计净利润\s*\d/.test(record.text)||/万\s*元(?:以上|\+)?\s*[·•|]\s*该项目累计净利润/.test(record.text)));
      const reported=netSource?.text.match(/该项目累计净利润\s*(\d+(?:\.\d+)?\s*万\s*元(?:以上|\+)?)/)?.[1]
        || netSource?.text.match(/(\d+(?:\.\d+)?\s*万\s*元(?:以上|\+)?)\s*[·•|]\s*该项目累计净利润/)?.[1];
      const perPerson=/一个人|每人|单人|单个|每(?:个|位|名)(?:人|学员)|一位|一名/.test(key);
      if(selected.length===1){paragraphs.length=0;if(reported&&!perPerson)facts.length=0;}
      if(reported&&!perPerson){
        facts.push({label:'电商项目累计净利润',value:reported});
        if(!sources.includes(netSource))sources.unshift(netSource);
      }else paragraphs.unshift('原文未提供足以核算净利润的成本与分成明细，学费和学员规模不能直接等同于净利润。');
    }
    const active = selected.filter(topic=>sources.some(r=>topic.path.test(r.url)||r.section===topic.section));
    if (!active.length) return null;
    const followups = [];
    const resolvedQuery = contextual && active.length === 1 ? `${active[0].title} ${original}` : original;
    return {
      query:original,
      resolvedQuery,
      title:overview ? '30 秒认识嘉程' : active.map(topic=>topic.title).join(' · '),
      paragraphs:paragraphs.slice(0,6),
      facts:facts.filter((fact,i,all)=>all.findIndex(other=>other.label===fact.label&&other.value===fact.value)===i).slice(0,6),
      sources:unique(sources).slice(0,8),
      followups,
      topic:overview ? 'overview' : active[0].id
    };
  }
  function search(query, sourceRecords, options = {}) {
    if(typeof query!=='string' || !Array.isArray(sourceRecords))return [];
    const original=query.trim().slice(0,140);
    if(!original || /[<>]|javascript:|\bonerror\s*=/i.test(original))return [];
    const key=normalize(original);
    if(excludedTest.test(key) || creationTest.test(key))return [];
    if(/(?:学校|大学|本科|专科|院校).*(?:学费|费用|收费)|(?:学费|费用|收费).*(?:学校|大学|本科|专科|院校)/.test(key))return [];
    const records=unique(sourceRecords.filter(safeRecord));
    const {selected,rejected}=matchTopics(key);
    const specific=selected.filter(topic=>topic.id!=='projects');
    const matched=specific.length?specific:selected;
    const number=Number(options?.limit);
    const limit=Number.isFinite(number)?Math.max(1,Math.min(8,Math.floor(number))):4;
    if(matched.length) {
      // Round-robin prevents one subject from hiding the other half of a
      // compound request (for example “学历和联系方式”).
      const buckets=matched.map(topic=>select(topic,records,original));
      const found=[];
      for(let i=0;found.length<limit && buckets.some(bucket=>bucket[i]);i++) {
        for(const bucket of buckets) {
          const record=bucket[i];
          if(record && !found.some(other=>other.text===record.text && other.url===record.url))found.push(record);
          if(found.length===limit)break;
        }
      }
      return found;
    }
    if(rejected.length)return [];
    // Unrecognised titles and exact product names remain searchable. Require
    // meaningful whole terms; isolated coincidental Chinese bigrams do not count.
    const terms=questionWords(key).filter(term=>term.length>=2 && !/^(?:什么|怎么|如何|多少|在哪里|有没有|可以|帮我|谢谢)$/.test(term));
    return records.map((record,index)=>{
      const title=normalize(record.title),body=normalize(record.text),keywords=normalize(record.keywords);
      let score=0;
      for(const term of terms){
        if(wordMatch(title,term))score+=30+term.length;
        if(wordMatch(body,term))score+=10+term.length;
        if(wordMatch(keywords,term))score+=5;
      }
      return {record,index,score};
    }).filter(item=>item.score>=10).sort((a,b)=>b.score-a.score || a.index-b.index).slice(0,limit).map(item=>item.record);
  }
  window.XiaoChengBrain = Object.freeze({answer,search});
})();

/* One local search surface. No model, account or download is required. */
(() => {
  'use strict';
  const root = document.querySelector('[data-sprite]');
  if (!root) return;
  const records = [{"title": "从获客到交付， 我都亲自做过。", "text": "2027 届本科", "url": "index.html", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "我做过的业务", "text": "50 万+ 多项目累计净利润（元）\n\n2022.06—2024.12 · 独立操盘", "url": "index.html#career-lens", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "我做过的业务 · 电商教学与用户增长", "text": "设计“先赚钱、后交学费＋经营分红”的服务模式，开发推广伙伴，负责教学、经营辅导与售后。\n\n2023.09—2024.12 · 校园创业", "url": "index.html#career-lens", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "我做过的业务 · 宿舍打印店创业", "text": "针对校内打印排队久、价格高、离宿舍远的需求，在宿舍提供低价打印与送货上门，验证盈利后交接经营。\n\n2026.02—2026.09 · 独立运营", "url": "index.html#career-lens", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "我做过的业务 · 直播内容与用户运营", "text": "独立完成主题、封面、场景与开播筹备，通过社群和私信维护用户，持续调整内容与互动。\n\n2025.08—2025.11 · 合伙经营", "url": "index.html#career-lens", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "我做过的业务 · 加盟门店筹备与经营", "text": "参与韩式炸鸡加盟门店的选址、设备与食材采购、开业统筹，营业后承担定价、出餐和日常经营。", "url": "index.html#career-lens", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "精选作品", "text": "独立策划 · AI 辅助实现", "url": "index.html#selected-work", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "让植物成长， 成为守住花园的策略。", "text": "我把玩法拆成植物、敌人、关卡与成长规则，推进实现，再逐项验收引导、操作和存档。\n\n独立创作 · AI 素材与后期剪辑", "url": "index.html#preview-panel-product", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "选择、风险、陪伴。", "text": "三个主题，三支已发布的叙事短片。我负责选题、脚本、分镜与剪辑，保留完整原作供观看。\n\n与朋友共同开展 · 策划与现场执行", "url": "index.html#preview-panel-film", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "面包挑战", "text": "共同设计收费、奖励和参与规则，准备 A3 宣传物料，再根据实际人流调整场地与组织方式。", "url": "index.html#preview-panel-field", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "面包挑战 · 现场参与规则", "text": "收费、挑战要求与奖励，向参与者清楚说明。", "url": "index.html#preview-panel-field", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "24 秒作品速览", "text": "我把想法，做成作品。 做。把想法做成作品 萌芽保卫队 · 实际游戏录屏 真实活动海报 · 从规则到现场 累计服务约 1,000 名学员 3 支 AI 叙事短片 · 独立完成全流程 直播内容与互动 · 2026 家乡荣耀季 马嘉程 · 产品与运营 马嘉程 · 继续看我的作品", "url": "index.html#introduction", "section": "认识嘉程", "keywords": "马嘉程 嘉程 自我介绍 个人介绍 认识嘉程 关于我 about introduction"}, {"title": "实践经历", "text": "做过的业务、承担的职责与实际结果。", "url": "experience/index.html", "section": "实践经历", "keywords": "实践 经历 experience"}, {"title": "求职方向", "text": "2027 届本科校招，意向一线及新一线城市。求职方向包括产品、用户与内容运营、电商、新媒体、活动策划、市场、销售商务与管培生。", "url": "experience/index.html#roles", "section": "求职方向", "keywords": "求职 应聘 招聘 职业方向 工作方向 岗位匹配 适合什么工作 能做什么岗位 找工作 招人 候选人 career job hiring"}, {"title": "电商知识付费与用户增长", "text": "2022.06—2024.12项目创始人 · 独立操盘\n\n40 万元以上 · 该项目累计净利润 · 近 1,000 人 · 累计去重学员 · 40–50 人 · 推广合作伙伴 · 288 元/人 · 教学服务学费", "url": "experience/index.html#ecommerce", "section": "电商教学", "keywords": "电商 教学 课程运营 教育运营 学费 收费 盈利 利润 收入 成本 经营分红 288 学员 获客 转化 增长 私域 社群 渠道 分销 推广伙伴 咨询 售后 答疑 客户成功 销售支持 选品 定价 sku commerce growth customer success"}, {"title": "电商知识付费与用户增长 · 实际结果", "text": "沉淀 1,000 余位微信好友，其中熟人不足 100 人。", "url": "experience/index.html#ecommerce", "section": "电商教学", "keywords": "电商 教学 课程运营 教育运营 学费 收费 盈利 利润 收入 成本 经营分红 288 学员 获客 转化 增长 私域 社群 渠道 分销 推广伙伴 咨询 售后 答疑 客户成功 销售支持 选品 定价 sku commerce growth customer success"}, {"title": "电商知识付费与用户增长 · 我做了什么", "text": "设计服务模式采用“先赚钱、后交学费＋经营分红”模式，降低学员开始尝试的门槛。\n\n发展推广伙伴将早期学员与朋友发展为推广伙伴，采用单层引荐分成，伙伴获 6 成；学员主要由伙伴带来，我负责伙伴开发。\n\n完成教学与经营辅导沉淀教学视频、操作手册与 FAQ，持续提供教学、店铺经营辅导与售后答疑。\n\n优化学员店铺指导调整活动策略、SKU 与投流。一个新店案例中，仅设置 1 个 SKU、未付费投流，截至当晚获得百余笔已付款订单。\n\n面向有创收需求的在校学生，从带教几位高中同学起步，将电商经验转化为教学与经营辅导服务。", "url": "experience/index.html#ecommerce", "section": "电商教学", "keywords": "电商 教学 课程运营 教育运营 学费 收费 盈利 利润 收入 成本 经营分红 288 学员 获客 转化 增长 私域 社群 渠道 分销 推广伙伴 咨询 售后 答疑 客户成功 销售支持 选品 定价 sku commerce growth customer success"}, {"title": "宿舍打印店创业：从校园需求到服务交付", "text": "2023.09—2024.12创始人 · 校园服务与项目引流\n\n0.2 元 · 黑白打印价格 · 0.4 元 · 彩印价格 · 1 份起送 · 送货上门", "url": "experience/index.html#printing", "section": "校园打印创业", "keywords": "打印 宿舍打印 校园创业 寝室打印店 黑白 彩印 低价 一份起送 送货上门 校园服务 引流 学生资源 交接 printing campus print shop"}, {"title": "宿舍打印店创业：从校园需求到服务交付 · 实际结果", "text": "单日最高收益数百元。", "url": "experience/index.html#printing", "section": "校园打印创业", "keywords": "打印 宿舍打印 校园创业 寝室打印店 黑白 彩印 低价 一份起送 送货上门 校园服务 引流 学生资源 交接 printing campus print shop"}, {"title": "宿舍打印店创业：从校园需求到服务交付 · 我做了什么", "text": "设计价格与配送以校内打印店黑白 0.5 元、彩印 1 元的 4 折定价，并提供送货上门。\n\n验证并交接经营经营半年多验证可盈利后，交由同学接手并获得分红，毕业前出售设备收尾。\n\n衔接其他业务通过打印服务沉淀学生资源，向电商知识付费等多个项目导流。\n\n校内仅有 1 家打印店，存在排队久、价格高、离宿舍远的问题。我在宿舍开店，为周边同学提供打印服务。", "url": "experience/index.html#printing", "section": "校园打印创业", "keywords": "打印 宿舍打印 校园创业 寝室打印店 黑白 彩印 低价 一份起送 送货上门 校园服务 引流 学生资源 交接 printing campus print shop"}, {"title": "抖音直播内容策划与用户维护", "text": "2026.02—2026.09独立主播 · 内容与用户运营\n\n1 万+ · 抖音粉丝 · 30 万+ · 单场最高曝光 · 日均约 3 小时 · 直播时长", "url": "experience/index.html#livestream", "section": "直播运营", "keywords": "直播 抖音 主播 内容运营 新媒体 用户维护 曝光量 直播间 社群 私信 粉丝 互动 传播 封面 直播策划 livestream content"}, {"title": "抖音直播内容策划与用户维护 · 实际结果", "text": "约 1 小时的直播达成单场最高曝光，获 2026 年“家乡荣耀季”区县 100 强。", "url": "experience/index.html#livestream", "section": "直播运营", "keywords": "直播 抖音 主播 内容运营 新媒体 用户维护 曝光量 直播间 社群 私信 粉丝 互动 传播 封面 直播策划 livestream content"}, {"title": "抖音直播内容策划与用户维护 · 我做了什么", "text": "准备开播独立策划主题、制作封面，筹备软硬件、场地与户外专场。\n\n调整内容与场景学习才艺，根据反馈调整直播风格、设备与呈现形式。\n\n维护用户关系通过社群、私信和个性化关怀延续直播中的互动。\n\n在直播之外，通过持续沟通延续与用户的联系。", "url": "experience/index.html#livestream", "section": "直播运营", "keywords": "直播 抖音 主播 内容运营 新媒体 用户维护 曝光量 直播间 社群 私信 粉丝 互动 传播 封面 直播策划 livestream content"}, {"title": "韩式炸鸡加盟门店筹备与经营", "text": "2025.08—2025.11合伙人 · 开业统筹与线下运营\n\n50% · 合伙持股比例", "url": "experience/index.html#store", "section": "门店经营", "keywords": "门店 餐饮 炸鸡 加盟 实体店 餐厅 零售 开业 选址 采购 供应商 食材 设备 商务支持 资源协调 store retail procurement"}, {"title": "韩式炸鸡加盟门店筹备与经营 · 实际结果", "text": "与朋友共同完成门店开业。", "url": "experience/index.html#store", "section": "门店经营", "keywords": "门店 餐饮 炸鸡 加盟 实体店 餐厅 零售 开业 选址 采购 供应商 食材 设备 商务支持 资源协调 store retail procurement"}, {"title": "韩式炸鸡加盟门店筹备与经营 · 我做了什么", "text": "推进开业准备参与加盟比选、门店选址和租赁签约，协调装修与开业安排。\n\n采购设备与食材比较批发和网购渠道，采购冰箱、空调等设备，通过美菜采购食品。\n\n参与日常经营参与定价、订单出餐与卫生维护，复盘实际经营问题。\n\n与朋友合伙开展韩式炸鸡加盟门店项目，从筹备推进到实际营业。", "url": "experience/index.html#store", "section": "门店经营", "keywords": "门店 餐饮 炸鸡 加盟 实体店 餐厅 零售 开业 选址 采购 供应商 食材 设备 商务支持 资源协调 store retail procurement"}, {"title": "面包挑战：活动规则与现场组织", "text": "2025.07—2025.08 / 2026.10 起与朋友共同开展 · 策划与执行\n\nA3 物料 · 现场宣传与规则说明 · 2–3 小时 · 通常的当场安排 · 19.9 元/次 · 参与价格", "url": "experience/index.html#field", "section": "活动实践", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "面包挑战：活动规则与现场组织 · 实际结果", "text": "现场吸引了参与者和围观人群，网站保留实际活动海报。", "url": "experience/index.html#field", "section": "活动实践", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "面包挑战：活动规则与现场组织 · 我做了什么", "text": "设计规则与宣传物料参与收费、奖励和挑战要求设计，面包成本 1.2 元/片，每日限量备货 20 片；准备宣传物料并在现场解释活动方式。\n\n组织现场选择人流较大的场地，统筹物料与现场安排。\n\n按人流调整调整经营位置与组织方式，包括流动经营。\n\n与朋友在南昌开展低投入的互动挑战活动，向现场人群说明收费、规则与奖励。", "url": "experience/index.html#field", "section": "活动实践", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "AI 叙事影像：从选题到成片", "text": "2026.09 起独立策划 · AI 素材制作 · 后期剪辑\n\n3 支 · 已发布叙事作品", "url": "experience/index.html#ai-work", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "AI 叙事影像：从选题到成片 · 实际结果", "text": "主题涵盖升学就业、风险代价和家庭陪伴。故事为虚构创作，非个人经历。", "url": "experience/index.html#ai-work", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "AI 叙事影像：从选题到成片 · 我做了什么", "text": "拆分镜头任务使用 ChatGPT 梳理选题与脚本，拆分分镜和素材生成提示词。\n\n制作与剪辑使用 Seedream、Seedance 生成素材，在剪映完成配音、字幕和剪辑，调整叙事节奏。\n\n发布与归档整理作品集并保留原作入口。\n\n以完整成片练习视听叙事。", "url": "experience/index.html#ai-work", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "网页游戏策划与产品交付", "text": "2026.10 发布游戏并持续迭代独立策划与验收 · AI 辅助实现\n\n4 个世界 · 公开游戏内容 · 20 个关卡 · 完整关卡推进", "url": "experience/index.html#digital-work", "section": "数字产品交付", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "网页游戏策划与产品交付 · 实际结果", "text": "个人网站与《萌芽保卫队》均已公开发布，可直接访问和操作。", "url": "experience/index.html#digital-work", "section": "数字产品交付", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "网页游戏策划与产品交付 · 我做了什么", "text": "定义玩法与范围设计“萌芽—成株—开花”机制，规划植物、敌人和关卡。\n\n推进实现拆解需求、设计提示词并提出反馈，完善引导、资源、暂停与存档。\n\n交付与验收公开发布网站和游戏，持续检查页面、操作与发布资源。\n\n把植物成长与资源分配转化为塔防玩法。", "url": "experience/index.html#digital-work", "section": "数字产品交付", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "工具与工作方法 · 业务与用户", "text": "咨询承接、用户沟通、服务交付、渠道合作、经营问题梳理。", "url": "experience/index.html#skills", "section": "工具与工作方法", "keywords": "技能 能力 工作方法 擅长什么 会什么软件 办公软件 数据整理 数据透视表 查找匹配 提示词 ai工具 skills tools excel word powerpoint ppt canva"}, {"title": "工具与工作方法 · 产品与 AI 应用", "text": "LLM 应用（ChatGPT、Claude）、提示词设计、Codex 与 Claude Code 辅助开发；通过需求拆解和迭代反馈推进产品交付。", "url": "experience/index.html#skills", "section": "工具与工作方法", "keywords": "技能 能力 工作方法 擅长什么 会什么软件 办公软件 数据整理 数据透视表 查找匹配 提示词 ai工具 skills tools excel word powerpoint ppt canva"}, {"title": "工具与工作方法 · 内容与视觉", "text": "Seedream、Seedance、剪映、Canva；覆盖脚本、分镜、素材、配音字幕与视觉材料。", "url": "experience/index.html#skills", "section": "工具与工作方法", "keywords": "技能 能力 工作方法 擅长什么 会什么软件 办公软件 数据整理 数据透视表 查找匹配 提示词 ai工具 skills tools excel word powerpoint ppt canva"}, {"title": "工具与工作方法 · 办公与数据", "text": "Word 文档编排、PowerPoint 演示材料；Excel 常用公式、查找匹配和数据透视表，用于信息整理和分类汇总。", "url": "experience/index.html#skills", "section": "工具与工作方法", "keywords": "技能 能力 工作方法 擅长什么 会什么软件 办公软件 数据整理 数据透视表 查找匹配 提示词 ai工具 skills tools excel word powerpoint ppt canva"}, {"title": "教育与校园服务 · 南昌理工学院", "text": "智能制造工程 · 全日制本科在读（专升本） 2025.09—2027.07（预计）", "url": "experience/index.html#education", "section": "教育经历", "keywords": "学历 学厉 教育背景 学校 院校 毕业院校 毕业学校 大学 本科 专科 专业 毕业时间 什么时候毕业 哪里读书 在哪上学 读什么专业 第几届 应届生 education degree university college"}, {"title": "教育与校园服务 · 华东交通大学", "text": "铁道信号自动控制 · 专科 2022.09—2025.07", "url": "experience/index.html#education", "section": "教育经历", "keywords": "学历 学厉 教育背景 学校 院校 毕业院校 毕业学校 大学 本科 专科 专业 毕业时间 什么时候毕业 哪里读书 在哪上学 读什么专业 第几届 应届生 education degree university college"}, {"title": "教育与校园服务 · 校园服务", "text": "两校就读期间均担任学习委员，负责班级沟通与学习事务。", "url": "experience/index.html#education", "section": "教育经历", "keywords": "学历 学厉 教育背景 学校 院校 毕业院校 毕业学校 大学 本科 专科 专业 毕业时间 什么时候毕业 哪里读书 在哪上学 读什么专业 第几届 应届生 education degree university college"}, {"title": "教育与校园服务 · 语言证书", "text": "普通话二级甲等。", "url": "experience/index.html#education", "section": "教育经历", "keywords": "学历 学厉 教育背景 学校 院校 毕业院校 毕业学校 大学 本科 专科 专业 毕业时间 什么时候毕业 哪里读书 在哪上学 读什么专业 第几届 应届生 education degree university college"}, {"title": "作品", "text": "网页产品、叙事影像与现场活动。", "url": "projects/index.html", "section": "作品与项目", "keywords": "作品 项目 作品集 做过什么 项目经历 portfolio projects"}, {"title": "萌芽保卫队", "text": "交互产品 · 独立策划 · AI 辅助实现\n\n把植物成长与资源分配做成可玩的网页产品。我负责玩法设计、需求拆解与迭代验收。\n\n影像创作 · 独立完成", "url": "projects/index.html#selected-work", "section": "作品与项目", "keywords": "作品 项目 作品集 做过什么 项目经历 portfolio projects"}, {"title": "AI 叙事影像", "text": "升学就业、风险与陪伴。三支短片，覆盖选题、脚本、分镜、素材与剪辑。\n\n线下活动 · 与朋友共同开展", "url": "projects/index.html#content-work", "section": "作品与项目", "keywords": "作品 项目 作品集 做过什么 项目经历 portfolio projects"}, {"title": "面包挑战", "text": "查看活动方案和现场实际使用的 A3 宣传物料。", "url": "projects/index.html#field-work", "section": "作品与项目", "keywords": "作品 项目 作品集 做过什么 项目经历 portfolio projects"}, {"title": "萌芽保卫队", "text": "种下、守护、成长。", "url": "projects/sprout-patrol/index.html", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "我的分工", "text": "独立负责玩法策划、需求拆解、交互与迭代验收，通过 Codex 辅助实现代码。", "url": "projects/sprout-patrol/index.html#overview", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "成长机制", "text": "用阳光补充防线，或等待现有植物成长。", "url": "projects/sprout-patrol/index.html#mechanism", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "成长机制 · 争取时间", "text": "保护萌芽，等待它长成。", "url": "projects/sprout-patrol/index.html#growth-panel-0", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "成长机制 · 形成防线", "text": "成株获得作战能力。", "url": "projects/sprout-patrol/index.html#growth-panel-1", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "成长机制 · 强化能力", "text": "投入阳光，让植物开花。", "url": "projects/sprout-patrol/index.html#growth-panel-2", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "花园旅程", "text": "完成当前关卡后解锁下一关，可在旅程中查看进度。", "url": "projects/sprout-patrol/index.html#journey", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "随时继续 · 引导与图鉴", "text": "首关引导帮助理解操作，图鉴用于查阅植物和敌人信息；将学习规则与进入玩法的过程衔接起来。", "url": "projects/sprout-patrol/index.html#decisions", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "随时继续 · 存档与继续", "text": "本机自动保存进度，也可导出存档码，让玩家能够中断后继续已有旅程。", "url": "projects/sprout-patrol/index.html#decisions", "section": "萌芽保卫队", "keywords": "游戏 萌芽 保卫队 塔防 数字产品 网站 产品助理 产品运营 项目助理 项目执行 需求拆解 交付 验收 人工智能 辅助开发 codex game product project"}, {"title": "AI 影像", "text": "独立完成的三支叙事短片。", "url": "projects/ai-content/index.html", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "升学与就业选择", "text": "围绕升学与就业方向，呈现人物的犹豫与决定。", "url": "projects/ai-content/index.html#film-choice", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "从赢两千到欠八十万", "text": "通过转折与节奏，呈现风险逐步累积的代价。", "url": "projects/ai-content/index.html#film-risk", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "陪家人抗癌", "text": "以人物关系、画面与声音表达家庭陪伴。", "url": "projects/ai-content/index.html#film-care", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "创作流程 · 脚本与分镜", "text": "使用 ChatGPT 梳理脚本，将故事拆成分镜、镜头要求与素材提示词。", "url": "projects/ai-content/index.html#process", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "创作流程 · 素材与剪辑", "text": "使用 Seedream、Seedance 生成素材，在剪映完成配音、字幕与剪辑，调整叙事节奏。", "url": "projects/ai-content/index.html#process", "section": "AI 影像", "keywords": "ai影像 ai视频 短视频 叙事 影片 剪辑 脚本 分镜 提示词 素材 配音 字幕 成片 内容策划 seedance seedream 剪映 video storytelling"}, {"title": "面包挑战", "text": "2025.07—2025.08、2026.10 起，与朋友共同开展。", "url": "poster/index.html", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "现场参与方式", "text": "收费、挑战要求与分档奖励均在现场宣传海报中说明。", "url": "poster/index.html#visual", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "策划与执行 · 场景与目标", "text": "基于南昌当地市场观察，与朋友将互动挑战整理为可以在现场开展的低投入活动。", "url": "poster/index.html#thinking", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "策划与执行 · 规则与物料", "text": "参与规则设计，准备 A3 海报，让参与者能在现场了解挑战要求。", "url": "poster/index.html#thinking", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "策划与执行 · 组织与调整", "text": "统筹物料与现场安排，向参与者说明规则，根据人流调整场地与经营方式。", "url": "poster/index.html#thinking", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "策划与执行 · 实际交付", "text": "完成策划与现场执行，吸引参与及围观，通常在 2–3 小时完成当场挑战安排。", "url": "poster/index.html#thinking", "section": "面包挑战", "keywords": "活动 面包 挑战 策划 执行 地推 线下推广 现场组织 规则设计 宣传物料 海报 统筹 event campaign"}, {"title": "青山湖区区县 100 强", "text": "2026 年抖音家乡荣耀季", "url": "honor/index.html#livestream-honor", "section": "荣誉与证书", "keywords": "荣誉 证书 获奖 奖项 奖励 凭证 学生干部 家乡荣耀季 区县100强 award certificate"}, {"title": "校优秀学生干部", "text": "2023 年 · 华东交通大学", "url": "honor/index.html#campus-honor", "section": "荣誉与证书", "keywords": "荣誉 证书 获奖 奖项 奖励 凭证 学生干部 家乡荣耀季 区县100强 award certificate"}, {"title": "2026 年秋 · 面包挑战", "text": "2026 年 10 月起与朋友继续开展线下活动。查看活动方案与物料", "url": "updates/index.html#recent-work", "section": "最近更新", "keywords": "更新 最近动态 新版 发布 迭代 上线 updates release"}, {"title": "马嘉程", "text": "2027 届本科 · 南昌理工学院\n\n运营与增长 · 产品与项目 · 内容与市场\n\n邮箱：19870043434@163.com\n\n手机：19870043434", "url": "contact/index.html", "section": "联系与合作", "keywords": "联系 联系方式 怎么联系 联络 邮箱 邮件 电话 手机号码 微信 合作 简历 履历 下载简历 contact email resume cv"}];
  const siteURL = new URL('../', document.currentScript.src);
  const launcher=root.querySelector('.sprite-launcher'), panel=root.querySelector('.sprite-panel');
  const input=root.querySelector('input'), results=root.querySelector('.sprite-results');
  const scroller=root.querySelector('.sprite-scroll'), status=root.querySelector('[data-sprite-status]');
  const clear=root.querySelector('[data-sprite-clear-input]'), submit=root.querySelector('button[type="submit"]');
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let opened=false,timer,closing,previousFocus,composing=false,committedContext=null;
  const normalize=value=>String(value || '').normalize('NFKC').toLowerCase().replace(/[\s\p{P}\p{S}]/gu,'');
  function markText(element, text, query) {
    const terms = [...new Set(query.trim().split(/\s+/).filter(Boolean))].sort((a,b)=>b.length-a.length);
    if (!terms.length) { element.textContent = text; return; }
    const escaped = terms.map(term => term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const expression = new RegExp('(' + escaped.join('|') + ')', 'gi');
    for (const part of text.split(expression)) {
      const match = terms.some(term => part.toLocaleLowerCase() === term.toLocaleLowerCase());
      const node = match ? document.createElement('mark') : document.createTextNode(part);
      if (match) node.textContent = part;
      element.append(node);
    }
  }
  function snippet(text, query) {
    const key = query.trim().split(/\s+/).find(term => text.toLowerCase().includes(term.toLowerCase()));
    const match = key ? text.toLowerCase().indexOf(key.toLowerCase()) : 0;
    const start = Math.max(0, match - 32);
    const end = Math.min(text.length, start + 180);
    return (start ? '…' : '') + text.slice(start, end) + (end < text.length ? '…' : '');
  }

  function safeSourceURL(value) {
    try {const url=new URL(value,siteURL);return url.origin===siteURL.origin && ['http:','https:'].includes(url.protocol) ? url.href : null;}
    catch {return null;}
  }
  function focusContent() {
    const target=results.querySelector('h3,h4,.sprite-empty strong');
    if(target){target.tabIndex=-1;target.focus({preventScroll:true});}
  }
  function appendSources(card,sources) {
    const destinations=new Set([...card.querySelectorAll('a[href]')].map(link=>link.href));
    const evidence=sources.filter(record=>{
      const destination=safeSourceURL(record.url);
      if(!destination || destinations.has(destination))return false;
      destinations.add(destination);return true;
    }).slice(0,3);
    if(!evidence.length)return;
    const box=document.createElement('nav');box.className='sprite-sources';box.setAttribute('aria-label','相关内容');
    for(const record of evidence){
      const link=document.createElement('a');link.className='sprite-answer-source';
      link.href=safeSourceURL(record.url);link.textContent=record.title || '查看相关经历';box.append(link);
    }
    card.append(box);
  }
  function drawAnswer(answer,query) {
    const card=document.createElement('article');card.className='sprite-answer';card.dataset.spriteTopic=answer.topic || '';
    const title=document.createElement('h3');title.className='sprite-answer-title';title.textContent=answer.title || '搜索结果';card.append(title);
    const facts=(answer.facts || []).slice(0,4);
    const paragraphs=(answer.paragraphs || []).filter(text=>!facts.some(fact=>normalize(text).includes(normalize(fact.value)))).slice(0,Math.min(4,(answer.title || '').split(' · ').length));
    for(const paragraph of paragraphs){
      const p=document.createElement('p');p.className='sprite-answer-paragraph';
      const clean=paragraph.trim();
      const boundary=Math.max(clean.slice(0,180).lastIndexOf('。'),clean.slice(0,180).lastIndexOf('；'));
      p.textContent=clean.length<=180?clean:clean.slice(0,boundary>50?boundary+1:180).trim()+'…';card.append(p);
    }
    if(facts.length){
      const list=document.createElement('dl');list.className='sprite-facts';
      for(const fact of facts){const row=document.createElement('div'),label=document.createElement('dt'),value=document.createElement('dd');label.textContent=fact.label;value.textContent=fact.value;row.append(label,value);list.append(row);}
      card.append(list);
    }
    if(/简历|履历|resume|\bcv\b/i.test(query)){
      const link=document.createElement('a');link.className='sprite-resume';link.dataset.spriteAction='resume';link.textContent='下载简历';
      const existing=[...document.querySelectorAll('a[href]')].map(a=>safeSourceURL(a.href)).find(url=>url && /\/resume(?:-[a-f0-9]{12})?\.pdf$/.test(new URL(url).pathname));
      link.href=existing || new URL('resume-beb4a3432690.pdf',siteURL).href;link.download='马嘉程_个人简历.pdf';card.append(link);
    }
    appendSources(card,answer.sources || []);return card;
  }
  function render(query,{commit=false}={}) {
    clearTimeout(timer);
    const value=query.trim().slice(0,140);
    clear.hidden=!input.value;submit.disabled=!value;
    results.replaceChildren();results.setAttribute('aria-busy','false');
    root.dataset.spriteState=value?'results':'welcome';
    if(!value){status.textContent='';committedContext=null;return;}
    if(!window.XiaoChengBrain?.search){
      root.dataset.spriteState='empty';status.textContent='搜索暂不可用';
      const message=document.createElement('p');message.className='sprite-unavailable';message.textContent='搜索暂不可用，请刷新后重试。';results.append(message);return;
    }
    let answer=null;
    try{answer=window.XiaoChengBrain?.answer(value,records,committedContext || {}) || null;}catch{}
    const found=window.XiaoChengBrain?.search?.(answer?.resolvedQuery || value,records,{limit:4}) || [];
    if(answer){
      results.append(drawAnswer(answer,value));
      status.textContent='已找到'+answer.title;
      if(commit)committedContext={topic:answer.topic,query:answer.resolvedQuery || value};
    }else if(found.length){
      status.textContent='找到'+found.length+'条相关内容';
      for(const [i,record] of found.entries()){
        const card=document.createElement('article'),title=document.createElement('h4'),link=document.createElement('a'),text=document.createElement('p');
        card.className='sprite-result';card.style.animationDelay=`${i*25}ms`;
        link.href=safeSourceURL(record.url);markText(link,record.title,value);title.append(link);
        markText(text,snippet(record.text,value),value);card.append(title,text);results.append(card);
      }
    }else{
      root.dataset.spriteState='empty';status.textContent='暂无结果';
      const card=document.createElement('div'),title=document.createElement('strong'),text=document.createElement('p');
      card.className='sprite-empty';title.textContent='暂无结果';text.textContent='换个关键词，或描述想找的内容。';card.append(title,text);results.append(card);
    }
    scroller.scrollTop=0;
  }
  function syncTone(){
    if(!opened)return;
    const hero=document.querySelector('.home-page .era-hero'),box=panel.getBoundingClientRect();
    const scene=hero?.getBoundingClientRect(),center=box.top+Math.min(box.height/2,180);
    root.dataset.spriteTone=scene&&scene.top<=center&&scene.bottom>=center?'dark':'light';
  }
  function open() {
    if(document.querySelector('dialog[open]'))return;
    if (opened) { input.focus({preventScroll:true}); return; }
    opened = true; clearTimeout(closing); previousFocus = document.activeElement;
    panel.hidden = false; panel.inert = false;
    launcher.setAttribute('aria-expanded','true');
    requestAnimationFrame(() => {if (opened) root.setAttribute('data-open','');});
    // Focus in the original gesture so the iOS keyboard can open naturally.
    input.focus({preventScroll:true}); fitKeyboard();syncTone();
  }
  function close(restoreFocus=true) {
    if (!opened) return;
    opened = false; root.removeAttribute('data-open'); panel.inert = true;
    launcher.setAttribute('aria-expanded','false'); input.blur();
    if(restoreFocus)(previousFocus && previousFocus.isConnected && previousFocus!==document.body && previousFocus!==document.documentElement ? previousFocus : launcher).focus({preventScroll:true});
    closing = setTimeout(() => { if (!opened) panel.hidden = true; }, reduced.matches ? 0 : 240);
    ['max-height','height','bottom','top','min-height'].forEach(property=>panel.style.removeProperty(property));root.removeAttribute('data-keyboard');
  }

  for(const trigger of document.querySelectorAll('[data-open-companion]')){
    trigger.hidden=false;trigger.setAttribute('aria-controls',panel.id);trigger.setAttribute('aria-haspopup','dialog');
    trigger.addEventListener('click',()=>{open();const query=trigger.dataset.openCompanion?.trim();if(query){input.value=query;render(query,{commit:true});input.blur();focusContent();}});
  }
  root.querySelector('.sprite-close').addEventListener('click',close);
  document.addEventListener('pointerdown',event=>{if(opened && !panel.contains(event.target) && !launcher.contains(event.target))close();});
  // This is a nonmodal search: Tab can return to the page, and the surface
  // dismisses without pulling focus away from the visitor's next control.
  document.addEventListener('focusin',event=>{if(opened && !panel.contains(event.target))close(false);});
  results.addEventListener('click',event=>{
    const link=event.target.closest('a[href]');
    if(!link || event.defaultPrevented || event.button!==0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)return;
    const destination=new URL(link.href);
    if(destination.origin!==siteURL.origin || link.hasAttribute('download'))return;
    close(false);
    // Native anchors own scrolling and history. Also focus a repeated same-page
    // destination, where hashchange may not fire a second time.
    if(destination.pathname===location.pathname && destination.hash){
      requestAnimationFrame(()=>{
        let section;try{section=document.getElementById(decodeURIComponent(destination.hash.slice(1)));}catch{return;}
        const target=section?.querySelector('h1,h2,h3') || section;
        if(!target)return;
        const old=target.getAttribute('tabindex');target.tabIndex=-1;target.focus({preventScroll:true});
        target.addEventListener('blur',()=>{if(old===null)target.removeAttribute('tabindex');else target.setAttribute('tabindex',old);},{once:true});
      });
    }
  });
  launcher.addEventListener('click',event=>{if(suppressClick){event.preventDefault();return;}opened?close():open();});
  root.querySelector('form').addEventListener('submit',event=>{
    event.preventDefault();clearTimeout(timer);if(composing || event.isComposing || !input.value.trim())return;
    render(input.value,{commit:true});input.blur();focusContent();
  });
  input.addEventListener('input',()=>{
    clear.hidden=!input.value;submit.disabled=!input.value.trim();
    if(composing)return;clearTimeout(timer);results.setAttribute('aria-busy','true');timer=setTimeout(()=>render(input.value),120);
  });
  input.addEventListener('compositionstart',()=>{composing=true;clearTimeout(timer);});
  input.addEventListener('compositionend',()=>{composing=false;render(input.value);});
  clear.addEventListener('click',()=>{clearTimeout(timer);input.value='';committedContext=null;render('');input.focus({preventScroll:true});});
  panel.addEventListener('keydown',event=>{
    if(event.altKey || event.metaKey || event.ctrlKey || event.isComposing || composing || !['ArrowDown','ArrowUp'].includes(event.key))return;
    const targets=[...results.querySelectorAll('summary,a')].filter(element=>{
      if(!element.getClientRects().length)return false;
      for(let owner=element.parentElement;owner && owner!==results;owner=owner.parentElement)if(owner.tagName==='DETAILS' && !owner.open && owner.querySelector('summary')!==element)return false;
      return true;
    });
    if(!targets.length)return;
    const index=targets.indexOf(document.activeElement),headingFocused=document.activeElement?.matches('h3,h4,.sprite-empty strong');
    if(document.activeElement!==input && index<0 && !headingFocused)return;
    if(document.activeElement===input && event.key==='ArrowUp')return;
    event.preventDefault();const next=index+(event.key==='ArrowDown'?1:-1);
    if(next<0)input.focus({preventScroll:true});else{const target=targets[Math.min(next,targets.length-1)];target.focus({preventScroll:true});target.scrollIntoView({block:'nearest'});}
  });
  document.addEventListener('keydown',event=>{
    if(event.isComposing || composing || event.defaultPrevented)return;
    if(event.key==='Escape' && opened){event.preventDefault();close();}
    if((event.metaKey || event.ctrlKey) && event.key.toLowerCase()==='k'){event.preventDefault();open();}
  });
  render('');
  launcher.hidden=false;
  const pauseCharacter=()=>root.toggleAttribute('data-sprite-paused',document.hidden);
  document.addEventListener('visibilitychange',pauseCharacter);pauseCharacter();
  // Keep the search field above the software keyboard without scrolling the page.
  function fitKeyboard() {
    if (!opened || !window.visualViewport) return;
    const viewport=window.visualViewport;
    const overlap=Math.max(0,window.innerHeight-viewport.height-viewport.offsetTop);
    const keyboard=overlap>100;
    root.toggleAttribute('data-keyboard',keyboard);
    if (keyboard || window.innerWidth<800) {
      const gutter=viewport.height<280?8:12;
      panel.style.top=`${Math.max(0,viewport.offsetTop)+gutter}px`;
      panel.style.bottom='auto';
      panel.style.maxHeight=`${Math.max(0,viewport.height-2*gutter)}px`;
    } else {['top','bottom','max-height'].forEach(property=>panel.style.removeProperty(property));}
  }
  window.visualViewport?.addEventListener('resize',fitKeyboard);
  window.visualViewport?.addEventListener('scroll',fitKeyboard);
  window.visualViewport?.addEventListener('resize',syncTone);
  addEventListener('scroll',syncTone,{passive:true});addEventListener('resize',syncTone,{passive:true});
  // The outer anchor stays still for tapping; only the inner pearl floats.
  let drag, suppressClick = false, draggedPosition = false;
  function boundaries() {
    const dock = document.querySelector('[data-glass-dock]')?.getBoundingClientRect();
    const floor = dock && dock.top > innerHeight / 2 ? dock.top - 12 : innerHeight - 12;
    return {minX:8,maxX:Math.max(8,innerWidth-launcher.offsetWidth-8),minY:8,maxY:Math.max(8,floor-launcher.offsetHeight)};
  }
  function position(x,y) {
    const b = boundaries();
    root.style.left = `${Math.min(b.maxX,Math.max(b.minX,x))}px`;
    root.style.top = `${Math.min(b.maxY,Math.max(b.minY,y))}px`;
    root.style.right = 'auto';root.style.bottom = 'auto';draggedPosition = true;
  }
  launcher.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    const box = launcher.getBoundingClientRect();
    drag = {id:event.pointerId,x:event.clientX,y:event.clientY,left:box.left,top:box.top,moved:false};
    suppressClick = false; launcher.setPointerCapture(event.pointerId);
  });
  launcher.addEventListener('pointermove', event => {
    if (!drag || event.pointerId !== drag.id) return;
    const dx = event.clientX-drag.x,dy = event.clientY-drag.y;
    if (!drag.moved && Math.hypot(dx,dy) < 7) return;
    drag.moved = true;suppressClick = true;root.setAttribute('data-dragging','');
    position(drag.left+dx,drag.top+dy);
  });
  function finishDrag(event) {
    if (!drag || event.pointerId !== drag.id) return;
    const moved = drag.moved;drag = null;root.removeAttribute('data-dragging');
    if (moved) {
      const box = launcher.getBoundingClientRect();
      position(box.left+box.width/2 < innerWidth/2 ? 10 : innerWidth-box.width-10,box.top);
      try {sessionStorage.setItem('mjc-sprite-position',JSON.stringify({side:box.left+box.width/2<innerWidth/2?'left':'right',ratio:box.top/Math.max(1,innerHeight)}));} catch {}
      setTimeout(()=>{suppressClick=false;},100);
    }
  }
  launcher.addEventListener('pointerup', finishDrag);
  launcher.addEventListener('pointercancel', finishDrag);
  launcher.addEventListener('lostpointercapture', event => {if(drag)finishDrag(event);});
  try {
    const saved = JSON.parse(sessionStorage.getItem('mjc-sprite-position'));
    if (saved && ['left','right'].includes(saved.side) && Number.isFinite(saved.ratio)) position(saved.side==='left'?10:innerWidth-launcher.offsetWidth-10,saved.ratio*innerHeight);
  } catch {}
  window.addEventListener('resize', () => {
    if(draggedPosition){const box=launcher.getBoundingClientRect();position(box.left,box.top);} fitKeyboard();
  });
  launcher.addEventListener('pointermove', event => {
    if (drag || reduced.matches) return;
    const box = launcher.getBoundingClientRect();
    launcher.style.setProperty('--sprite-eye-x',`${(event.clientX-box.left-box.width/2)/14}px`);
    launcher.style.setProperty('--sprite-eye-y',`${(event.clientY-box.top-box.height/2)/18}px`);
  });
  launcher.addEventListener('pointerleave',()=>{launcher.style.setProperty('--sprite-eye-x','0px');launcher.style.setProperty('--sprite-eye-y','0px');});
})();

/* Direct manipulation of a single glass selection. Drag previews stay local;
 * release invokes the existing button or anchor exactly once. */
(() => {
  'use strict';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const engines = [];
  const clamp = (value,min,max) => Math.max(min,Math.min(max,value));
  for (const group of document.querySelectorAll('.case-jump,.growth-steps,.studio-tabs')) {
    if (group.hasAttribute('data-control-glass')) continue;
    const controls = [...group.querySelectorAll(':scope > a[href],:scope > button')];
    if (!controls.length) continue;
    const lens = document.createElement('span');
    lens.className = 'control-lens';
    lens.setAttribute('aria-hidden','true');
    lens.hidden = true;
    group.prepend(lens);
    group.dataset.controlGlass = '';
    const current = {x:0,y:0,width:0,height:0}, target = {...current}, velocity = {...current};
    let selected = null, ready = false, visible = true, frame = 0, measuredFrame = 0, lastTime = 0;
    let glint = .16, glintTarget = .16, contact = null, gesture = null;
    let suppressClickUntil = 0;
    controls.forEach(control=>{control.draggable=false;});
    const activeControl = () => controls.find(control =>
      control.getAttribute('aria-pressed') === 'true' ||
      control.getAttribute('aria-selected') === 'true' ||
      (control.hasAttribute('aria-current') && control.getAttribute('aria-current') !== 'false'));
    function stop() { cancelAnimationFrame(frame); frame = 0; lastTime = 0; }
    function paint(stretch=1,squash=1) {
      for (const [property,value] of Object.entries(current)) lens.style.setProperty('--control-'+property,value.toFixed(3)+'px');
      lens.style.setProperty('--control-stretch',stretch.toFixed(4));
      lens.style.setProperty('--control-squash',squash.toFixed(4));
      lens.style.setProperty('--control-glint',glint.toFixed(3));
    }
    function settle() {
      stop();Object.assign(current,target);
      for (const key of Object.keys(velocity)) velocity[key] = 0;
      glint = glintTarget;paint();
      group.dataset.controlMotion = 'idle';
    }
    function animate(time) {
      frame = 0;
      if (document.hidden || !visible || reduced.matches || !selected) { settle(); return; }
      const dt = Math.min(.032,(time-(lastTime || time-16.67))/1000);lastTime=time;
      let remaining = 0, speed = 0;
      for (const key of Object.keys(current)) {
        if(gesture?.dragging){
          velocity[key]=(target[key]-current[key])/dt;current[key]=target[key];
          if(key==='x'||key==='y')speed+=velocity[key]*velocity[key];
          continue;
        }
        velocity[key] += ((target[key]-current[key])*330-velocity[key]*28)*dt;
        current[key] += velocity[key]*dt;
        remaining += Math.abs(target[key]-current[key])+Math.abs(velocity[key])*.025;
        if (key === 'x' || key === 'y') speed += velocity[key]*velocity[key];
      }
      glint += (glintTarget-glint)*(1-Math.exp(-dt*13));
      const stretch = Math.min(.13,Math.sqrt(speed)/Math.max(44,current.width)*.018);
      paint(1+stretch+(contact ? .02 : 0),1-stretch*.42+(contact ? .015 : 0));
      if (remaining < .055 && Math.abs(glint-glintTarget)<.003) { settle(); return; }
      frame = requestAnimationFrame(animate);
    }
    function wake() {
      if(gesture?.dragging&&reduced.matches){Object.assign(current,target);paint();return;}
      if (!ready || document.hidden || !visible || reduced.matches) { settle(); return; }
      group.dataset.controlMotion = 'moving';
      if (!frame) frame = requestAnimationFrame(animate);
    }
    function measure(animateSelection=true) {
      measuredFrame=0;
      if(gesture?.dragging)return;
      const next = activeControl();
      if (!next || !next.getClientRects().length) {
        selected=null;lens.hidden=true;ready=false;stop();
        delete group.dataset.controlReady;return;
      }
      const changed = next !== selected;
      selected = next;
      // Layout offsets ignore the selected control's transient press transform.
      // The positioned group is the lens's containing block, including wrapped rows.
      Object.assign(target,{x:next.offsetLeft-group.scrollLeft,y:next.offsetTop-group.scrollTop,width:next.offsetWidth,height:next.offsetHeight});
      lens.hidden=false;group.dataset.controlReady='';
      if (!ready || !animateSelection) { ready=true;settle();return; }
      if (changed) { glint=.92;glintTarget=contact ? .76 : .16; }
      wake();
    }
    const scheduleMeasure = () => {
      if (!measuredFrame) measuredFrame=requestAnimationFrame(()=>measure(false));
    };
    new MutationObserver(()=>measure()).observe(group,{subtree:true,attributes:true,attributeFilter:['aria-current','aria-pressed','aria-selected']});
    if ('ResizeObserver' in window) {
      const resize = new ResizeObserver(scheduleMeasure);
      resize.observe(group);controls.forEach(control=>resize.observe(control));
    }
    if ('IntersectionObserver' in window) new IntersectionObserver(entries=>{
      visible=entries[0].isIntersecting;
      if (!visible) { finishDrag();contact=null;glintTarget=.16;settle(); }
      else measure(false);
    },{rootMargin:'40px'}).observe(group);
    group.addEventListener('scroll',scheduleMeasure,{passive:true});
    const geometry=control=>({x:control.offsetLeft-group.scrollLeft,y:control.offsetTop-group.scrollTop,width:control.offsetWidth,height:control.offsetHeight});
    function preview(control){
      controls.forEach(item=>item.toggleAttribute('data-control-preview',item===control));
    }
    function finishDrag(event,commit=false){
      if(!gesture || event&&event.pointerId!==gesture.id)return;
      const ended=gesture;gesture=null;contact=null;glintTarget=.16;
      delete group.dataset.controlDragging;preview(null);
      if(ended.dragging){
        suppressClickUntil=performance.now()+600;
        const r=group.getBoundingClientRect();
        const inside=commit&&event.clientX>=r.left-14&&event.clientX<=r.right+14&&event.clientY>=r.top-14&&event.clientY<=r.bottom+14;
        if(inside&&ended.candidate){
          // Existing handlers update panels/ARIA, and anchors keep native history.
          ended.candidate.focus({preventScroll:true});ended.candidate.click();
        }
      }
      if(group.hasPointerCapture?.(ended.id))group.releasePointerCapture(ended.id);
      measure();
    }
    group.addEventListener('pointerdown',event=>{
      if(gesture||!event.isPrimary||event.button!==0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey)return;
      const control=controls.find(control=>control.contains(event.target));
      if(!control)return;
      suppressClickUntil=0;
      const rect=group.getBoundingClientRect(),start=geometry(control);
      gesture={id:event.pointerId,x:event.clientX,y:event.clientY,dragging:false,candidate:control,rect,
        grabX:event.clientX-rect.left-group.clientLeft-start.x,
        grabY:event.clientY-rect.top-group.clientTop-start.y,
        boxes:controls.map(item=>({control:item,...geometry(item)}))};
      contact={id:event.pointerId,x:event.clientX,y:event.clientY};glint=.95;glintTarget=.76;wake();
    },{passive:true});
    group.addEventListener('pointermove',event=>{
      if(!gesture||event.pointerId!==gesture.id)return;
      const dx=event.clientX-gesture.x,dy=event.clientY-gesture.y;
      if(!gesture.dragging){
        // Vertical intent belongs to native page scrolling. Once horizontal
        // intent wins, diagonal motion can reach a wrapped second row.
        if(Math.abs(dy)>9&&Math.abs(dy)>Math.abs(dx)){finishDrag(event);return;}
        if(Math.abs(dx)<7||Math.abs(dx)<Math.abs(dy)*1.15)return;
        gesture.dragging=true;group.dataset.controlDragging='true';
        group.setPointerCapture?.(event.pointerId);
        ready=true;lens.hidden=false;group.dataset.controlReady='';
      }
      if(event.cancelable)event.preventDefault();
      const x=event.clientX-gesture.rect.left-group.clientLeft,y=event.clientY-gesture.rect.top-group.clientTop;
      const closest=gesture.boxes.reduce((best,box)=>Math.hypot(x-box.x-box.width/2,y-box.y-box.height/2)<Math.hypot(x-best.x-best.width/2,y-best.y-best.height/2)?box:best);
      gesture.candidate=closest.control;preview(closest.control);
      const rawX=x-gesture.grabX,rawY=y-gesture.grabY;
      const maxX=group.clientWidth-closest.width,maxY=group.clientHeight-closest.height;
      const resist=(n,max)=>n<0?n*.14:n>max?max+(n-max)*.14:n;
      Object.assign(target,{x:resist(rawX,maxX),y:resist(rawY,maxY),width:closest.width,height:closest.height});
      // Direct touch never chases a spring; only release uses the spring.
      Object.assign(current,target);paint(reduced.matches?1:1.05,reduced.matches?1:1.025);wake();
    },{passive:false});
    group.addEventListener('click',event=>{
      if(event.isTrusted&&event.detail>0&&performance.now()<suppressClickUntil){
        suppressClickUntil=0;event.preventDefault();event.stopImmediatePropagation();
      }
    },true);
    group.addEventListener('dragstart',event=>event.preventDefault());
    group.addEventListener('lostpointercapture',event=>{
      if(gesture?.id===event.pointerId&&!group.hasPointerCapture?.(event.pointerId))finishDrag(event);
    });
    group.addEventListener('keydown',event=>{
      if (event.repeat || event.isComposing || event.defaultPrevented || event.metaKey || event.ctrlKey || event.altKey || !['Enter',' '].includes(event.key))return;
      const control=controls.find(control=>control.contains(event.target));
      if (!control || (event.key===' ' && control.matches('a')))return;
      contact={id:'keyboard'};glint=.95;glintTarget=.76;wake();
    });
    const release = () => { finishDrag();if(contact){contact=null;glintTarget=.16;wake();} };
    document.addEventListener('pointerup',event=>{if(gesture?.id===event.pointerId)finishDrag(event,true);},{passive:true});
    document.addEventListener('pointercancel',event=>{if(gesture?.id===event.pointerId)finishDrag(event);},{passive:true});
    document.addEventListener('keydown',event=>{
      if(event.key==='Escape'&&gesture){event.preventDefault();finishDrag();}
    });
    document.addEventListener('keyup',event=>{if(contact?.id==='keyboard' && ['Enter',' '].includes(event.key))release();});
    group.addEventListener('focusout',()=>{if(contact?.id==='keyboard')release();});
    const releasePointer = () => { if(contact?.id!=='keyboard')release(); };
    engines.push({measure,scheduleMeasure,release,releasePointer,settle});
    measure(false);
  }
  const sync = () => engines.forEach(engine=>{engine.release();engine.measure(false);});
  addEventListener('resize',()=>engines.forEach(engine=>{engine.release();engine.scheduleMeasure();}),{passive:true});
  addEventListener('scroll',()=>engines.forEach(engine=>engine.releasePointer()),{passive:true,capture:true});
  addEventListener('blur',sync);
  addEventListener('pagehide',()=>engines.forEach(engine=>{engine.release();engine.settle();}));
  addEventListener('pageshow',sync);
  document.addEventListener('visibilitychange',sync);
  reduced.addEventListener('change',sync);
  document.fonts?.ready.then(sync);
})();

/* Artwork reacts to reading and pointer position; text and native gestures stay put. */
(() => {
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),animations=new Map();
 const artworks=[...document.querySelectorAll('.work-art,.film-collection-cover')];
 let frame=0,pending=null;
 const reset=node=>{
  node.style.setProperty('--gallery-rx','0deg');node.style.setProperty('--gallery-ry','0deg');
  node.style.setProperty('--gallery-light-x','80%');node.style.setProperty('--gallery-light-y','0%');
 };
 for(const art of artworks){
  art.addEventListener('pointermove',event=>{
   if(reduced.matches||document.hidden||event.pointerType!=='mouse')return;
   pending={art,x:event.clientX,y:event.clientY};if(frame)return;
   frame=requestAnimationFrame(()=>{
    frame=0;if(!pending||reduced.matches||document.hidden)return;
    const {art,x,y}=pending,r=art.getBoundingClientRect();
    const nx=Math.max(0,Math.min(1,(x-r.left)/r.width)),ny=Math.max(0,Math.min(1,(y-r.top)/r.height));
    art.style.setProperty('--gallery-rx',((.5-ny)*4).toFixed(2)+'deg');
    art.style.setProperty('--gallery-ry',((nx-.5)*5).toFixed(2)+'deg');
    art.style.setProperty('--gallery-light-x',(nx*100).toFixed(1)+'%');
    art.style.setProperty('--gallery-light-y',(ny*100).toFixed(1)+'%');
   });
  },{passive:true});
  art.addEventListener('pointerleave',()=>{if(pending?.art===art)pending=null;reset(art);},{passive:true});
 }
 const clear=()=>{
  cancelAnimationFrame(frame);frame=0;pending=null;
  for(const animation of animations.values())animation.cancel();animations.clear();artworks.forEach(reset);
 };
 if('IntersectionObserver' in window){
  const observer=new IntersectionObserver(entries=>{
   for(const entry of entries){
    const node=entry.target;
    if(!entry.isIntersecting){animations.get(node)?.cancel();continue;}
    observer.unobserve(node);
    if(reduced.matches||document.hidden||node.dataset.galleryEntered)continue;
    node.dataset.galleryEntered='true';
    const animation=node.animate([{opacity:.52,translate:'0 22px',scale:.97},{opacity:1,translate:'0 0',scale:1}],{duration:700,easing:'cubic-bezier(.18,.8,.22,1)'});
    animations.set(node,animation);animation.finished.catch(()=>{}).finally(()=>animations.delete(node));
   }
  },{threshold:.16});
  document.querySelectorAll('[data-gallery-reveal]').forEach(node=>observer.observe(node));
 }
 document.querySelectorAll('.proof-disclosure').forEach(details=>{
  details.addEventListener('toggle',()=>{
   const content=details.querySelector('.proof-content');if(!content)return;
   animations.get(content)?.cancel();if(!details.open||reduced.matches)return;
   const animation=content.animate([{opacity:.4,translate:'0 -6px'},{opacity:1,translate:'0 0'}],{duration:240,easing:'ease-out'});
   animations.set(content,animation);animation.finished.catch(()=>{}).finally(()=>animations.delete(content));
  });
 });
 reduced.addEventListener('change',clear);addEventListener('pagehide',clear);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)clear();});
})();

/* One input owner for surface lighting and pressure; no scroll interception. */
(() => {
  'use strict';
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  const coarse=matchMedia('(hover: none)');
  const root=document.documentElement;
  const surfaces=[...document.querySelectorAll('.practice-glass,.work-card,.contact-identity,.event-preview')];
  for(const surface of surfaces)surface.dataset.materialSurface='';
  const timers=new Map();
  let held=null,surfaceHeld=null,frame=0,pending=null;
  const selector='.button,.practice-link,summary,.contact-copy,.dialog-close,.sprite-close,.sprite-form button,.sprite-answer-source,.sprite-resume,.era-hero-foot a,[data-control-glass] a,[data-control-glass] button';
  const targetFor=target=>target?.closest?.(selector);
  function illuminate(node,x,y){
    const b=node.getBoundingClientRect();
    const nx=Math.max(0,Math.min(1,(x-b.left)/Math.max(1,b.width)));
    const ny=Math.max(0,Math.min(1,(y-b.top)/Math.max(1,b.height)));
    node.style.setProperty('--press-x',(nx*100).toFixed(1)+'%');
    node.style.setProperty('--press-y',(ny*100).toFixed(1)+'%');
    node.style.setProperty('--press-rx',((.5-ny)*3).toFixed(2)+'deg');
    node.style.setProperty('--press-ry',((nx-.5)*4).toFixed(2)+'deg');
  }
  function finish(animate=false){
    if(!held)return;
    const node=held.node;held=null;node.removeAttribute('data-glass-pressed');
    clearTimeout(timers.get(node));timers.delete(node);
    if(animate&&!reduced.matches&&!document.hidden){
      node.dataset.glassReleased='true';
      timers.set(node,setTimeout(()=>{node.removeAttribute('data-glass-released');timers.delete(node);},500));
    }else node.removeAttribute('data-glass-released');
  }
  function releaseSurface(animate=false){
    if(!surfaceHeld)return;
    const node=surfaceHeld.node;surfaceHeld=null;node.removeAttribute('data-surface-pressed');
    clearTimeout(timers.get(node));timers.delete(node);
    if(animate&&!reduced.matches&&!document.hidden){
      node.setAttribute('data-surface-released','');
      timers.set(node,setTimeout(()=>{node.removeAttribute('data-surface-released');timers.delete(node);},650));
    }
  }
  function press(node,id,x,y){
    finish();clearTimeout(timers.get(node));timers.delete(node);node.removeAttribute('data-glass-released');
    illuminate(node,x,y);held={node,id,x,y};node.dataset.glassPressed='true';
  }
  document.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0)return;
    const node=targetFor(event.target);
    if(!node){
      const surface=event.target.closest?.('[data-material-surface]');
      if(surface&&!event.target.closest('input,select,textarea,video,a,button')){
        releaseSurface();const box=surface.getBoundingClientRect();
        surface.style.setProperty('--surface-x',((event.clientX-box.left)/box.width*100)+'%');
        surface.style.setProperty('--surface-y',((event.clientY-box.top)/box.height*100)+'%');
        surfaceHeld={node:surface,id:event.pointerId,x:event.clientX,y:event.clientY};surface.setAttribute('data-surface-pressed','');
      }
      return;
    }
    if(node.disabled)return;
    press(node,event.pointerId,event.clientX,event.clientY);
  },{passive:true});
  document.addEventListener('pointermove',event=>{
    if(surfaceHeld?.id===event.pointerId&&Math.hypot(event.clientX-surfaceHeld.x,event.clientY-surfaceHeld.y)>10)releaseSurface();
    if(held?.id===event.pointerId){
      if(Math.hypot(event.clientX-held.x,event.clientY-held.y)>12){finish();return;}
      illuminate(held.node,event.clientX,event.clientY);
    }
    if(reduced.matches||coarse.matches||document.hidden||event.pointerType!=='mouse')return;
    const surface=event.target.closest?.('[data-material-surface]');if(!surface)return;
    pending={surface,x:event.clientX,y:event.clientY};
    if(!frame)frame=requestAnimationFrame(()=>{
      frame=0;if(!pending||document.hidden||reduced.matches)return;
      const {surface,x,y}=pending,b=surface.getBoundingClientRect();pending=null;
      const nx=Math.max(0,Math.min(1,(x-b.left)/b.width)),ny=Math.max(0,Math.min(1,(y-b.top)/b.height));
      surface.style.setProperty('--surface-x',(nx*100).toFixed(1)+'%');surface.style.setProperty('--surface-y',(ny*100).toFixed(1)+'%');
      surface.style.setProperty('--surface-rx',((.5-ny)*1.2).toFixed(2)+'deg');surface.style.setProperty('--surface-ry',((nx-.5)*1.6).toFixed(2)+'deg');
    });
  },{passive:true});
  document.addEventListener('pointerup',event=>{if(held?.id===event.pointerId)finish(true);if(surfaceHeld?.id===event.pointerId)releaseSurface(true);},{passive:true});
  document.addEventListener('pointercancel',()=>{finish();releaseSurface();},{passive:true});
  document.addEventListener('keydown',event=>{
    if(event.defaultPrevented||event.repeat||event.isComposing||event.metaKey||event.ctrlKey||event.altKey||!['Enter',' '].includes(event.key))return;
    const node=targetFor(event.target);if(!node||node.disabled||node.matches('a')&&event.key===' ')return;
    const b=node.getBoundingClientRect();press(node,'keyboard',b.left+b.width/2,b.top+b.height/2);
  });
  document.addEventListener('keyup',event=>{if(held?.id==='keyboard'&&['Enter',' '].includes(event.key))finish(true);});
  document.addEventListener('focusout',()=>{if(held?.id==='keyboard')finish();});
  for(const surface of surfaces){
    surface.addEventListener('pointerleave',()=>{surface.style.setProperty('--surface-rx','0deg');surface.style.setProperty('--surface-ry','0deg');});
  }
  function clear(){
    finish();releaseSurface();cancelAnimationFrame(frame);frame=0;pending=null;
    for(const [node,timer]of timers){clearTimeout(timer);node.removeAttribute('data-glass-released');node.removeAttribute('data-surface-released');}timers.clear();
    for(const surface of surfaces){surface.style.setProperty('--surface-rx','0deg');surface.style.setProperty('--surface-ry','0deg');}
  }
  function lifecycle(){root.dataset.scenePaused=String(document.hidden);if(document.hidden)clear();}
  document.addEventListener('visibilitychange',lifecycle);
  addEventListener('scroll',()=>{finish();releaseSurface();},{passive:true,capture:true});
  addEventListener('blur',clear);addEventListener('pagehide',()=>{root.dataset.scenePaused='true';clear();});
  addEventListener('pageshow',lifecycle);reduced.addEventListener('change',clear);coarse.addEventListener('change',clear);lifecycle();
})();

/* Portfolio-only live atmosphere. The generated 1,228,800 samples supply
 * height and normals to broad pearl planes and direct touch refraction. */
(() => {
  'use strict';
  if (/(?:^|\/)game(?:\/|$)/.test(location.pathname) || document.querySelector('[data-optical-scene]')) return;
  document.body.dataset.atmosphereRenderer = 'fallback';
  const profiles = {
    home: [0, .72, .0, [.76,.86,.99]],
    work: [-.45, .78, 1.8, [.69,.82,.99]],
    experience: [.55, .66, 3.9, [.70,.89,.83]],
    honor: [-.82, .58, 5.7, [.96,.83,.65]],
    contact: [.9, .70, 7.4, [.82,.74,.96]],
  };
  const scene = profiles[document.body.dataset.atmosphere] || profiles.work;
  const water = document.createElement('div');
  water.className = 'water-events';
  water.setAttribute('aria-hidden', 'true');
  // Each event has an actual falling lens followed by two expanding surface rings.
  for (const [x, y, delay] of [[16,28,0],[77,52,-1.05],[34,78,-2.1],[87,18,-3.15]]) {
    const event = document.createElement('span');
    event.className = 'water-event';
    event.style.cssText = `--water-x:${x}%;--water-y:${y}%;--water-delay:${delay}s`;
    event.innerHTML = '<i class="water-drop"></i><i class="water-ring"></i><i class="water-ring water-ring-echo"></i>';
    water.append(event);
  }
  (document.querySelector('.ambient-field') || document.body).append(water);
  // Put the water in front of the hero's own tinted backdrop as well.
  const heroScene=document.querySelector('.home-page .era-silk');
  if(heroScene){
    const heroWater=water.cloneNode(true);heroWater.className='hero-water';
    [...heroWater.children].forEach((event,index)=>{
      if(index>1){event.remove();return;}
      event.style.setProperty('--water-x',index===0?'73%':'91%');
      event.style.setProperty('--water-y',index===0?'62%':'30%');
    });
    heroScene.append(heroWater);
  }

  const source = new URL('glass-flow.0decc9aa5b10.png', document.currentScript.src).href;
  const canvas = document.createElement('canvas');
  canvas.className = 'optical-scene';
  // An opaque WebGL buffer is black before its first draw. Keep the CSS field
  // visible during texture decoding, initialization and context restoration.
  canvas.hidden = true;
  canvas.dataset.opticalScene = 'loading';
  canvas.setAttribute('aria-hidden', 'true');
  (document.querySelector('.ambient-field') || document.body).prepend(canvas);
  const gameplay = !!document.querySelector('#garden');
  const arenaOverlay = gameplay ? document.querySelector('#overlay') : null;
  let battleActive = !!arenaOverlay?.hidden;
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const contrast = matchMedia('(prefers-contrast: more)');
  const transparency = matchMedia('(prefers-reduced-transparency: reduce)');
  // One contact lens is shared by blank-space touches, including the CSS fallback.
  // It never owns a gesture or delays navigation; controls have their own material.
  const contact = document.createElement('span');
  contact.className = 'surface-touch';contact.setAttribute('aria-hidden','true');
  (document.querySelector('.ambient-field') || document.body).append(contact);
  let contactPointer=null, contactOrigin=null, contactAnimation=null;
  const clearContact = () => {
    contactPointer=null;contactOrigin=null;contactAnimation?.cancel();
    contact.removeAttribute('data-held');contact.style.opacity='';
  };
  document.addEventListener('pointerdown',event=>{
    if(!event.isPrimary||event.button!==0||contrast.matches||transparency.matches||
       event.target.closest?.('a,button,summary,input,select,textarea,[role=dialog]'))return;
    contactAnimation?.cancel();contactPointer=event.pointerId;
    contactOrigin={x:event.clientX,y:event.clientY};
    contact.style.left=event.clientX+'px';contact.style.top=event.clientY+'px';
    contact.setAttribute('data-held','');
  },{passive:true});
  document.addEventListener('pointermove',event=>{
    if(event.pointerId===contactPointer&&contactOrigin&&Math.hypot(event.clientX-contactOrigin.x,event.clientY-contactOrigin.y)>12)clearContact();
  },{passive:true});
  addEventListener('pointerup',event=>{
    if(event.pointerId!==contactPointer)return;
    contactPointer=null;contactOrigin=null;contact.removeAttribute('data-held');
    if(motion.matches)return;
    contactAnimation=contact.animate([{opacity:.85,scale:1},{opacity:.38,scale:1.65,offset:.45},{opacity:0,scale:2.2}],{duration:850,easing:'cubic-bezier(.18,.62,.25,1)'});
  },{passive:true});
  for(const name of ['pointercancel','blur','pagehide','scroll'])addEventListener(name,clearContact,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)clearContact();});
  for(const preference of [motion,contrast,transparency])preference.addEventListener('change',clearContact);
  const gl = canvas.getContext('webgl', {alpha: false, antialias: false,
    depth: false, stencil: false, preserveDrawingBuffer: true, powerPreference: 'default'});
  if (!gl) { canvas.remove(); return; } // The authored CSS field stays visible.
  const rendererInfo = gl.getExtension('WEBGL_debug_renderer_info');
  const software = !!rendererInfo && /SwiftShader|llvmpipe|software/i.test(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL));
  const vertex = 'attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}';
  // Broad pearl planes and finite refractive waves belong to the portfolio.
  // The game continues loading its unchanged optical-runtime.js separately.
  const fragment = `precision highp float;
    varying vec2 uv;
    uniform sampler2D field;
    uniform float clock;
    uniform vec2 pointer;
    uniform vec3 pulses[4];
    uniform float aspect;
    uniform float pressure;
    uniform float contactRadius;
    uniform vec3 scene;
    uniform vec3 accent;

    // Visible silk-like currents: the broad moving folds supply the contrast
    // that lets a refracted ripple read through an otherwise clear surface.
    vec3 environment(vec2 q){
      float t=clock*scene.y+scene.z;
      float c=cos(scene.x),s=sin(scene.x);
      vec2 p=mat2(c,-s,s,c)*(q-.5)+.5;
      vec3 pearl=vec3(.972,.984,.998);
      vec3 color=mix(pearl,accent,smoothstep(-.10,1.30,p.y)*.42);
      // A broad moving lens with a defined caustic edge gives clear glass
      // something to refract. The palette stays light enough for reading.
      float fold=p.y-(.36+.23*sin(p.x*3.4+t)+.11*cos(t*.68));
      color=mix(color,accent,exp(-pow((fold-.07)/.16,2.))*.42);
      color+=exp(-pow((fold+.035)/.026,2.))*.075;
      color-=exp(-pow((fold-.105)/.055,2.))*.035;
      float returnFold=p.y-(.88-.30*p.x+.19*sin(p.x*4.-t*.78));
      color=mix(color,accent,exp(-pow((returnFold-.035)/.14,2.))*.30);
      color+=exp(-pow((returnFold+.05)/.032,2.))*.065;
      return clamp(color,vec3(.77),vec3(.997));
    }
    float surface(vec2 p){
      return sin(p.y*4.2+p.x*1.4-clock*.85)*.36
           +sin(p.x*3.4-p.y*1.7+clock*.61)*.19;
    }
    vec3 packet(vec2 delta,float age){
      float radius=length(delta),front=radius-age*.34;
      float envelope=exp(-front*front*155.-age*.72)*smoothstep(0.,.10,age);
      float ridge=sin(front*48.);
      vec2 normal=delta/max(radius,.002)*ridge*envelope;
      return vec3(normal*2.5,cos(front*48.)*envelope);
    }
    void main(){
      vec2 q=vec2(uv.x,1.-uv.y),metric=vec2(aspect,1.);
      vec2 p=q*metric+(pointer-.5)*.012;
      float height=surface(p);
      vec2 slope=vec2(surface(p+vec2(.006,0.))-height,
                      surface(p+vec2(0.,.006))-height)/.006;
      float sheen=0.;
      for(int i=0;i<4;i++){
        if(pulses[i].z>=0.){
          vec3 ripple=packet((q-pulses[i].xy)*metric,max(0.,clock-pulses[i].z));
          slope+=ripple.xy*5.2;
          sheen+=ripple.z*.065;
        }
      }
      // A sparse falling bead and its wake share one clock and one impact point.
      // The wake bends the same planes; it is never an independent bright ring.
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*1.8,5.4)-.9;
        vec2 center=vec2(.18+id*.32,.30+mod(id*.35,.50));
        if(age>=0.){
          vec3 ripple=packet((q-center)*metric,age);
          slope+=ripple.xy*1.7;
          sheen+=ripple.z*.027;
        }
      }
      vec2 finger=(q-pointer)*metric/max(.025,contactRadius);
      float dimple=exp(-dot(finger,finger)*2.1)*pressure;
      slope+=finger*dimple*5.0;
      vec2 drift=vec2(sin(clock*.09),cos(clock*.075))*.018;
      vec3 sampled=texture2D(field,clamp(q*.84+.08+drift,.001,.999)).rgb;
      vec2 normal=-slope*.19+(sampled.gb-.5)*.020;
      vec2 refracted=q+normal*.20/metric;
      vec3 color=environment(refracted);
      // A broad specular response reads as depth without hard neon-like ridges.
      float softLight=pow(max(dot(normalize(vec3(normal,1.)),normalize(vec3(-.25,-.35,1.))),0.),12.);
      color+=softLight*.018+sheen+sampled.r*.0015;
      color-=dimple*.042;
      color+=exp(-pow((length(finger)-.85)*7.,2.))*pressure*.060;
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*1.8,5.4)-.9;
        if(age<0.){
          float fall=clamp((age+.9)/.9,0.,1.);
          vec2 center=vec2(.18+id*.32,.30+mod(id*.35,.50)-.22*(1.-fall*fall));
          vec2 local=(q-center)*metric/vec2(.018,.028-.010*fall);
          float distance=length(local),mask=1.-smoothstep(.90,1.06,distance);
          float curve=sqrt(max(.001,1.-min(distance*distance,1.)));
          vec3 bead=environment(q+local*.035/metric);
          float reflection=pow(max(dot(normalize(vec3(local,curve)),normalize(vec3(-.45,-.7,1.))),0.),30.);
          bead+=reflection*.26;
          bead-=smoothstep(.60,1.,distance)*.035;
          color=mix(color,bead,mask*smoothstep(0.,.22,fall));
        }
      }
      gl_FragColor=vec4(clamp(color,0.,1.),1.);
    }`;
  function shader(type, text) {
    const result = gl.createShader(type);
    if (type === gl.FRAGMENT_SHADER && !gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)?.precision) text = text.replace('precision highp float;', 'precision mediump float;');
    gl.shaderSource(result, text); gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) throw Error('Optical shader compilation failed');
    return result;
  }
  let program, texture, frame = 0, last = 0, elapsed = 0, ready = false, lost = false, needsPaint = true, suspended = false;
  const pointer = [.5, .5], pulses = new Float32Array([.5,.5,-1,.5,.5,-1,.5,.5,-1,.5,.5,-1]);
  let pulseIndex = 0, held = false, pressure = 0, lastTrail = 0, contactId = null;
  let buffer = null, locations = null;
  function clearPressure() { held = false; pressure = 0; contactId = null; }
  function clearWaves() { for (let i = 2; i < pulses.length; i += 3) pulses[i] = -1; }
  function position(event) {
    pointer[0] = Math.max(0, Math.min(1, event.clientX / innerWidth));
    pointer[1] = Math.max(0, Math.min(1, event.clientY / innerHeight));
  }
  function stopped() { return suspended || battleActive || document.hidden || contrast.matches || transparency.matches || lost; }
  function resize() {
    // Native GPUs keep the full-resolution field. CPU-only rasterizers get a
    // smaller backing buffer so material never competes with direct manipulation.
    const scale = gameplay
      ? Math.min(.75, 640 / innerWidth, 480 / innerHeight)
      : software ? Math.min(1, 640 / innerWidth, 480 / innerHeight)
      : matchMedia('(pointer: coarse)').matches || navigator.connection?.saveData
        ? Math.min(devicePixelRatio || 1, 1.25, 1152 / innerWidth, 1152 / innerHeight)
        : Math.min(devicePixelRatio || 1, 1.5, 1920 / innerWidth, 1440 / innerHeight);
    needsPaint = true;
    canvas.width = Math.max(1, Math.round(innerWidth * scale));
    canvas.height = Math.max(1, Math.round(innerHeight * scale));
  }
  function draw(now = 0) {
    frame = 0;
    if (!ready || stopped() || (motion.matches && !needsPaint)) { last = 0; return; }
    if (last && now - last < (held ? 15 : 32) && !motion.matches && !needsPaint) { frame = requestAnimationFrame(draw); return; }
    // Analytic waves follow wall time even on a busy or low-refresh device.
    // resume() resets last, so hidden time never causes a catch-up jump.
    const delta = last ? Math.max(0, (now-last)/1000) : 1/60;
    if (last && !motion.matches) elapsed += delta;
    last = now;
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.useProgram(program);
    gl.uniform1f(locations.clock, elapsed);
    gl.uniform1f(locations.aspect, canvas.width / canvas.height);
    gl.uniform3f(locations.scene, scene[0], scene[1], scene[2]);
    gl.uniform3fv(locations.accent, scene[3]);
    gl.uniform2fv(locations.pointer, pointer);
    pressure += ((held ? 1 : 0) - pressure) * (1-Math.exp(-delta*18));
    gl.uniform1f(locations.pressure, pressure);
    gl.uniform1f(locations.contactRadius, 72 / innerHeight);
    gl.uniform3fv(locations.pulses, pulses);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    canvas.hidden = false;
    document.body.dataset.atmosphereRenderer = 'webgl';
    water.hidden = true;
    needsPaint = false;
    canvas.dataset.opticalSeconds = elapsed.toFixed(3);
    canvas.dataset.opticalFrames = String(Number(canvas.dataset.opticalFrames || 0) + 1);
    if (!motion.matches) frame = requestAnimationFrame(draw);
  }
  function resume() {
    if (frame) cancelAnimationFrame(frame);
    frame = 0; last = 0;
    if (stopped() || motion.matches) { clearPressure(); clearWaves(); }
    document.documentElement.dataset.waterPaused = document.hidden || battleActive ? 'true' : 'false';
    canvas.dataset.opticalMotion = motion.matches ? 'still' : 'live';
    if (ready && !stopped() && (!motion.matches || needsPaint)) frame = requestAnimationFrame(draw);
  }
  if (arenaOverlay) new MutationObserver(() => {
    const next = arenaOverlay.hidden;
    if (next === battleActive) return;
    battleActive = next; resume();
  }).observe(arenaOverlay, {attributes:true, attributeFilter:['hidden']});
  const image = new Image();
  function initialize() {
    try {
      if (program && !lost) { gl.deleteProgram(program); gl.deleteTexture(texture); gl.deleteBuffer(buffer); }
      program = gl.createProgram();
      const vs = shader(gl.VERTEX_SHADER, vertex), fs = shader(gl.FRAGMENT_SHADER, fragment);
      gl.attachShader(program, vs); gl.attachShader(program, fs); gl.linkProgram(program);
      gl.deleteShader(vs); gl.deleteShader(fs);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('Optical shader linking failed');
      gl.useProgram(program);
      locations = Object.fromEntries(['clock','aspect','pointer','pressure','contactRadius','scene','accent'].map(name => [name, gl.getUniformLocation(program, name)]));
      locations.pulses = gl.getUniformLocation(program, 'pulses[0]');
      buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]), gl.STATIC_DRAW);
      const attribute = gl.getAttribLocation(program, 'a');
      gl.enableVertexAttribArray(attribute); gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
      texture = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
      gl.uniform1i(gl.getUniformLocation(program, 'field'), 0);
      canvas.dataset.opticalScene = 'webgl';
      canvas.dataset.opticalMaterial = 'responsive-current-v29';
      canvas.dataset.opticalSamples = String(image.width * image.height);
      ready = true; resize(); resume();
    } catch { ready = false; canvas.hidden = true; water.hidden = false; document.body.dataset.atmosphereRenderer = 'fallback'; }
  }
  image.onload = initialize;
  image.onerror = () => canvas.remove();
  image.src = source;
  addEventListener('resize', () => { resize(); resume(); }, {passive: true});
  document.addEventListener('visibilitychange', resume);
  addEventListener('pagehide', event => {
    suspended = true; held = false; resume();
    if (!event.persisted) gl.getExtension('WEBGL_lose_context')?.loseContext();
  });
  addEventListener('pageshow', () => { suspended = false; resume(); });
  for (const preference of [motion, contrast, transparency]) preference.addEventListener('change', () => { needsPaint = true; resume(); });
  document.addEventListener('pointermove', event => {
    if (!event.isPrimary || motion.matches || stopped() || (contactId !== null && event.pointerId !== contactId)) return;
    position(event);
    if (held && event.timeStamp - lastTrail > 90) { lastTrail = event.timeStamp; ripple(pointer[0], pointer[1]); }
  }, {passive: true});
  function ripple(x, y) {
    if (motion.matches || stopped()) return;
    const offset = (pulseIndex++ % 4) * 3;
    pulses[offset] = x; pulses[offset+1] = y; pulses[offset+2] = elapsed;
    canvas.dataset.opticalInputs = String(Number(canvas.dataset.opticalInputs || 0) + 1);
  }
  document.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0 || motion.matches || stopped()) return;
    if(event.target.closest?.('a,button,summary,input,select,textarea,[role=dialog]'))return;
    position(event); contactId = event.pointerId;needsPaint=true;
    held = true; ripple(pointer[0], pointer[1]);
  }, {passive: true});
  addEventListener('pointerup', event => {
    if (event.pointerId !== contactId) return;
    position(event); held = false; contactId = null;
    ripple(pointer[0], pointer[1]);
  }, {passive: true});
  addEventListener('pointercancel', event => { if (event.pointerId === contactId) clearPressure(); }, {passive: true});
  for (const event of ['blur','pagehide']) addEventListener(event, clearPressure, {passive: true});
  document.addEventListener('visibilitychange', () => { if (document.hidden) held = false; });
  addEventListener('gardenoptics', event => ripple(event.detail?.x ?? .5, event.detail?.y ?? .5));
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); lost = true; canvas.hidden = true; water.hidden = false; document.body.dataset.atmosphereRenderer = 'fallback'; resume(); });
  canvas.addEventListener('webglcontextrestored', () => { lost = false; initialize(); });
})();
