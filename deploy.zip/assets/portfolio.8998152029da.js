/* Progressive portfolio interactions. Include once with defer; no dependencies. */
(() => {
  'use strict';
  const all = (selector, root = document) => [...root.querySelectorAll(selector)];
  const byId = id => id ? document.getElementById(id.replace(/^#/, '')) : null;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const focusable = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
  const isOpen = dialog => Boolean(dialog?.hasAttribute('open'));
  const canFocus = node => node && !node.hidden && node.getClientRects().length > 0;
  const fallbackStates = new WeakMap();
  const modalSupported = typeof HTMLDialogElement !== 'undefined' && typeof HTMLDialogElement.prototype.showModal === 'function';
  const openers = new WeakMap();
  const triggers = new WeakMap();
  let activeDialog = null;
  let priorOverflow = '';
  let priorGutter = '';
  const outsideStarts = new WeakMap();

  function finishClose(dialog, restoreFocus = true) {
    if (isOpen(dialog) || activeDialog !== dialog) return;
    all('video, audio', dialog).forEach(media => media.pause());
    const opener = openers.get(dialog);
    triggers.get(dialog)?.setAttribute('aria-expanded', 'false');
    const fallback = fallbackStates.get(dialog);
    if (fallback) {
      fallback.backdrop.remove();
      fallback.background.forEach(({ node, inert, hidden }) => {
        if ('inert' in node) node.inert = inert;
        if (hidden === null) node.removeAttribute('aria-hidden'); else node.setAttribute('aria-hidden', hidden);
      });
      if (fallback.style === null) dialog.removeAttribute('style'); else dialog.setAttribute('style', fallback.style);
      if (fallback.role === null) dialog.removeAttribute('role'); else dialog.setAttribute('role', fallback.role);
      dialog.removeAttribute('aria-modal');
      fallbackStates.delete(dialog);
    }
    document.documentElement.style.overflow = priorOverflow;
    document.documentElement.style.scrollbarGutter = priorGutter;
    activeDialog = null;
    if (restoreFocus && opener?.isConnected && canFocus(opener) && !opener.closest('dialog:not([open])')) opener.focus({ preventScroll: true });
  }
  function close(dialog, restoreFocus = true) {
    if (!isOpen(dialog)) return;
    if (fallbackStates.has(dialog)) dialog.removeAttribute('open');
    else dialog.close();
    // Native close events are queued: settle this session before opening another.
    finishClose(dialog, restoreFocus);
  }
  function open(dialog, opener) {
    if (!dialog || dialog.tagName !== 'DIALOG') return false;
    if (isOpen(dialog)) return true;
    const returnOpener = activeDialog && opener?.closest('dialog') === activeDialog ? openers.get(activeDialog) : opener;
    if (activeDialog && activeDialog !== dialog) close(activeDialog, false);
    openers.set(dialog, returnOpener);
    triggers.set(dialog, opener);
    priorOverflow = document.documentElement.style.overflow;
    priorGutter = document.documentElement.style.scrollbarGutter;
    // Reserve the scrollbar lane so opening a dialog does not shift the page.
    document.documentElement.style.scrollbarGutter = 'stable';
    document.documentElement.style.overflow = 'hidden';
    // Older WebViews still receive a usable, focus-contained dialog.
    let nativeOpened = false;
    if (modalSupported) {
      try { dialog.showModal(); nativeOpened = true; } catch (_) { /* Use the local fallback. */ }
    }
    if (!nativeOpened) {
      const backdrop = document.createElement('div');
      backdrop.setAttribute('aria-hidden', 'true');
      backdrop.style.cssText = 'position:fixed;inset:0;z-index:9998;background:rgba(12,20,32,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px)';
      const background = all('body > *').filter(node => node !== dialog && !['SCRIPT', 'STYLE'].includes(node.tagName))
        .map(node => ({ node, inert: node.inert, hidden: node.getAttribute('aria-hidden') }));
      fallbackStates.set(dialog, { backdrop, background, style: dialog.getAttribute('style'), role: dialog.getAttribute('role') });
      background.forEach(({ node }) => { if ('inert' in node) node.inert = true; else node.setAttribute('aria-hidden', 'true'); });
      document.body.append(backdrop);
      backdrop.addEventListener('click', () => close(dialog));
      dialog.setAttribute('open', '');
      dialog.setAttribute('role', 'dialog');
      dialog.setAttribute('aria-modal', 'true');
      Object.assign(dialog.style, { display: 'block', position: 'fixed', zIndex: '9999', inset: '0', margin: 'auto', overflow: 'auto', maxHeight: 'calc(100% - 24px)' });
    }
    activeDialog = dialog;
    opener?.setAttribute('aria-expanded', 'true');
    requestAnimationFrame(() => {
      if (activeDialog !== dialog || !isOpen(dialog)) return;
      const target = dialog.querySelector('[autofocus]') ||
        dialog.querySelector('[data-dialog-close], button, a[href], input');
      if (target) target.focus({ preventScroll: true });
      else { dialog.tabIndex = -1; dialog.focus({ preventScroll: true }); }
    });
    return true;
  }

  all('dialog').forEach(dialog => {
    if (!modalSupported) dialog.style.display = 'none';
    dialog.addEventListener('close', () => {
      // Ignore an older queued close if this dialog has already reopened.
      finishClose(dialog);
    });
    const outside = event => {
      const box = dialog.getBoundingClientRect();
      return event.target === dialog && (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom);
    };
    dialog.addEventListener('pointerdown', event => { outsideStarts.set(dialog, outside(event)); });
    dialog.addEventListener('cancel', event => { event.preventDefault(); close(dialog); });
    dialog.addEventListener('click', event => {
      // A drag starting inside the dialog must never dismiss it on release.
      const startedOutside = outsideStarts.get(dialog);
      outsideStarts.delete(dialog);
      if (!startedOutside || event.target !== dialog) return;
      const box = dialog.getBoundingClientRect();
      if (event.clientX < box.left || event.clientX > box.right || event.clientY < box.top || event.clientY > box.bottom) close(dialog);
    });
    all('[data-dialog-close], [data-portrait-close]', dialog).forEach(button => button.addEventListener('click', () => close(dialog)));
  });

  all('[data-dialog-open], [data-portrait-open], [data-image-open]').forEach(opener => {
    const id = opener.dataset.dialogOpen || opener.dataset.imageTarget || 'portrait-dialog';
    const dialog = byId(id);
    if (!dialog) {
      // Keep real hrefs operational; dead buttons should not appear interactive.
      if (opener.tagName === 'BUTTON') opener.hidden = true;
      return;
    }
    opener.setAttribute('aria-controls', dialog.id);
    opener.setAttribute('aria-haspopup', 'dialog');
    opener.setAttribute('aria-expanded', 'false');
    opener.addEventListener('click', event => {
      if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      if (opener.hasAttribute('data-image-open')) {
        const image = dialog.querySelector('[data-dialog-image]');
        const source = opener.dataset.imageSrc || opener.getAttribute('href');
        if (image && source) {
          let url;
          try { url = new URL(source, location.href); } catch (_) { return; }
          if (!['https:', 'http:'].includes(url.protocol)) return;
          image.src = url.href;
          image.alt = opener.dataset.imageAlt || opener.querySelector('img')?.alt || '作品图片';
        }
      }
      if (open(dialog, opener)) event.preventDefault();
    });
  });

  document.addEventListener('keydown', event => {
    if (event.isComposing || event.keyCode === 229 || event.defaultPrevented) return;
    if (activeDialog && event.key === 'Escape') { event.preventDefault(); close(activeDialog); return; }
    if (!activeDialog || !fallbackStates.has(activeDialog)) return;
    if (event.key === 'Tab') {
      const targets = all(focusable, activeDialog).filter(canFocus);
      const first = targets[0];
      const last = targets[targets.length - 1];
      if (!first) { event.preventDefault(); activeDialog.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !activeDialog.contains(document.activeElement))) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && (document.activeElement === last || !activeDialog.contains(document.activeElement))) { event.preventDefault(); first.focus(); }
    }
  });

  // No autoplay, scroll hijacking, or automatic audio resumption.
  // Native video controls remain the single playback surface.
  const pauseMedia = () => all('video').forEach(media => media.pause());
  document.addEventListener('visibilitychange', () => { if (document.hidden) pauseMedia(); });
  window.addEventListener('pagehide', pauseMedia);

  // A small, explicit choice illustrates the mechanism; no timed advancement.
  all('.growth-demo').forEach(demo => {
    const buttons = all('button[data-growth-step]', demo);
    const panels = all('[data-growth-panel]', demo);
    if (!buttons.length || !panels.length) return;
    const select = step => {
      const chosen = panels.find(panel => panel.dataset.growthPanel === step);
      if (!chosen) return;
      buttons.forEach(button => button.setAttribute('aria-pressed', String(button.dataset.growthStep === step)));
      panels.forEach(panel => { panel.hidden = panel !== chosen; });
    };
    buttons.forEach(button => button.addEventListener('click', () => select(button.dataset.growthStep)));
    const initial = buttons.find(button => button.getAttribute('aria-pressed') === 'true') || buttons[0];
    select(initial.dataset.growthStep);
    demo.classList.add('is-enhanced');
  });

  document.documentElement.classList.add('js-ready');

  // Content remains visible if JS fails or IntersectionObserver is unsupported.
  const reveal = all('[data-reveal]');
  let observer;
  const settleReveal = () => {
    observer?.disconnect();
    reveal.forEach(node => { node.classList.remove('reveal-pending'); node.classList.add('is-visible'); });
  };
  if (!reduce.matches && 'IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.remove('reveal-pending');
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.08 });
    reveal.forEach(node => {
      // Above-the-fold content is immediately readable, even on a slow device.
      const box = node.getBoundingClientRect();
      if (box.top < innerHeight && box.bottom > 0) node.classList.add('is-visible');
      else { observer.observe(node); node.classList.add('reveal-pending'); }
    });
    document.addEventListener('focusin', event => {
      const section = event.target.closest?.('[data-reveal]');
      if (section) { section.classList.remove('reveal-pending'); section.classList.add('is-visible'); observer.unobserve(section); }
    });
    window.addEventListener('beforeprint', settleReveal);
    window.addEventListener('pageshow', event => { if (event.persisted) settleReveal(); });
  } else settleReveal();
  // Only active reveal effects respond to the motion preference.
  const motionChanged = () => { if (reduce.matches) settleReveal(); };
  if (reduce.addEventListener) reduce.addEventListener('change', motionChanged);
  else reduce.addListener(motionChanged);
})();

/* The dock keeps real links and native vertical scrolling. Only a deliberate
   horizontal drag becomes a liquid selection gesture. No page-wide effects. */
(() => {
  'use strict';
  const dock = document.querySelector('[data-glass-dock]');
  if (!dock || dock.dataset.glassReady) return;
  const lens = dock.querySelector('[data-dock-lens]');
  const links = [...dock.querySelectorAll('[data-dock-item]')];
  const isLink = item => item.hasAttribute('data-dock-link');
  if (!lens || !links.length) return;
  dock.dataset.glassReady = 'true';
  // Anchors remain ordinary links, but their browser drag ghost would cancel
  // the pointer stream before our horizontal liquid gesture can take ownership.
  links.forEach(link => {
    link.setAttribute('draggable', 'false');
    link.querySelectorAll('svg,img').forEach(node => node.setAttribute('draggable', 'false'));
  });
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const aborter = new AbortController();
  const signal = aborter.signal;
  const clamp = (n, low, high) => Math.max(low, Math.min(high, n));
  let selected = Math.max(0, links.findIndex(link => link.hasAttribute('aria-current')));
  let dockLeft = 0, measuredRect = null;
  let boxes = [], current = 0, target = 0, width = 0, targetWidth = 0;
  let velocity = 0, frame = 0, lastTime = 0, gesture = null;
  let suppressClickUntil = 0, navigationTimer = 0, dragActivation = false;
  let heldScale = 0, heldVelocity = 0;
  let resizeObserver = null, contrastObserver = null, pendingHref = '';
  const contrastSources = [...document.querySelectorAll('video, .dark, [data-dock-tone=dark]')];
  function observeContrast() {
    contrastObserver?.disconnect();
    if (!contrastSources.length || !('IntersectionObserver' in window)) return;
    const box = dock.getBoundingClientRect();
    const viewportHeight = window.innerHeight, viewportWidth = window.innerWidth;
    const center = box.top + box.height / 2;
    const active = new Set();
    contrastObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) active.add(entry.target); else active.delete(entry.target); });
      dock.toggleAttribute('data-over-media', active.size > 0);
    }, {rootMargin:`${-center}px ${-(viewportWidth - box.right)}px ${-(viewportHeight - center - 1)}px ${-box.left}px`, threshold:0});
    contrastSources.forEach(node => contrastObserver.observe(node));
  }
  const handoffKey = 'portfolio-dock-handoff-v2';
  const normalizedPath = pathname => pathname.replace(/\/index\.html$/, '/');
  function samePage(a, b) {
    return a.origin === b.origin && normalizedPath(a.pathname) === normalizedPath(b.pathname) && a.search === b.search;
  }
  function clearHandoff() {
    pendingHref = '';
    try { sessionStorage.removeItem(handoffKey); } catch (_) { /* Storage may be disabled. */ }
  }
  function saveHandoff() {
    if (!pendingHref || reduce.matches || boxes.length < 2) return;
    const span = boxes.at(-1).x - boxes[0].x;
    if (span <= 0) return;
    try {
      sessionStorage.setItem(handoffKey, JSON.stringify({
        href: pendingHref, at: Date.now(), fraction: (current - boxes[0].x) / span,
        speed: clamp(velocity / span, -3, 3), lift: heldScale
      }));
    } catch (_) { /* Ordinary anchor navigation remains available without storage. */ }
  }
  function restoreHandoff() {
    let state;
    try {
      state = JSON.parse(sessionStorage.getItem(handoffKey));
      sessionStorage.removeItem(handoffKey);
    } catch (_) { return; }
    if (reduce.matches || !state || typeof state.href !== 'string' ||
        !Number.isFinite(state.at) || Date.now() - state.at < 0 || Date.now() - state.at > 2000 ||
        !Number.isFinite(state.fraction) || state.fraction < -.1 || state.fraction > 1.1 ||
        !Number.isFinite(state.speed) || !Number.isFinite(state.lift)) return;
    try { if (!samePage(new URL(state.href, location.href), new URL(location.href))) return; } catch (_) { return; }
    const span = boxes.at(-1).x - boxes[0].x;
    current = boxes[0].x + state.fraction * span;
    velocity = clamp(state.speed, -3, 3) * span;
    heldScale = clamp(state.lift, 0, 1);
    paint(1 + heldScale * .09, 1 + heldScale * .16);
    animate();
  }

  // The shell alone samples the backdrop. The empty lens is one composited
  // surface: no filters, cloned labels, width animation or per-item frame writes.
  function paint(stretch = 1, squash = 1) {
    lens.style.setProperty('--lens-x', `${current.toFixed(3)}px`);
    lens.style.setProperty('--lens-stretch', stretch.toFixed(4));
    lens.style.setProperty('--lens-squash', squash.toFixed(4));
    lens.style.setProperty('--lens-glint-shift', `${clamp(velocity * .008, -10, 10).toFixed(3)}px`);
    lens.style.setProperty('--lens-glint-alpha', (.2 + Math.min(.45, Math.abs(velocity) * .0003 + Math.abs(heldScale) * .24)).toFixed(3));
  }
  function tick(time) {
    frame = 0;
    if (document.hidden) return;
    const dt = clamp((time - (lastTime || time - 16.667)) / 1000, .001, .04);
    lastTime = time;
    // Exact critically damped spring; its response is independent of 60/120 Hz.
    if (gesture?.dragging) {
      // Coalesce input into one paint per display frame; do not make the finger
      // chase a spring. Only the released lens settles with inertia.
      velocity = (target - current) / dt;
      current = target;
    } else {
      const omega = 24;
      const offset = current - target, c = velocity + omega * offset;
      const decay = Math.exp(-omega * dt);
      current = target + (offset + c * dt) * decay;
      velocity = (velocity - omega * c * dt) * decay;
    }
    const heldTarget = gesture ? 1 : 0;
    // Closed-form damped droplet response: one restrained release ripple,
    // independent of display refresh rate and with no geometry/filter animation.
    const frequency = 30, damping = .72, decayLift = Math.exp(-damping * frequency * dt);
    const damped = frequency * Math.sqrt(1 - damping * damping);
    const liftOffset = heldScale - heldTarget;
    const liftB = (heldVelocity + damping * frequency * liftOffset) / damped;
    const liftCos = Math.cos(damped * dt), liftSin = Math.sin(damped * dt);
    heldScale = heldTarget + decayLift * (liftOffset * liftCos + liftB * liftSin);
    heldVelocity = decayLift * ((-damping * frequency * liftOffset + damped * liftB) * liftCos
      + (-damping * frequency * liftB - damped * liftOffset) * liftSin);
    const strain = Math.min(.15, Math.abs(velocity) * .00013);
    paint(1 + strain + heldScale * .09, 1 - strain * .32 + heldScale * .16);
    if (Math.abs(current - target) > .03 || Math.abs(velocity) > .15 || Math.abs(heldTarget - heldScale) > .002 || Math.abs(heldVelocity) > .04) {
      frame = requestAnimationFrame(tick);
    } else {
      current = target; velocity = 0; lastTime = 0; heldScale = heldTarget; heldVelocity = 0;
      dock.removeAttribute('data-settling');
      paint(1 + heldScale * .09, 1 + heldScale * .16);
    }
  }
  function animate() {
    if (reduce.matches) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; velocity = 0; lastTime = 0; current = target; width = targetWidth; heldScale = 0; heldVelocity = 0;
      paint(); return;
    }
    if (!frame && !document.hidden) frame = requestAnimationFrame(tick);
  }
  function measure(snap = false) {
    const rect = dock.getBoundingClientRect();
    measuredRect = {left:rect.left, width:rect.width, height:rect.height};
    dockLeft = rect.left + dock.clientLeft;
    boxes = links.map(link => {
      const box = link.getBoundingClientRect();
      return {x: box.left - rect.left - dock.clientLeft, width: box.width, center: box.left + box.width / 2};
    });
    const geometryIndex = selected;
    target = boxes[geometryIndex].x; targetWidth = boxes[geometryIndex].width;
    width = targetWidth;
    lens.style.setProperty('--lens-width', `${width.toFixed(3)}px`);
    if (snap || !width) { current = target; width = targetWidth; velocity = 0; paint(); }
    else animate();
  }
  function select(index, snap = false) {
    selected = clamp(index, 0, links.length - 1);
    links.forEach((link, i) => {
      if (i === selected && isLink(link)) link.setAttribute('data-active', 'true');
      else link.removeAttribute('data-active');
      if (i === selected && isLink(link)) link.setAttribute('aria-current', new URL(link.href, location.href).hash ? 'location' : 'page');
      else link.removeAttribute('aria-current');
    });
    if (!boxes.length) return;
    target = boxes[selected].x; targetWidth = boxes[selected].width;
    if (snap) { current = target; width = targetWidth; velocity = 0; paint(); }
    else { dock.setAttribute('data-settling', ''); animate(); }
  }
  function nearest(clientX) {
    return boxes.reduce((best, box, index) => Math.abs(clientX - box.center) < Math.abs(clientX - boxes[best].center) ? index : best, 0);
  }
  function releaseCapture(pointerId) {
    if (dock.hasPointerCapture?.(pointerId)) dock.releasePointerCapture(pointerId);
  }
  function cancelGesture() {
    const old = gesture; gesture = null;
    velocity = 0;
    dock.removeAttribute('data-dragging');
    if (old) releaseCapture(old.id);
    select(selected, reduce.matches);
  }
  dock.addEventListener('contextmenu', event => {
    // Keep desktop link menus (including Ctrl-click on macOS) available. Only
    // the touch hold needs suppression to avoid callouts and selected labels.
    if (event.button === 2 || event.ctrlKey || event.pointerType === 'mouse') return;
    event.preventDefault();
    if (gesture && !gesture.dragging) { suppressClickUntil = performance.now() + 900; cancelGesture(); }
  }, {signal});
  dock.addEventListener('selectstart', event => event.preventDefault(), {signal});
  dock.addEventListener('dragstart', event => event.preventDefault(), {signal});
  dock.addEventListener('pointerdown', event => {
    if (event.button !== 0 || !event.isPrimary || event.target.closest('a')?.hasAttribute('download')) return;
    if (navigationTimer) { clearTimeout(navigationTimer); navigationTimer = 0; clearHandoff(); }
    measure();
    gesture = {id: event.pointerId, x: event.clientX, y: event.clientY, started: performance.now(), dragging: false};
    animate();
  }, {signal, passive: true});
  dock.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const dx = event.clientX - gesture.x, dy = event.clientY - gesture.y;
    if (!gesture.dragging) {
      if (Math.abs(dy) > 9 && Math.abs(dy) > Math.abs(dx)) { cancelGesture(); return; }
      if (Math.abs(dx) < 7 || Math.abs(dx) < Math.abs(dy) * 1.15) return;
      gesture.dragging = true;
      dock.setPointerCapture?.(event.pointerId);
      dock.setAttribute('data-dragging', 'true');
    }
    if (event.cancelable) event.preventDefault();
    const first = boxes[0].x, last = boxes.at(-1).x;
    // Once horizontal intent is established, the lens belongs underneath the
    // finger even if the gesture began over an unselected destination.
    const raw = event.clientX - dockLeft - width / 2;
    target = raw < first ? first + (raw - first) * .16 : raw > last ? last + (raw - last) * .16 : raw;
    animate();
  }, {signal, passive: false});
  dock.addEventListener('pointerup', event => {
    if (!gesture || event.pointerId !== gesture.id) return;
    const wasDragging = gesture.dragging;
    const held = performance.now() - gesture.started;
    gesture = null;
    dock.removeAttribute('data-dragging');
    releaseCapture(event.pointerId);
    if (!wasDragging) {
      // A held press can already have settled and stopped its frame loop.
      // Always restart on release, even when no click follows the long hold.
      animate();
      if (held > 550) suppressClickUntil = performance.now() + 450;
      return;
    }
    velocity = clamp(velocity, -750, 750);
    const next = nearest(event.clientX);
    if (isLink(links[next])) select(next);
    else select(selected);
    // Consume only the compatibility click generated by this drag. Dispatch a
    // real anchor click first so existing navigation handlers remain in charge.
    dragActivation = event.isTrusted;
    links[next].click();
    dragActivation = false;
    suppressClickUntil = performance.now() + 450;
  }, {signal});
  dock.addEventListener('click', event => {
    if (performance.now() < suppressClickUntil && event.isTrusted && event.detail > 0) {
      suppressClickUntil = 0;
      event.preventDefault(); event.stopImmediatePropagation(); return;
    }
    const link = event.target.closest('[data-dock-item]');
    if (!link || !isLink(link) || link.hasAttribute('download') || link.getAttribute('target') === '_blank' || event.defaultPrevented || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button > 0) return;
    select(links.indexOf(link));
    const url = new URL(link.href, location.href);
    const currentURL = new URL(location.href);
    // Native cross-document navigation otherwise destroys the selection animation
    // before its first frame. A short, cancellable handoff makes it visible.
    if ((event.isTrusted || dragActivation) && url.origin === location.origin &&
        !samePage(url, currentURL)) {
      event.preventDefault();
      if (navigationTimer) clearTimeout(navigationTimer);
      pendingHref = url.href;
      if (reduce.matches) { clearHandoff(); location.assign(url.href); }
      else navigationTimer = setTimeout(() => {
        navigationTimer = 0;
        saveHandoff();
        location.assign(url.href);
      }, 110);
    }
  }, {signal, capture: true});
  dock.addEventListener('pointercancel', cancelGesture, {signal});
  // A mouse press has no implicit capture. If it leaves the dock before a
  // horizontal drag begins, its release never reaches the dock listener.
  // Clear that held state without activating an unrelated destination.
  addEventListener('pointerup', event => {
    if (gesture && event.pointerId === gesture.id && !dock.contains(event.target)) cancelGesture();
  }, {signal});
  addEventListener('blur', () => { if (gesture) cancelGesture(); }, {signal});
  dock.addEventListener('lostpointercapture', event => {
    // Touch starts with implicit capture on the anchor. Moving capture to the
    // dock emits a bubbling lostpointercapture for that anchor; it is not loss
    // of the dock's newly acquired pointer and must not cancel the drag.
    if (gesture && event.pointerId === gesture.id && !dock.hasPointerCapture?.(gesture.id)) cancelGesture();
  }, {signal});
  // Native Tab/Enter activation and the focus-visible ring provide keyboard
  // navigation. Focus alone never moves the page-selection lens to a different
  // destination, so a focused control cannot look like a second current page.
  const onResize = event => {
    // ResizeObserver delivers an initial notification even without a resize.
    // Snapping that notification would erase a just-restored cross-page spring.
    const rect = dock.getBoundingClientRect();
    const changed = !measuredRect || rect.left !== measuredRect.left || rect.width !== measuredRect.width || rect.height !== measuredRect.height;
    if (!changed && !event?.type) return;
    if (gesture) cancelGesture();
    measure(true);
    observeContrast();
  };
  addEventListener('resize', onResize, {signal, passive: true});
  if ('ResizeObserver' in window) {
    resizeObserver = new ResizeObserver(onResize); resizeObserver.observe(dock);
  }
  const onMotion = () => { cancelGesture(); measure(true); animate(); };
  reduce.addEventListener('change', onMotion, {signal});
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0; lastTime = 0; cancelGesture();
    } else { measure(true); }
  }, {signal});
  // Each tab now names a separate page, including contact. Scrolling inside a
  // document never changes its current-page semantics or runs a section observer.
  measure(true); select(selected, true); restoreHandoff(); observeContrast();
  addEventListener('pagehide', event => {
    // Capture the actual departure position after loading time, rather than the
    // earlier click position, so the next document continues the same movement.
    saveHandoff();
    cancelGesture();
    if (frame) cancelAnimationFrame(frame);
    frame = 0; velocity = 0; lastTime = 0;
    if (navigationTimer) clearTimeout(navigationTimer);
    navigationTimer = 0;
    if (event.persisted) return;
    aborter.abort(); resizeObserver?.disconnect(); contrastObserver?.disconnect();
    if (frame) cancelAnimationFrame(frame);
  }, {signal});
  addEventListener('pageshow', event => {
    if (!event.persisted) return;
    suppressClickUntil = 0;
    heldScale = 0; heldVelocity = 0; velocity = 0;
    measure(true); select(selected, true);
  }, {signal});
})();

/* Local appearance preferences; no network requests or visitor tracking. */
(() => {
  'use strict';
  const root = document.documentElement;
  const slider = document.querySelector('#glass-clarity');
  const output = document.querySelector('#glass-clarity-value');
  const motion = document.querySelector('#glass-motion');
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const key = 'portfolio-glass-appearance-v1';
  let settings = { clarity: 82, motion: !reduced.matches };
  try {
    const saved = JSON.parse(localStorage.getItem(key));
    if (saved && Number.isFinite(saved.clarity)) settings.clarity = Math.max(0, Math.min(100, saved.clarity));
    if (saved && typeof saved.motion === 'boolean') settings.motion = saved.motion;
  } catch { /* Storage may be unavailable in a private browsing session. */ }
  function apply() {
    root.style.setProperty('--glass-alpha', String(.72 - settings.clarity * .0066));
    root.dataset.sceneMotion = settings.motion && !reduced.matches ? 'on' : 'off';
    if (slider) slider.value = settings.clarity;
    if (output) output.value = `${settings.clarity}%`;
    if (motion) {
      motion.checked = settings.motion && !reduced.matches;
      motion.disabled = reduced.matches;
    }
  }
  function save() {
    apply();
    try { localStorage.setItem(key, JSON.stringify(settings)); } catch { /* Preferences still work for this visit. */ }
  }
  slider?.addEventListener('input', () => { settings.clarity = Number(slider.value); save(); });
  motion?.addEventListener('change', () => { settings.motion = motion.checked; save(); });
  reduced.addEventListener('change', apply);
  apply();
  const preferences = document.querySelector('.glass-preferences');
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && preferences?.open) {
      preferences.open = false;
      preferences.querySelector('summary').focus();
    }
  });
  document.addEventListener('click', event => {
    if (preferences?.open && !preferences.contains(event.target)) preferences.open = false;
  });
  // Only schedule a frame after a pointer event; never run a continuous JS loop.
  if (!matchMedia('(hover:hover) and (pointer:fine)').matches) return;
  let frame = 0;
  let point = null;
  document.addEventListener('pointermove', event => {
    if (root.dataset.sceneMotion !== 'on' || document.hidden) return;
    point = { x: event.clientX, y: event.clientY, target: event.target };
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      if (!point || root.dataset.sceneMotion !== 'on') return;
      root.style.setProperty('--scene-x', `${(point.x / innerWidth - .5) * 18}px`);
      root.style.setProperty('--scene-y', `${(point.y / innerHeight - .5) * 12}px`);
      const card = point.target.closest?.('.capability-card');
      if (!card) return;
      const rect = card.getBoundingClientRect();
      card.style.setProperty('--light-x', `${point.x - rect.left}px`);
      card.style.setProperty('--light-y', `${point.y - rect.top}px`);
    });
  }, { passive: true });
})();
