/* 我只在交互发生时更新材质，让战斗循环专注于草坪。 */
(() => {
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const nav=document.querySelector('.gp-nav'),menu=document.querySelector('.gp-menu');
 const isEnglish=()=>document.documentElement.dataset.language==='en';
 function closeMenu(focus=false){if(!nav||!menu)return;nav.classList.remove('gp-open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label',isEnglish()?'Open navigation':'展开导航');if(focus)menu.focus();}
 if(nav&&menu){
  menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';nav.classList.toggle('gp-open',open);menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',isEnglish()?(open?'Close navigation':'Open navigation'):(open?'收起导航':'展开导航'));});
  nav.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>closeMenu()));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('gp-open')){e.preventDefault();e.stopImmediatePropagation();closeMenu(true);}},true);
  document.addEventListener('pointerdown',e=>{if(nav.classList.contains('gp-open')&&!nav.contains(e.target))closeMenu();},{passive:true});
  matchMedia('(min-width:761px)').addEventListener('change',e=>{if(e.matches)closeMenu();});
 }
 const targets='button:not(:disabled),a.button,a.pill,.gp-nav nav a,.book-tabs a';
 function wave(target,x,y){
  if(reduced.matches)return;
  const box=target.getBoundingClientRect();if(!box.width||!box.height)return;
  const node=document.createElement('i');node.className='liquid-wave';node.setAttribute('aria-hidden','true');
  node.style.setProperty('--wave-size',Math.max(box.width,box.height)*1.3+'px');node.style.setProperty('--wave-x',x-box.left+'px');node.style.setProperty('--wave-y',y-box.top+'px');
  target.querySelectorAll('.liquid-wave').forEach(n=>n.remove());target.append(node);
  node.addEventListener('animationend',()=>node.remove(),{once:true});setTimeout(()=>node.remove(),1100);
 }
 document.addEventListener('pointerdown',e=>{const target=e.target.closest(targets);if(target&&e.button===0)wave(target,e.clientX,e.clientY);},{passive:true});
 document.addEventListener('keydown',e=>{if(!['Enter',' '].includes(e.key)||e.repeat)return;const target=e.target.closest(targets);if(target){const r=target.getBoundingClientRect();wave(target,r.left+r.width/2,r.top+r.height/2);}});
 let pointerFrame=0,pointerTarget=null,point=null;
 document.addEventListener('pointermove',e=>{if(reduced.matches||e.pointerType!=='mouse')return;const target=e.target.closest(targets);if(!target)return;point={x:e.clientX,y:e.clientY};pointerTarget=target;if(pointerFrame)return;pointerFrame=requestAnimationFrame(()=>{pointerFrame=0;if(!pointerTarget?.isConnected)return;const b=pointerTarget.getBoundingClientRect();pointerTarget.classList.add('gp-material');pointerTarget.style.setProperty('--light-x',(point.x-b.left)+'px');pointerTarget.style.setProperty('--light-y',(point.y-b.top)+'px');});},{passive:true});
 let scrollFrame=0;function scrollState(){document.body.classList.toggle('has-scrolled',scrollY>20);}scrollState();
 addEventListener('scroll',()=>{if(!scrollFrame)scrollFrame=requestAnimationFrame(()=>{scrollFrame=0;scrollState();});},{passive:true});
 // 标题卡保持原有游戏按钮与焦点，不复制或接管游戏状态。
 const overlay=document.getElementById('overlay');
 function decorateTitle(){
  const card=overlay?.querySelector('.overlay-card');if(!card||!card.querySelector('h1')||card.classList.contains('gp-title'))return;
  card.classList.add('gp-title');
  const mark=document.createElement('img');mark.className='gp-title-mark';mark.width=72;mark.height=72;mark.alt='';mark.src=document.querySelector('.brand img')?.getAttribute('src')||'favicon.svg';card.prepend(mark);
  const growth=document.createElement('div');growth.className='gp-growth';growth.setAttribute('aria-label',isEnglish()?'Three growth stages':'三个生长阶段');
  [['幼芽','Sprout'],['成株','Mature'],['开花','Bloom']].forEach(([zh,en])=>{const item=document.createElement('span');const dot=document.createElement('i');dot.setAttribute('aria-hidden','true');item.append(dot);const z=document.createElement('span');z.className='zh';z.textContent=zh;const n=document.createElement('span');n.className='en';n.lang='en';n.textContent=en;item.append(z,n);growth.append(item);});
  const action=card.querySelector('[data-action="resume"]');if(action)card.insertBefore(growth,action);
 }
 if(overlay){new MutationObserver(decorateTitle).observe(overlay,{childList:true});decorateTitle();}
 if(!reduced.matches&&'IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>entries.forEach(({target,isIntersecting})=>{if(isIntersecting){target.classList.add('gp-enter');observer.unobserve(target);}}),{threshold:.08});document.querySelectorAll('.gp-feature,.guide-step,.gp-info-card,.gp-world,.change-entry').forEach(el=>observer.observe(el));}
 // 页面阅读辅助只作用于资料区，不接管战斗、存档和解锁状态。
 const pageName=location.pathname.split('/').pop()||'index.html';
 document.querySelectorAll('.gp-footer nav a').forEach(a=>{if(a.getAttribute('href')===pageName)a.setAttribute('aria-current','page');});
 const achievements=document.getElementById('achievement-grid');
 function nameProgress(){achievements?.querySelectorAll('.achievement').forEach(card=>{const bar=card.querySelector('progress'),title=card.querySelector('h3');if(bar&&title)bar.setAttribute('aria-label',title.textContent.trim());});}
 if(achievements){new MutationObserver(nameProgress).observe(achievements,{childList:true,subtree:true});nameProgress();}
 document.addEventListener('gardenlanguage',()=>closeMenu());
})();

/* Live light field. The generated 1,228,800 samples supply height and normals;
 * time, pointer input and game actions change their refraction every frame. */
(() => {
  'use strict';
  if (document.querySelector('[data-optical-scene]')) return;
  const source = new URL('assets/glass-flow.0decc9aa5b10.png', document.currentScript.src).href;
  const canvas = document.createElement('canvas');
  canvas.className = 'optical-scene';
  canvas.dataset.opticalScene = 'loading';
  canvas.setAttribute('aria-hidden', 'true');
  (document.querySelector('.ambient-field') || document.body).prepend(canvas);
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const contrast = matchMedia('(prefers-contrast: more)');
  const transparency = matchMedia('(prefers-reduced-transparency: reduce)');
  const gl = canvas.getContext('webgl', {alpha: false, antialias: false,
    depth: false, stencil: false, powerPreference: 'low-power'});
  if (!gl) { canvas.remove(); return; } // The authored CSS field stays visible.
  const vertex = 'attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}';
  const fragment = `precision mediump float;
    varying vec2 uv; uniform sampler2D field; uniform float clock;
    uniform vec2 pointer; uniform vec3 pulse; uniform float aspect;
    void main(){
      vec2 q=vec2(uv.x,1.-uv.y);
      vec2 drift=vec2(sin(clock*.18),cos(clock*.13))*.055;
      vec3 sampleA=texture2D(field,clamp(q*.88+drift+.06,.001,.999)).rgb;
      vec2 normal=(sampleA.gb-.5)*1.7;
      float age=max(0.,clock-pulse.z);
      float radius=length((q-pulse.xy)*vec2(aspect,1.));
      float ripple=sin(radius*30.-age*5.)*exp(-radius*2.8-age*.9)*step(0.,pulse.z);
      vec2 refracted=q+normal*.07+(pointer-.5)*.025+drift*.35+ripple*.015;
      vec3 sampleB=texture2D(field,clamp(refracted,.001,.999)).rgb;
      float lens=pow(max(0.,1.-abs(sampleB.r-.47)*2.1),3.);
      float glint=pow(max(0.,dot(normal,normalize(vec2(.6,-.8)))+.3),2.);
      float wash=.5+.5*sin(refracted.x*4.+refracted.y*3.+clock*.14);
      vec3 sky=vec3(.76,.87,.97),mint=vec3(.72,.90,.85);
      vec3 color=mix(sky,mint,clamp(refracted.y*.7+wash*.25,0.,1.));
      color=mix(color,vec3(.98,.99,1.),.28+lens*.26+glint*.13);
      color+=ripple*.035;
      gl_FragColor=vec4(clamp(color,0.,1.),1.);
    }`;
  function shader(type, text) {
    const result = gl.createShader(type); gl.shaderSource(result, text); gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) throw Error('Optical shader compilation failed');
    return result;
  }
  let program, texture, frame = 0, last = 0, elapsed = 0, ready = false, lost = false;
  const pointer = [.5, .5], pulse = [.5, .5, -1];
  function stopped() { return document.hidden || contrast.matches || transparency.matches || lost; }
  function resize() {
    // This is a low resolution background, independent of the gameplay canvas.
    const scale = Math.min(1, 960 / innerWidth, 720 / innerHeight);
    canvas.width = Math.max(1, Math.round(innerWidth * scale));
    canvas.height = Math.max(1, Math.round(innerHeight * scale));
  }
  function draw(now = 0) {
    frame = 0;
    if (!ready || stopped()) { last = 0; return; }
    if (last && now - last < 48 && !motion.matches) { frame = requestAnimationFrame(draw); return; }
    if (last && !motion.matches) elapsed += Math.min(.1, (now - last) / 1000);
    last = now;
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.useProgram(program);
    gl.uniform1f(gl.getUniformLocation(program, 'clock'), elapsed);
    gl.uniform1f(gl.getUniformLocation(program, 'aspect'), canvas.width / canvas.height);
    gl.uniform2fv(gl.getUniformLocation(program, 'pointer'), pointer);
    gl.uniform3fv(gl.getUniformLocation(program, 'pulse'), pulse);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    canvas.dataset.opticalFrames = String(Number(canvas.dataset.opticalFrames || 0) + 1);
    if (!motion.matches) frame = requestAnimationFrame(draw);
  }
  function resume() {
    if (frame) cancelAnimationFrame(frame);
    frame = 0; last = 0;
    canvas.dataset.opticalMotion = motion.matches ? 'still' : 'live';
    if (ready && !stopped()) frame = requestAnimationFrame(draw);
  }
  const image = new Image();
  function initialize() {
    try {
      program = gl.createProgram();
      gl.attachShader(program, shader(gl.VERTEX_SHADER, vertex));
      gl.attachShader(program, shader(gl.FRAGMENT_SHADER, fragment)); gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('Optical shader linking failed');
      gl.useProgram(program);
      const buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]), gl.STATIC_DRAW);
      const attribute = gl.getAttribLocation(program, 'a');
      gl.enableVertexAttribArray(attribute); gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
      texture = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
      gl.uniform1i(gl.getUniformLocation(program, 'field'), 0);
      canvas.dataset.opticalScene = 'webgl';
      canvas.dataset.opticalSamples = String(image.width * image.height);
      ready = true; resize(); resume();
    } catch { ready = false; canvas.hidden = true; }
  }
  image.onload = initialize;
  image.onerror = () => canvas.remove();
  image.src = source;
  addEventListener('resize', () => { resize(); resume(); }, {passive: true});
  document.addEventListener('visibilitychange', resume);
  for (const preference of [motion, contrast, transparency]) preference.addEventListener('change', resume);
  document.addEventListener('pointermove', event => {
    if (motion.matches || stopped()) return;
    pointer[0] = event.clientX / innerWidth; pointer[1] = event.clientY / innerHeight;
  }, {passive: true});
  function ripple(x, y) {
    if (motion.matches || stopped()) return;
    pulse[0] = x; pulse[1] = y; pulse[2] = elapsed;
    canvas.dataset.opticalInputs = String(Number(canvas.dataset.opticalInputs || 0) + 1);
  }
  document.addEventListener('pointerdown', event => ripple(event.clientX / innerWidth, event.clientY / innerHeight), {passive: true});
  addEventListener('gardenoptics', event => ripple(event.detail?.x ?? .5, event.detail?.y ?? .5));
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); lost = true; resume(); });
  canvas.addEventListener('webglcontextrestored', () => { lost = false; initialize(); });
})();
