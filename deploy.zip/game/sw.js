'use strict';
const PREFIX='sprout-patrol:'+self.registration.scope+':';
const CACHE=PREFIX+'7.0.0-37062133636f';
const CORE=["LICENSE.txt","about.en.html","about.html","assets/guide/step-1.f24d84af1948.svg","assets/guide/step-2.8360251159cb.svg","assets/guide/step-3.b2659aeb7d47.svg","assets/guide/step-4.ba1b57d25aa0.svg","assets/guide/step-5.b4d598943564.svg","assets/guide/step-6.ba3bd587cd8b.svg","assets/guide/step-7.2c19fb0e055c.svg","assets/guide/step-8.a49c818721a2.svg","assets/portraits/enemy-bat.64b6ae1e156a.png","assets/portraits/enemy-boss.5301b105ea26.png","assets/portraits/enemy-boss_dusk.bba8721d03f2.png","assets/portraits/enemy-boss_morning.785a7799534d.png","assets/portraits/enemy-boss_noon.4f87d01f8b0f.png","assets/portraits/enemy-brute.707b98cdba82.png","assets/portraits/enemy-burrow.4898d088730a.png","assets/portraits/enemy-dash.824bca09dd22.png","assets/portraits/enemy-healer.d328d206c005.png","assets/portraits/enemy-leap.0daba34cd5ee.png","assets/portraits/enemy-moss.c0617ce1c4e3.png","assets/portraits/enemy-push.1fed49498527.png","assets/portraits/enemy-summoner.53cdeb2b829f.png","assets/portraits/enemy-tank.93dec04e1d26.png","assets/portraits/enemy-wisp.b3b8628b9a61.png","assets/portraits/plant-boom-a.70b772a6a4c5.png","assets/portraits/plant-boom-b.af369b8ccb34.png","assets/portraits/plant-boom.8d6d1b6be2a8.png","assets/portraits/plant-ember-a.c95d500be1d7.png","assets/portraits/plant-ember-b.89d3139e1045.png","assets/portraits/plant-ember.55895172be36.png","assets/portraits/plant-frost-a.4b2921a93bd5.png","assets/portraits/plant-frost-b.ef003820bd30.png","assets/portraits/plant-frost.c0b7c3d74257.png","assets/portraits/plant-healer-a.e86b1efb1a1d.png","assets/portraits/plant-healer-b.370c2339bf57.png","assets/portraits/plant-healer.3dce2aa3ab16.png","assets/portraits/plant-ironwall-a.f38425f35875.png","assets/portraits/plant-ironwall-b.0b0219d0b1db.png","assets/portraits/plant-ironwall.c0d54840e717.png","assets/portraits/plant-lantern-a.9c7418480756.png","assets/portraits/plant-lantern-b.6e0e60fca9ca.png","assets/portraits/plant-lantern.59584efad23b.png","assets/portraits/plant-lobber-a.0360923b8e93.png","assets/portraits/plant-lobber-b.707f85991292.png","assets/portraits/plant-lobber.5dcc8936e7f9.png","assets/portraits/plant-mine-a.5431b07c5aa0.png","assets/portraits/plant-mine-b.da93a3c0347d.png","assets/portraits/plant-mine.6cece837aaf9.png","assets/portraits/plant-mint-a.c473e80ceefd.png","assets/portraits/plant-mint-b.3e01be606978.png","assets/portraits/plant-mint.8b8f9ff93cb3.png","assets/portraits/plant-moonbud-a.3550661e86f9.png","assets/portraits/plant-moonbud-b.f2070bb34e4c.png","assets/portraits/plant-moonbud.663fc2f13102.png","assets/portraits/plant-root-a.9bd648c82fa7.png","assets/portraits/plant-root-b.1d37590c6fab.png","assets/portraits/plant-root.9e3e3faba342.png","assets/portraits/plant-seed-a.9d2019ae5c21.png","assets/portraits/plant-seed-b.f08bddcbf94d.png","assets/portraits/plant-seed.16b74bd6a43b.png","assets/portraits/plant-skyreed-a.72bc5e8533b7.png","assets/portraits/plant-skyreed-b.ee8a5e80bb7a.png","assets/portraits/plant-skyreed.97635a8113d8.png","assets/portraits/plant-storm-a.65555e250b43.png","assets/portraits/plant-storm-b.6ca45c0ff2c1.png","assets/portraits/plant-storm.e8cd425c767b.png","assets/portraits/plant-sunbud-a.803bb75488f6.png","assets/portraits/plant-sunbud-b.3640ae3fc024.png","assets/portraits/plant-sunbud.81bfc13a2905.png","assets/portraits/plant-thorn-a.5049c9b85c81.png","assets/portraits/plant-thorn-b.4feb7e10dc9d.png","assets/portraits/plant-thorn.db694a15267e.png","assets/portraits/plant-twinbud-a.3f4f7300ca4a.png","assets/portraits/plant-twinbud-b.0da25183bb5b.png","assets/portraits/plant-twinbud.9dd27db66bfd.png","assets/portraits/plant-twinseed-a.224cb0e25196.png","assets/portraits/plant-twinseed-b.d83e232762e7.png","assets/portraits/plant-twinseed.a22368583555.png","assets/portraits/plant-wall-a.41d555242ecb.png","assets/portraits/plant-wall-b.23657ad8752a.png","assets/portraits/plant-wall.84a33e8e7aab.png","assets/portraits/plant-wind-a.67bcf0233b9e.png","assets/portraits/plant-wind-b.adf5a6b50196.png","assets/portraits/plant-wind.87aa94c30ace.png","assets/pwa-192.e734a8c3a2eb.png","assets/pwa-512.f04b52d8f380.png","assets/trailer-poster.243761b8a99a.jpg","challenges.en.html","challenges.html","cloud.en.html","cloud.html","codex.en.html","codex.html","favicon.99075eb591aa.svg","garden-access.563646507a70.js","garden-app.725cdf534f0c.js","garden-art.3c4a26d878c5.js","garden-audio.30e4931b0292.js","garden-book.3849b4e51957.js","garden-boot.4069a48eb8ac.js","garden-copy.be7a7375136a.js","garden-data.e6199fb5fb80.js","garden-engine.9be0b5e776d2.js","garden-ghost.2141a2e007be.js","garden-home.1f1cc12c6ac8.js","garden-journal.f427e1b8e577.js","garden-legacy6.7624ce44d106.js","garden-pwa.b8bc2f87032b.js","garden-replay-page.b4d3c25b6dc5.js","garden-shared.1094164df8e6.js","garden.8d5f72b9b664.css","guide.en.html","guide.html","home.en.html","home.html","index.en.html","index.html","journal.en.html","journal.html","manifest.webmanifest","presentation.bc918ccaae61.css","presentation.f48a14f4c62e.js","press.en.html","press.html","privacy.en.html","privacy.html","replay.en.html","replay.html","trailer.en.html","trailer.html","updates.en.html","updates.html"];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE.map(path=>new URL(path,self.registration.scope).href))));});
// Keep one previous generation for tabs still loading its content-addressed assets.
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>{
  const previous=keys.filter(key=>key.startsWith(PREFIX)&&key!==CACHE);
  return Promise.all(previous.slice(0,-1).map(key=>caches.delete(key)));
}).then(()=>self.clients.claim()));});
self.addEventListener('message',event=>{if(event.data?.type==='SKIP_WAITING')self.skipWaiting();});
// Content-addressed assets are immutable. Pages and the install manifest stay fresh.
self.addEventListener('fetch',event=>{
  const request=event.request,url=new URL(request.url);
  if(request.method!=='GET'||url.origin!==self.location.origin||!url.href.startsWith(self.registration.scope))return;
  const fresh=request.mode==='navigate'||url.pathname.endsWith('/manifest.webmanifest');
  event.respondWith(caches.open(CACHE).then(async cache=>{
    let saved=await cache.match(request,{ignoreSearch:true})||
      (request.mode==='navigate'&&url.pathname.endsWith('/')?
        await cache.match(new URL('index.html',url).href,{ignoreSearch:true}):null);
    // Only immutable hashed assets may fall back to an earlier application cache.
    // Never serve an old document or manifest after a successful upgrade.
    if(!saved&&!fresh&&/\.[a-f0-9]{8,}\.[^/]+$/i.test(url.pathname)){
      const previous=(await caches.keys()).filter(key=>key.startsWith(PREFIX)&&key!==CACHE).slice(-1);
      if(previous.length)saved=await (await caches.open(previous[0])).match(request,{ignoreSearch:true});
    }
    if(!fresh&&saved)return saved;
    try{
      const response=await fetch(request);
      if(response.ok){
        // Extend this event so writes finish even when the page immediately closes.
        event.waitUntil(cache.put(request,response.clone()).catch(()=>{}));
        return response;
      }
      return saved||response;
    }catch{
      return saved||Response.error();
    }
  }));
});
