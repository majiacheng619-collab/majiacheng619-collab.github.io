/* 我只在交互发生时更新材质，让战斗循环专注于草坪。 */
(() => {
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const nav=document.querySelector('.gp-nav'),menu=document.querySelector('.gp-menu');
 const isEnglish=()=>document.documentElement.dataset.language==='en';
 function closeMenu(focus=false){if(!nav||!menu)return;nav.classList.remove('gp-open');menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label',isEnglish()?'Open navigation':'展开导航');if(focus)menu.focus();}
 if(nav&&menu){
  menu.addEventListener('click',()=>{const open=menu.getAttribute('aria-expanded')!=='true';nav.classList.toggle('gp-open',open);menu.setAttribute('aria-expanded',String(open));menu.setAttribute('aria-label',isEnglish()?(open?'Close navigation':'Open navigation'):(open?'收起导航':'展开导航'));});
  nav.querySelectorAll('nav a').forEach(a=>a.addEventListener('click',()=>closeMenu()));
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&nav.classList.contains('gp-open')){e.preventDefault();e.stopImmediatePropagation();closeMenu(true);}},true);
  document.addEventListener('pointerdown',e=>{if(nav.classList.contains('gp-open')&&!nav.contains(e.target))closeMenu();},{passive:true});
  matchMedia('(min-width:761px)').addEventListener('change',e=>{if(e.matches)closeMenu();});
 }
 const targets='button:not(:disabled),a.button,a.pill,.gp-nav nav a,.book-tabs a';
 function wave(target,x,y){
  if(reduced.matches)return;
  const box=target.getBoundingClientRect();if(!box.width||!box.height)return;
  const node=document.createElement('i');node.className='liquid-wave';node.setAttribute('aria-hidden','true');
  node.style.setProperty('--wave-size',Math.max(box.width,box.height)*1.3+'px');node.style.setProperty('--wave-x',x-box.left+'px');node.style.setProperty('--wave-y',y-box.top+'px');
  target.querySelectorAll('.liquid-wave').forEach(n=>n.remove());target.append(node);
  node.addEventListener('animationend',()=>node.remove(),{once:true});setTimeout(()=>node.remove(),1100);
 }
 document.addEventListener('pointerdown',e=>{const target=e.target.closest(targets);if(target&&e.button===0)wave(target,e.clientX,e.clientY);},{passive:true});
 document.addEventListener('keydown',e=>{if(!['Enter',' '].includes(e.key)||e.repeat)return;const target=e.target.closest(targets);if(target){const r=target.getBoundingClientRect();wave(target,r.left+r.width/2,r.top+r.height/2);}});
 let pointerFrame=0,pointerTarget=null,point=null;
 document.addEventListener('pointermove',e=>{if(reduced.matches||e.pointerType!=='mouse')return;const target=e.target.closest(targets);if(!target)return;point={x:e.clientX,y:e.clientY};pointerTarget=target;if(pointerFrame)return;pointerFrame=requestAnimationFrame(()=>{pointerFrame=0;if(!pointerTarget?.isConnected)return;const b=pointerTarget.getBoundingClientRect();pointerTarget.classList.add('gp-material');pointerTarget.style.setProperty('--light-x',(point.x-b.left)+'px');pointerTarget.style.setProperty('--light-y',(point.y-b.top)+'px');});},{passive:true});
 let scrollFrame=0;function scrollState(){document.body.classList.toggle('has-scrolled',scrollY>20);}scrollState();
 addEventListener('scroll',()=>{if(!scrollFrame)scrollFrame=requestAnimationFrame(()=>{scrollFrame=0;scrollState();});},{passive:true});
 // 标题卡保持原有游戏按钮与焦点，不复制或接管游戏状态。
 const overlay=document.getElementById('overlay');
 function decorateTitle(){
  const card=overlay?.querySelector('.overlay-card');if(!card||!card.querySelector('h1')||card.classList.contains('gp-title'))return;
  card.classList.add('gp-title');
  const mark=document.createElement('img');mark.className='gp-title-mark';mark.width=72;mark.height=72;mark.alt='';mark.src=document.querySelector('.brand img')?.getAttribute('src')||'favicon.svg';card.prepend(mark);
  const growth=document.createElement('div');growth.className='gp-growth';growth.setAttribute('aria-label',isEnglish()?'Three growth stages':'三个生长阶段');
  [['幼芽','Sprout'],['成株','Mature'],['开花','Bloom']].forEach(([zh,en])=>{const item=document.createElement('span');const dot=document.createElement('i');dot.setAttribute('aria-hidden','true');item.append(dot);const z=document.createElement('span');z.className='zh';z.textContent=zh;const n=document.createElement('span');n.className='en';n.lang='en';n.textContent=en;item.append(z,n);growth.append(item);});
  const action=card.querySelector('[data-action="resume"]');if(action)card.insertBefore(growth,action);
 }
 if(overlay){new MutationObserver(decorateTitle).observe(overlay,{childList:true});decorateTitle();}
 if(!reduced.matches&&'IntersectionObserver'in window){const observer=new IntersectionObserver(entries=>entries.forEach(({target,isIntersecting})=>{if(isIntersecting){target.classList.add('gp-enter');observer.unobserve(target);}}),{threshold:.08});document.querySelectorAll('.gp-feature,.guide-step,.gp-info-card,.gp-world,.change-entry').forEach(el=>observer.observe(el));}
 // 页面阅读辅助只作用于资料区，不接管战斗、存档和解锁状态。
 const pageName=location.pathname.split('/').pop()||'index.html';
 document.querySelectorAll('.gp-footer nav a').forEach(a=>{if(a.getAttribute('href')===pageName)a.setAttribute('aria-current','page');});
 const achievements=document.getElementById('achievement-grid');
 function nameProgress(){achievements?.querySelectorAll('.achievement').forEach(card=>{const bar=card.querySelector('progress'),title=card.querySelector('h3');if(bar&&title)bar.setAttribute('aria-label',title.textContent.trim());});}
 if(achievements){new MutationObserver(nameProgress).observe(achievements,{childList:true,subtree:true});nameProgress();}
 document.addEventListener('gardenlanguage',()=>closeMenu());
})();

/* Live light field. The generated 1,228,800 samples supply height and normals;
 * time, pointer input and game actions change their refraction every frame. */
(() => {
  'use strict';
  if (document.querySelector('[data-optical-scene]')) return;
  const water = document.createElement('div');
  water.className = 'water-events';
  water.setAttribute('aria-hidden', 'true');
  // Each event has an actual falling lens followed by two expanding surface rings.
  for (const [x, y, delay] of [[16,28,0],[77,52,-1.05],[34,78,-2.1],[87,18,-3.15]]) {
    const event = document.createElement('span');
    event.className = 'water-event';
    event.style.cssText = `--water-x:${x}%;--water-y:${y}%;--water-delay:${delay}s`;
    event.innerHTML = '<i class="water-drop"></i><i class="water-ring"></i><i class="water-ring water-ring-echo"></i>';
    water.append(event);
  }
  (document.querySelector('.ambient-field') || document.body).append(water);
  const source = new URL('assets/glass-flow.0decc9aa5b10.png', document.currentScript.src).href;
  const canvas = document.createElement('canvas');
  canvas.className = 'optical-scene';
  canvas.dataset.opticalScene = 'loading';
  canvas.setAttribute('aria-hidden', 'true');
  (document.querySelector('.ambient-field') || document.body).prepend(canvas);
  const gameplay = !!document.querySelector('#garden');
  const arenaOverlay = gameplay ? document.querySelector('#overlay') : null;
  let battleActive = !!arenaOverlay?.hidden;
  const motion = matchMedia('(prefers-reduced-motion: reduce)');
  const contrast = matchMedia('(prefers-contrast: more)');
  const transparency = matchMedia('(prefers-reduced-transparency: reduce)');
  const gl = canvas.getContext('webgl', {alpha: false, antialias: false,
    depth: false, stencil: false, powerPreference: 'high-performance'});
  if (!gl) { canvas.remove(); return; } // The authored CSS field stays visible.
  const rendererInfo = gl.getExtension('WEBGL_debug_renderer_info');
  const software = !!rendererInfo && /SwiftShader|llvmpipe|software/i.test(gl.getParameter(rendererInfo.UNMASKED_RENDERER_WEBGL));
  const vertex = 'attribute vec2 a; varying vec2 uv; void main(){uv=a*.5+.5;gl_Position=vec4(a,0.,1.);}';
  // Analytic waves animate the sampled surface; highlights follow its normals.
  // Everything lives behind the page, so refraction never distorts readable type.
  const fragment = `precision highp float;
    varying vec2 uv; uniform sampler2D field; uniform float clock;
    uniform vec2 pointer; uniform vec3 pulses[4]; uniform float aspect; uniform float pressure;
    // An environment with real tonal structure makes refraction visible without
    // adding a blue tint to every pane. Broad ribbons carry light through water.
    vec3 waterColor(vec2 q){
      float bend=q.x*.72+q.y*.38+.13*sin(q.y*3.8-clock*.24);
      float ribbon=sin(bend*8.6-clock*.20);
      float seam=exp(-pow((ribbon-.42)*9.,2.));
      float shadow=exp(-pow((ribbon-.13)*4.,2.));
      vec3 c=mix(vec3(.88,.92,.95),vec3(.96,.97,.95),smoothstep(0.,1.,q.y));
      c-=shadow*vec3(.075,.065,.047);
      c+=seam*vec3(.065,.059,.044);
      vec2 pool=q-vec2(.83+.08*sin(clock*.17),.72);
      c=mix(c,vec3(.76,.85,.88),exp(-dot(pool,pool)*5.)*.32);
      return c;
    }
    float surface(vec2 p){
      return sin(p.x*4.8+p.y*3.2-clock*.47)*.40
        +sin(p.x*-2.7+p.y*7.1+clock*.38)*.23
        +sin(p.x*8.2-p.y*2.4+sin(p.y*3.-clock*.31))*.08;
    }
    // A wave packet has a finite front and a trailing wake, rather than a
    // CSS outline expanding independently from the refracted environment.
    vec2 waveSlope(vec2 delta,float age){
      float radius=length(delta),front=radius-age*.30;
      float envelope=exp(-front*front*180.-age*.85)*smoothstep(0.,.12,age);
      return delta/max(radius,.002)*cos(front*72.)*envelope*1.9;
    }
    void main(){
      vec2 q=vec2(uv.x,1.-uv.y), metric=vec2(aspect,1.);
      vec2 p=q*metric+(pointer-.5)*.028;
      float h=surface(p);
      vec2 slope=vec2(surface(p+vec2(.003,0.))-h,surface(p+vec2(0.,.003))-h)/.003;
      for(int i=0;i<4;i++){
        if(pulses[i].z>=0.){
          float age=max(0.,clock-pulses[i].z);
          slope+=waveSlope((q-pulses[i].xy)*metric,age)*1.45;
        }
      }
      // Automatic droplets share one clock with their impact waves. They land
      // in the same coordinate system; refraction continues into the wake.
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*2.17,6.5)-1.05;
        vec2 center=vec2(.17+id*.32,.25+mod(id*.29,.6));
        if(age>=0.) slope+=waveSlope((q-center)*metric,age);
      }
      vec2 contact=(q-pointer)*metric;
      slope+=contact*exp(-dot(contact,contact)*42.)*pressure*18.;
      vec2 drift=vec2(sin(clock*.16),cos(clock*.13))*.035;
      vec3 optical=texture2D(field,clamp(q*.88+.06+drift,.001,.999)).rgb;
      vec3 normal=normalize(vec3(-slope*.18+(optical.gb-.5)*.045,1.));
      vec2 refracted=q+normal.xy*.15/metric;
      vec3 color=waterColor(refracted);
      vec3 key=normalize(vec3(-.48,-.62,1.));
      float light=pow(max(dot(normal,key),0.),42.);
      float caustic=pow(.5+.5*sin(h*6.+optical.r*.6),22.);
      color+=light*.14+caustic*.065;
      // Three shallow, noncircular lenses have thickness, dispersion and a
      // grazing reflection. Their centers remain transparent to the water.
      for(int i=0;i<3;i++){
        float id=float(i),r=.12+id*.045;
        vec2 center=vec2(.14+id*.35+sin(clock*(.16-id*.025)+id*3.)*.065,
                         .20+id*.27+cos(clock*.14+id*2.)*.065);
        vec2 local=(q-center)*metric/vec2(r*1.35,r);
        float angle=atan(local.y,local.x);
        float d=length(local)/(1.+.055*sin(angle*3.+clock*.22+id));
        float mask=1.-smoothstep(.985,1.015,d);
        float curve=sqrt(max(.001,1.-min(d*d,1.)));
        vec2 bend=local*r*(.18+.38*curve)/metric;
        vec3 lens=waterColor(refracted+bend);
        float rim=pow(smoothstep(.63,1.,d),5.);
        lens.r=waterColor(refracted+bend*(1.+rim*.055)).r;
        lens.b=waterColor(refracted+bend*(1.-rim*.055)).b;
        vec3 ln=normalize(vec3(local*.82,curve));
        float highlight=pow(max(dot(ln,key),0.),64.);
        float fresnel=pow(1.-curve,4.);
        lens=mix(lens,vec3(.99,1.,1.),fresnel*.36)+highlight*.34;
        color=mix(color,lens,mask);
        float edge=exp(-pow((d-.994)*145.,2.));
        float direction=dot(normalize(local+vec2(.001)),normalize(vec2(-.5,-.8)));
        color+=edge*(.035+.075*direction);
        color-=exp(-pow((d-1.025)*48.,2.))*.028;
      }
      // A falling bead shrinks into its impact; no decorative overlay covers text.
      for(int i=0;i<3;i++){
        float id=float(i),age=mod(clock+id*2.17,6.5)-1.05;
        if(age<0.){
          float fall=clamp(age+1.05,0.,1.);
          vec2 center=vec2(.17+id*.32,.25+mod(id*.29,.6)-.26*(1.-fall*fall));
          vec2 local=(q-center)*metric/vec2(.012,.021-.007*fall);
          float d=length(local),mask=1.-smoothstep(.94,1.04,d);
          vec3 bead=waterColor(q+local*.035/metric);
          bead+=pow(max(dot(normalize(vec3(local,sqrt(max(.001,1.-d*d)))),key),0.),24.)*.4;
          color=mix(color,bead,mask*smoothstep(0.,.22,fall));
        }
      }
      gl_FragColor=vec4(clamp(color,0.,1.),1.);
    }`;
  function shader(type, text) {
    const result = gl.createShader(type);
    if (type === gl.FRAGMENT_SHADER && !gl.getShaderPrecisionFormat(gl.FRAGMENT_SHADER, gl.HIGH_FLOAT)?.precision) text = text.replace('precision highp float;', 'precision mediump float;');
    gl.shaderSource(result, text); gl.compileShader(result);
    if (!gl.getShaderParameter(result, gl.COMPILE_STATUS)) throw Error('Optical shader compilation failed');
    return result;
  }
  let program, texture, frame = 0, last = 0, elapsed = 0, ready = false, lost = false, needsPaint = true, suspended = false;
  const pointer = [.5, .5], pulses = new Float32Array([.5,.5,-1,.5,.5,-1,.5,.5,-1,.5,.5,-1]);
  let pulseIndex = 0, held = false, pressure = 0, lastTrail = 0;
  function stopped() { return suspended || battleActive || document.hidden || contrast.matches || transparency.matches || lost; }
  function resize() {
    // Native GPUs keep the full-resolution field. CPU-only rasterizers get a
    // smaller backing buffer so material never competes with direct manipulation.
    const scale = gameplay
      ? Math.min(.75, 640 / innerWidth, 480 / innerHeight)
      : software ? Math.min(1, 960 / innerWidth, 720 / innerHeight)
      : Math.min(devicePixelRatio || 1, 1.5, 1920 / innerWidth, 1440 / innerHeight);
    needsPaint = true;
    canvas.width = Math.max(1, Math.round(innerWidth * scale));
    canvas.height = Math.max(1, Math.round(innerHeight * scale));
  }
  function draw(now = 0) {
    frame = 0;
    if (!ready || stopped() || (motion.matches && !needsPaint)) { last = 0; return; }
    if (last && now - last < (gameplay ? 50 : software ? 32 : 15) && !motion.matches) { frame = requestAnimationFrame(draw); return; }
    if (last && !motion.matches) elapsed += Math.min(.1, (now - last) / 1000);
    last = now;
    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.useProgram(program);
    gl.uniform1f(gl.getUniformLocation(program, 'clock'), elapsed);
    gl.uniform1f(gl.getUniformLocation(program, 'aspect'), canvas.width / canvas.height);
    gl.uniform2fv(gl.getUniformLocation(program, 'pointer'), pointer);
    pressure += ((held ? 1 : 0) - pressure) * .24;
    gl.uniform1f(gl.getUniformLocation(program, 'pressure'), pressure);
    gl.uniform3fv(gl.getUniformLocation(program, 'pulses[0]'), pulses);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    needsPaint = false;
    canvas.dataset.opticalFrames = String(Number(canvas.dataset.opticalFrames || 0) + 1);
    if (!motion.matches) frame = requestAnimationFrame(draw);
  }
  function resume() {
    if (frame) cancelAnimationFrame(frame);
    frame = 0; last = 0;
    document.documentElement.dataset.waterPaused = document.hidden || battleActive ? 'true' : 'false';
    canvas.dataset.opticalMotion = motion.matches ? 'still' : 'live';
    if (ready && !stopped() && (!motion.matches || needsPaint)) frame = requestAnimationFrame(draw);
  }
  if (arenaOverlay) new MutationObserver(() => {
    const next = arenaOverlay.hidden;
    if (next === battleActive) return;
    battleActive = next; resume();
  }).observe(arenaOverlay, {attributes:true, attributeFilter:['hidden']});
  const image = new Image();
  function initialize() {
    try {
      if (program && !lost) { gl.deleteProgram(program); gl.deleteTexture(texture); }
      program = gl.createProgram();
      gl.attachShader(program, shader(gl.VERTEX_SHADER, vertex));
      gl.attachShader(program, shader(gl.FRAGMENT_SHADER, fragment)); gl.linkProgram(program);
      if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw Error('Optical shader linking failed');
      gl.useProgram(program);
      const buffer = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]), gl.STATIC_DRAW);
      const attribute = gl.getAttribLocation(program, 'a');
      gl.enableVertexAttribArray(attribute); gl.vertexAttribPointer(attribute, 2, gl.FLOAT, false, 0, 0);
      texture = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
      gl.uniform1i(gl.getUniformLocation(program, 'field'), 0);
      canvas.hidden = false;
      canvas.dataset.opticalScene = 'webgl';
      water.hidden = true; // CSS droplets are only the no-WebGL fallback.
      canvas.dataset.opticalSamples = String(image.width * image.height);
      ready = true; resize(); resume();
    } catch { ready = false; canvas.hidden = true; water.hidden = false; }
  }
  image.onload = initialize;
  image.onerror = () => canvas.remove();
  image.src = source;
  addEventListener('resize', () => { resize(); resume(); }, {passive: true});
  document.addEventListener('visibilitychange', resume);
  addEventListener('pagehide', event => {
    suspended = true; held = false; resume();
    if (!event.persisted) gl.getExtension('WEBGL_lose_context')?.loseContext();
  });
  addEventListener('pageshow', () => { suspended = false; resume(); });
  for (const preference of [motion, contrast, transparency]) preference.addEventListener('change', resume);
  document.addEventListener('pointermove', event => {
    if (motion.matches || stopped()) return;
    pointer[0] = event.clientX / innerWidth; pointer[1] = event.clientY / innerHeight;
    if (held && event.timeStamp - lastTrail > 90) { lastTrail = event.timeStamp; ripple(pointer[0], pointer[1]); }
  }, {passive: true});
  function ripple(x, y) {
    if (motion.matches || stopped()) return;
    const offset = (pulseIndex++ % 4) * 3;
    pulses[offset] = x; pulses[offset+1] = y; pulses[offset+2] = elapsed;
    canvas.dataset.opticalInputs = String(Number(canvas.dataset.opticalInputs || 0) + 1);
  }
  document.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    pointer[0] = event.clientX / innerWidth; pointer[1] = event.clientY / innerHeight;
    held = true; ripple(pointer[0], pointer[1]);
  }, {passive: true});
  for (const event of ['pointerup','pointercancel','blur','pagehide']) addEventListener(event, () => { held = false; }, {passive: true});
  document.addEventListener('visibilitychange', () => { if (document.hidden) held = false; });
  addEventListener('gardenoptics', event => ripple(event.detail?.x ?? .5, event.detail?.y ?? .5));
  canvas.addEventListener('webglcontextlost', event => { event.preventDefault(); lost = true; canvas.hidden = true; water.hidden = false; resume(); });
  canvas.addEventListener('webglcontextrestored', () => { lost = false; initialize(); });
})();
